'use strict';
// Builds the script that the bridge injects into every http(s) frame of every
// Chrome tab. It gives the UNMODIFIED content.js a tiny `chrome` object
// (runtime.sendMessage + storage.local + storage.onChanged) that talks to the
// bridge through a CDP binding, and (top frame, TTD pages only) mounts a small
// "G" launcher that opens the Govinda panel over the page.
//
// content.js is concatenated as plain text (never inside a template literal),
// because it contains backticks and ${...}.

function buildPageScript({ contentSrc, bind, port, embed, launcherRe }) {
  const head = `(function () {
  try {
    var LOADED = Symbol.for('govinda.loaded');
    if (window[LOADED]) return;
    if (!/^https?:$/.test(location.protocol)) return;
    if (location.hostname === '127.0.0.1' && String(location.port) === '${port}') return;
    var cur = window['${bind}'];
    if (typeof cur !== 'function') return;           // binding not installed yet; context-created hook retries
    Object.defineProperty(window, LOADED, { value: true });
    try { delete window['${bind}']; } catch (e) {}     // keep the channel private to this closure
    // After the bridge reconnects (e.g. adb dropped), Chrome installs a fresh binding: pick it up.
    function getSend() {
      var s = window['${bind}'];
      if (typeof s === 'function') { cur = s; try { delete window['${bind}']; } catch (e) {} }
      return cur;
    }

    var pending = new Map(), seq = 0, storageListeners = [];
    function rpc(kind, body, ms) {
      return new Promise(function (resolve, reject) {
        var id = ++seq;
        var t = setTimeout(function () { if (pending.delete(id)) reject(new Error('bridge timeout')); }, ms || 130000);
        pending.set(id, {
          resolve: function (v) { clearTimeout(t); resolve(v); },
          reject: function (e) { clearTimeout(t); reject(e); }
        });
        try { getSend()(JSON.stringify(Object.assign({ id: id, kind: kind }, body || {}))); }
        catch (e) { clearTimeout(t); pending.delete(id); reject(e); }
      });
    }
    Object.defineProperty(window, Symbol.for('govinda.recv'), {
      configurable: true,
      value: function (m) {
        if (m.push === 'storage') {
          storageListeners.forEach(function (f) { try { f(m.changes, m.area); } catch (e) {} });
          return;
        }
        var p = pending.get(m.id);
        if (!p) return;
        pending.delete(m.id);
        if (m.ok) p.resolve(m.value); else p.reject(new Error(m.error || 'bridge error'));
      }
    });

    var chromeShim = {
      runtime: { sendMessage: function (msg) { return rpc('msg', { msg: msg }); } },
      storage: {
        local: {
          get: function (k, cb) {
            var p = rpc('storage.get', { keys: k === undefined ? null : k });
            if (typeof cb === 'function') p.then(cb, function () { cb({}); });
            return p;
          },
          set: function (o, cb) {
            var p = rpc('storage.set', { items: o });
            if (typeof cb === 'function') p.then(function () { cb(); }, function () { cb(); });
            return p;
          }
        },
        onChanged: { addListener: function (f) { storageListeners.push(f); } }
      }
    };

    function runContent() {
      (function (chrome) {
`;

  const tail = `
      })(chromeShim);
    }

    function mountLauncher(tabId) {
      if (document.getElementById('__govinda_host')) return;
      var host = document.createElement('div');
      host.id = '__govinda_host';
      host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;right:0;bottom:0;';
      var root = host.attachShadow({ mode: 'closed' });
      root.innerHTML =
        '<style>' +
        '.fab{position:fixed;right:14px;bottom:90px;width:46px;height:46px;border-radius:50%;border:0;' +
        'background:#b45309;color:#fff;font:700 20px sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.4);opacity:.9}' +
        '.sheet{position:fixed;left:0;right:0;bottom:0;height:88vh;background:#fff;border-radius:14px 14px 0 0;' +
        'box-shadow:0 -6px 24px rgba(0,0,0,.45);display:none;flex-direction:column}' +
        '.bar{display:flex;align-items:center;justify-content:space-between;padding:6px 10px;font:13px sans-serif;' +
        'background:#1f2430;color:#fff;border-radius:14px 14px 0 0}' +
        '.bar button{background:none;border:0;color:#fff;font-size:18px;padding:4px 10px}' +
        '.bar a{color:#fcd34d;font-size:12px;margin-right:8px}' +
        'iframe{flex:1;border:0;width:100%;background:#fff}' +
        '</style>' +
        '<button class="fab" aria-label="Govinda">G</button>' +
        '<div class="sheet"><div class="bar"><span>Govinda Assistant</span><span>' +
        '<a target="_blank" rel="noopener" href="http://127.0.0.1:${port}/popup.html?tab=' + tabId + '">open in tab</a>' +
        '<button class="x" aria-label="Close">\\u2715</button></span></div></div>';
      var fab = root.querySelector('.fab'), sheet = root.querySelector('.sheet'), x = root.querySelector('.x');
      var frame = null;
      fab.addEventListener('click', function () {
        if (!frame) {
          frame = document.createElement('iframe');
          frame.src = 'http://127.0.0.1:${port}/popup.html?embed=1&tab=' + tabId;
          sheet.appendChild(frame);
        }
        sheet.style.display = 'flex';
        fab.style.display = 'none';
      });
      x.addEventListener('click', function () { sheet.style.display = 'none'; fab.style.display = ''; });
      (document.body || document.documentElement).appendChild(host);
    }

    var EMBED = ${embed ? 'true' : 'false'};
    var LAUNCH_RE = ${launcherRe};
    function boot() {
      runContent();
      if (EMBED && window.top === window && LAUNCH_RE.test(location.hostname)) {
        (function tryMount() {          // keeps retrying so the G button appears once the bridge link is back
          rpc('who', null, 4000).then(function (w) {
            if (w && w.tabId != null) mountLauncher(w.tabId); else setTimeout(tryMount, 3000);
          }).catch(function () { setTimeout(tryMount, 3000); });
        })();
      }
    }
    if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(boot, 0);
    else document.addEventListener('DOMContentLoaded', boot, { once: true });
  } catch (e) { /* never break the host page */ }
})();`;

  return head + contentSrc + tail;
}

module.exports = { buildPageScript };
