// Served to popup.html (before platform.js / popup.js). Replaces the extension
// APIs popup.js uses with calls to the local bridge. __TOKEN__ is filled in by
// the server on every load.
(function () {
  'use strict';
  var TOKEN = '__TOKEN__';
  var params = new URLSearchParams(location.search);
  var embedded = params.get('embed') === '1';
  var pinned = params.get('tab') ? Number(params.get('tab')) : null;
  var tabUpdated = [];
  var storageChanged = [];

  function api(kind, body) {
    return fetch('/api/rpc', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-gov-token': TOKEN },
      body: JSON.stringify(Object.assign({ kind: kind }, body || {}))
    }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok) throw new Error(j.error || 'bridge error');
      return j.value;
    });
  }

  function toast(text) {
    var d = document.createElement('div');
    d.textContent = text;
    d.style.cssText = 'position:fixed;left:8px;right:8px;top:8px;z-index:99999;background:#1f2430;color:#fff;' +
      'padding:10px 12px;border-radius:8px;font:13px sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.4)';
    document.body.appendChild(d);
    setTimeout(function () { d.remove(); }, 6000);
  }

  try {
    var es = new EventSource('/api/events?token=' + encodeURIComponent(TOKEN));
    es.onmessage = function (ev) {
      var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (m.type === 'tabUpdated') tabUpdated.forEach(function (f) { try { f(m.tabId, m.changeInfo, m.tab); } catch (e) {} });
      else if (m.type === 'storage') storageChanged.forEach(function (f) { try { f(m.changes, m.area); } catch (e) {} });
      else if (m.type === 'notify') toast((m.title || '') + (m.message ? ' - ' + m.message : ''));
    };
  } catch (e) {}

  window.chrome = {
    runtime: {
      lastError: undefined,
      sendMessage: function (msg) { return api('msg', { msg: msg, tabId: pinned }); },
      getURL: function (p) { return new URL(p, location.href).href; },
      onMessage: { addListener: function () {} }
    },
    storage: {
      local: {
        // popup.js uses the callback form: storage.local.get(keys, cb). Support both callback and promise.
        get: function (k, cb) {
          var p = api('storage.get', { keys: k === undefined ? null : k });
          if (typeof cb === 'function') { p.then(cb, function (e) { console.error('storage.get failed', e); cb({}); }); }
          return p;
        },
        set: function (o, cb) {
          var p = api('storage.set', { items: o });
          if (typeof cb === 'function') { p.then(function () { cb(); }, function (e) { console.error('storage.set failed', e); cb(); }); }
          return p;
        }
      },
      onChanged: { addListener: function (f) { storageChanged.push(f); } }
    },
    tabs: {
      query: function () {
        return api('tabs.active', { prefer: pinned }).then(function (t) { return t ? [t] : []; });
      },
      create: function (o) { return api('tabs.create', { url: o.url, active: o.active !== false }); },
      onUpdated: {
        addListener: function (f) { tabUpdated.push(f); },
        removeListener: function (f) { tabUpdated = tabUpdated.filter(function (x) { return x !== f; }); }
      }
    },
    scripting: {
      executeScript: function (o) {
        if (!o || typeof o.func !== 'function') return Promise.reject(new Error('only func injection is supported'));
        return api('scripting.exec', {
          tabId: o.target.tabId, allFrames: !!o.target.allFrames, func: String(o.func), args: o.args || []
        });
      }
    },
    windows: {
      create: function (o) { window.open(o.url, '_blank'); return Promise.resolve({}); }
    }
  };

  // Red banner while the bridge has no link to Chrome (adb dropped etc.).
  var banner = null;
  setInterval(function () {
    api('status').then(function (st) {
      if (st.connected && banner) { banner.remove(); banner = null; }
      if (!st.connected && !banner && document.body) {
        banner = document.createElement('div');
        banner.textContent = 'Not linked to Chrome - reconnecting. Check adb is still connected (Termux).';
        banner.style.cssText = 'position:sticky;top:0;z-index:99998;background:#b91c1c;color:#fff;padding:8px 10px;font:13px sans-serif';
        document.body.insertBefore(banner, document.body.firstChild);
      }
    }).catch(function () {});
  }, 3000);

  // Tell the on-page launcher the panel loaded (it shows a fallback link otherwise).
  if (embedded && window.parent !== window) {
    try { window.parent.postMessage({ govindaReady: true }, '*'); } catch (e) {}
  }

  // Standalone tab: let the person pick which Chrome tab to drive.
  if (!embedded && pinned == null) {
    document.addEventListener('DOMContentLoaded', function () {
      api('tabs.list').then(function (list) {
        if (!list.length) return;
        var bar = document.createElement('div');
        bar.style.cssText = 'padding:6px 8px;background:#1f2430;color:#fff;font:12px sans-serif;display:flex;gap:6px;align-items:center';
        var sel = document.createElement('select');
        sel.style.cssText = 'flex:1;min-width:0;font-size:12px';
        list.forEach(function (t) {
          var o = document.createElement('option');
          o.value = t.id; o.textContent = (t.title || t.url).slice(0, 60);
          sel.appendChild(o);
        });
        sel.onchange = function () { pinned = Number(sel.value); };
        bar.appendChild(document.createTextNode('Tab:'));
        bar.appendChild(sel);
        document.body.insertBefore(bar, document.body.firstChild);
      }).catch(function () {});
    });
  }
})();
