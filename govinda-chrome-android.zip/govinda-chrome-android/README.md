# Govinda Assistant for Chrome on Android

Chrome for Android cannot load extensions. This bridge runs in **Termux**, attaches to the real
Chrome app through its DevTools socket, and re-creates what the extension's browser provided.
`ext/` holds your v2.14.3 `background.js`, `content.js`, `popup.*` **unmodified**.

| Extension feature | How it works here |
|---|---|
| content.js on every frame | Injected over CDP with a small `chrome.runtime/storage` shim |
| background.js (Quick Book state machine, alarms, tab queue) | Runs in Node with a `chrome.*` host (alarms, tabs, scripting, storage, debugger) |
| Real taps / keystrokes (`chrome.debugger`) | `Input.dispatch*Event` over CDP (set `GOV_TOUCH=1` for touch events) |
| Popup | Floating **G** button on TTD pages (bottom sheet), or open http://127.0.0.1:8787/ in a tab |
| chrome.storage.local | `~/.govinda/storage.json` (mode 600 - contains the saved card, protect your phone) |
| Notifications | Termux:API notification + in-panel toast |

## Setup (once)
1. Install **Termux** (F-Droid) and optionally **Termux:API**. Copy this folder to Termux home, then `./setup-termux.sh`.
2. Enable **Wireless debugging** (Developer options), pair and connect adb to `127.0.0.1` as the script prints.
3. Open Chrome, then in Termux: `./start.sh`.
4. Open the TTD site in Chrome and tap the **G** button.

## Wi-Fi changes / mobile data
`./start.sh` now moves adb to the fixed local port 5555 by itself (one time, while Wireless debugging still works) and a watchdog
re-connects adb and the Chrome forward every 4 s. After that, switching Wi-Fi, hotspots or using mobile data does not stop it.
A phone reboot resets this: do one Wireless-debugging connect again, then run `./start.sh`.

## Using it without Wi-Fi
Wireless debugging itself only starts while Wi-Fi is on, so do this **once, at home on Wi-Fi**, after step 2:
`./enable-offline.sh` (runs `adb tcpip 5555`). From then on `./start.sh` connects to `127.0.0.1:5555`, which
needs no Wi-Fi (mobile data or airplane mode is fine). Repeat it once after every phone reboot.
Fallbacks if your phone refuses `adb tcpip`: connect to another phone's hotspot, or switch on this phone's own hotspot
while setting up. Everything else the bridge does is on `127.0.0.1` and needs no internet.

## Using it without Wi-Fi
Android's *Wireless debugging* only works while connected to Wi-Fi, so switch adb to local TCP once per boot:
1. While on Wi-Fi with Wireless debugging on and adb connected, run `./tcpip-setup.sh`.
2. Now Wi-Fi can be turned off (mobile data only). `./start.sh` reconnects adb through `127.0.0.1:5555` by itself.
3. After a phone reboot repeat step 1 (needs Wi-Fi/hotspot once).
Some phones restart adbd when Wi-Fi drops and lose this mode; if so, do step 1 using any Wi-Fi network
(a router or another phone's hotspot works - no internet needed) and turn Wi-Fi off afterwards.
If the link drops the popup shows a red "Not linked to Chrome" bar, and the G button / bridge recover by themselves
once adb is back (no page reload needed).

## Options (env vars)
`GOV_TOUCH=1` touch instead of mouse taps - `GOV_EMBED=0` no floating panel - `GOV_LAUNCHER_HOSTS='ttd|tirumala'` where the G button shows -
`GOV_BYPASS_CSP=0` (the panel iframe may then be blocked by a site's CSP; use "open in tab") - `GOV_PORT`, `GOV_DATA`, `GOV_SOCKET`.

## Security notes
- The server listens on 127.0.0.1 only, checks the Host header, and requires a per-run token for its API.
- While attached, the bridge relaxes page CSP (`Page.setBypassCSP`) so the panel can load. Disable with `GOV_BYPASS_CSP=0`.
- Chrome's DevTools access gives the bridge full control of your tabs; only run code you trust.

## Known differences / untested
- **Not yet tested on a real phone** - only against a mock DevTools endpoint (`npm test`). Expect to tune coordinates/timing.
- No "debugging this browser" bar; native `<select>` popups can't be driven (same as the extension).
- Android Chrome may throttle a hidden tab: keep the TTD tab in front (the floating panel avoids tab switching).
- The panel loads from `http://127.0.0.1` inside an https page; newer Chrome "local network access" prompts may appear - allow it.
- `chrome.debugger.getTargets` etc. are stubs; extension-only popup layout "Layover" opens a new tab.
