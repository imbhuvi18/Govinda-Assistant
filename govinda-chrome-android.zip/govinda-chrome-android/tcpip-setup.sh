#!/data/data/com.termux/files/usr/bin/bash
# Run ONCE per phone boot, while Wi-Fi + Wireless debugging are still on.
# Switches adbd to plain TCP on port 5555 so Termux can reach it at 127.0.0.1
# even after Wi-Fi is turned off (works until the phone reboots).
cd "$(dirname "$0")"
SERIAL=$(adb devices | awk 'NR>1 && $2=="device"{print $1; exit}')
[ -z "$SERIAL" ] && { echo "No adb device. Do 'adb pair' / 'adb connect' first (see README)."; exit 1; }
adb -s "$SERIAL" tcpip 5555
sleep 3
adb connect 127.0.0.1:5555
adb devices
echo "Done. Now you can turn Wi-Fi off. ./start.sh will use 127.0.0.1:5555."
