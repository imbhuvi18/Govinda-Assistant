#!/data/data/com.termux/files/usr/bin/bash
# Starts the Govinda bridge and keeps adb + the Chrome DevTools forward alive
# when Wi-Fi/hotspot changes or mobile data is used.
cd "$(dirname "$0")"
LOCAL=127.0.0.1:5555
say() { echo "[$(date +%H:%M:%S)] $*"; }

online_serials() { adb devices | awk 'NR>1 && $2=="device"{print $1}'; }

ensure() {
  # forget stale entries left over from an old Wi-Fi/hotspot address
  adb devices | awk 'NR>1 && $2=="offline"{print $1}' | while read -r s; do adb disconnect "$s" >/dev/null 2>&1; done

  # 1) fixed local port: independent of Wi-Fi (needs one earlier `adb tcpip 5555`)
  online_serials | grep -qx "$LOCAL" || adb connect "$LOCAL" >/dev/null 2>&1
  if ! online_serials | grep -qx "$LOCAL"; then
    # 2) still on Wireless debugging? promote it to the fixed local port once
    OTHER=$(online_serials | head -1)
    if [ -n "$OTHER" ]; then
      say "Switching adb to $LOCAL so it survives Wi-Fi changes..."
      adb -s "$OTHER" tcpip 5555 >/dev/null 2>&1
      sleep 3
      adb connect "$LOCAL" >/dev/null 2>&1
    fi
  fi
  online_serials | grep -qx "$LOCAL" && SER=$LOCAL || SER=$(online_serials | head -1)
  [ -n "$SER" ] || return 1

  SOCK=${GOV_SOCKET:-$(adb -s "$SER" shell cat /proc/net/unix 2>/dev/null | grep -o 'chrome_devtools_remote[^ ]*' | head -1)}
  [ -n "$SOCK" ] || return 2
  adb -s "$SER" forward tcp:9222 localabstract:"$SOCK" >/dev/null 2>&1
  echo "$SER"
}

# First connection must succeed, otherwise explain what to do.
for i in 1 2 3; do SER=$(ensure) && break; sleep 2; done
if [ -z "$SER" ]; then
  say "Could not reach Chrome. Check:"
  say " - Chrome is open"
  say " - adb is connected: turn on Wireless debugging once and run  adb connect 127.0.0.1:<PORT>"
  say "   (after that this script moves adb to port 5555 and no longer needs Wi-Fi)"
  exit 1
fi
say "adb ready on $SER"

# Watchdog: re-heals adb / the forward every few seconds (Wi-Fi change, Chrome restart, adb restart).
( LAST=""
  while sleep 4; do
    CUR=$(ensure); RC=$?
    [ "$CUR" != "$LAST" ] && { [ $RC -eq 0 ] && say "adb ok ($CUR)" || say "waiting for adb/Chrome..."; LAST="$CUR"; }
  done ) &
WATCH=$!
trap 'kill $WATCH 2>/dev/null' EXIT

termux-wake-lock 2>/dev/null
node server.js
