// Picks the popup layout BEFORE first paint (loaded synchronously in <head>).
//   desktop  -> compact dropdown panel (like a normal browser-action popup)
//   mobile   -> full-width sheet (Android browsers such as Quetta)
//   layover  -> the wide window opened by the 🖥️ Layover button
(function () {
  var ua = navigator.userAgent || "";
  var uad = navigator.userAgentData;
  var mobile = uad && typeof uad.mobile === "boolean" ? uad.mobile : /Android|iPhone|iPad|Mobile/i.test(ua);
  var layover = /[?&]layout=desktop\b/.test(location.search);
  document.documentElement.dataset.platform = layover ? "layover" : mobile ? "mobile" : "desktop";
})();
