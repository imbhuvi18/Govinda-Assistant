// ---- Scheduled tab queue ----
// Lets the popup line up several service tabs to open automatically at
// their own release times, instead of babysitting one at a time. Each
// entry gets its own one-shot chrome.alarms alarm (survives the popup
// closing/the browser sleeping, same reasoning as ADVANCE_ALARM_PREFIX
// below) named "pilgrim_queue_<entryId>"; alarms only carry a name back,
// not arbitrary data, so the actual entries (label/url) are kept in
// chrome.storage.local under TAB_QUEUE_KEY for the alarm handler to look
// up when it fires.
const TAB_QUEUE_ALARM_PREFIX = "pilgrim_queue_";
const TAB_QUEUE_KEY = "pilgrimTabQueue";

async function syncTabQueueAlarms(queue) {
  await chrome.storage.local.set({ [TAB_QUEUE_KEY]: Array.isArray(queue) ? queue : [] });
  const all = await chrome.alarms.getAll();
  const ours = all.filter((a) => a.name.startsWith(TAB_QUEUE_ALARM_PREFIX));
  await Promise.all(ours.map((a) => chrome.alarms.clear(a.name)));
  for (const entry of queue || []) {
    const when = new Date(entry.time).getTime();
    if (!Number.isFinite(when) || when <= Date.now()) continue; // past/invalid — don't schedule
    chrome.alarms.create(`${TAB_QUEUE_ALARM_PREFIX}${entry.id}`, { when });
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith(TAB_QUEUE_ALARM_PREFIX)) return;
  const entryId = alarm.name.slice(TAB_QUEUE_ALARM_PREFIX.length);
  const { [TAB_QUEUE_KEY]: queue = [] } = await chrome.storage.local.get([TAB_QUEUE_KEY]);
  const entry = queue.find((e) => e.id === entryId);
  // One-shot: drop it from storage regardless of whether it's still found,
  // so a stale/misfired alarm can't loop.
  await chrome.storage.local.set({ [TAB_QUEUE_KEY]: queue.filter((e) => e.id !== entryId) });
  if (!entry?.url) return;
  try {
    await chrome.tabs.create({ url: entry.url, active: false });
    notifyBg("🗓️ Opened scheduled tab", entry.label || entry.url);
  } catch (err) {
    notifyBg("⚠️ Scheduled tab failed to open", `${entry.label || entry.url}: ${err?.message || err}`);
  }
});

// background.js — drives the Continue → Pay Now → payment-method chooser →
// card sub-form flow from the (persistent-across-navigation) service
// worker instead of the popup.
//
// Why this exists: popups are ephemeral. On mobile browsers especially, a
// full-page redirect — TTD shows "Redirecting to payment gateway. Please
// do not click on refresh or back button." — reliably closes the
// extension popup. Once a popup closes, every bit of JS running inside it
// stops immediately, mid-`await` and all, with no error surfaced anywhere.
// The old design ran the entire multi-page chain as one continuous
// function inside popup.js, so it died silently the instant that redirect
// happened — no card selection, no fill, no Proceed, and nothing telling
// the person why.
//
// The service worker isn't tied to any popup's lifecycle — it keeps
// running (or gets woken back up by chrome.tabs.onUpdated) regardless of
// whether the popup is open. So instead of one long function, the flow is
// a small state machine: each step does ONE action, and the NEXT step
// only runs once chrome.tabs.onUpdated reports the resulting page has
// finished loading. Session state lives in chrome.storage.session (not a
// plain in-memory variable) so it survives the service worker itself
// being torn down and restarted between steps, which MV3 can do freely
// when the worker's been idle for a few seconds.

const SESSION_PREFIX = "pilgrim_pay_session_";
const SESSION_TIMEOUT_MS = 120000; // give up (and clean up) after 120s of no progress — was 90s; raised to comfortably fit fill_card's longer CARD_FIELD_RETRY_LIMIT wait on top of the earlier steps' own time
const STEP_RETRY_LIMIT = 15; // guard against polling forever on a stuck/unrelated page
// fill_card's "wait for the card number field" loop gets its own, longer
// budget: unlike every other step here, it's waiting on a *third-party*
// payment-gateway page rather than TTD's own site, and those have been
// observed taking noticeably longer than a few seconds to finish
// rendering their form on a real (non-Wi-Fi) mobile connection. The
// original 15 attempts x 400ms (~6s) gave up well before that page was
// actually ready, surfacing "Card page didn't finish loading — fill it
// in yourself" on a page that in fact went on to load fine seconds later.
const CARD_FIELD_RETRY_LIMIT = 60; // ~20s at ~300ms per attempt — still well inside SESSION_TIMEOUT_MS

function sessionKey(tabId) {
  return `${SESSION_PREFIX}${tabId}`;
}

async function getSession(tabId) {
  const res = await chrome.storage.session.get(sessionKey(tabId));
  return res[sessionKey(tabId)] || null;
}

async function setSession(tabId, session) {
  await chrome.storage.session.set({ [sessionKey(tabId)]: session });
}

// A run only writes/clears the session if it is still the CURRENT run — an
// older run finishing late must never wipe the session of the run the
// person just started by tapping Fill again.
async function saveMine(tabId, session) {
  const cur = await getSession(tabId);
  if (cur && cur.runId && session.runId && cur.runId !== session.runId) return false;
  await setSession(tabId, session);
  return true;
}
async function clearMine(tabId, session) {
  const cur = await getSession(tabId);
  if (cur && cur.runId && session.runId && cur.runId !== session.runId) return false;
  await clearSession(tabId);
  return true;
}

async function clearSession(tabId) {
  await chrome.storage.session.remove(sessionKey(tabId));
  chrome.alarms.clear(`${ADVANCE_ALARM_PREFIX}${tabId}`).catch(() => {});
}

// Small on-page status bubble — the popup's own toast is useless here
// since the popup is very likely already closed by the time later steps
// run, so progress has to be shown on the page itself instead.
function injectedShowStatus(msg, isError) {
  const id = "__pilgrimBgStatus";
  let box = document.getElementById(id);
  if (!box) {
    box = document.createElement("div");
    box.id = id;
    box.style.cssText =
      "position:fixed;z-index:2147483647;left:16px;bottom:16px;right:16px;max-width:320px;" +
      "background:#1f2430;color:#fff;padding:12px 14px;border-radius:10px;" +
      "font:13px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;" +
      "box-shadow:0 6px 20px rgba(0,0,0,.35);";
    document.body.appendChild(box);
  }
  box.style.borderLeft = isError ? "4px solid #f87171" : "4px solid #34d399";
  box.textContent = msg;
  clearTimeout(box._pilgrimTimer);
  box._pilgrimTimer = setTimeout(() => box.remove(), 9000);
}

async function showStatus(tabId, msg, isError = false) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: injectedShowStatus,
      args: [msg, !!isError]
    });
  } catch (err) {
    // Tab can be mid-navigation at this exact instant (about:blank between
    // pages, etc.) — not fatal, the next status update will land instead.
  }
}

// Desktop notification for the card-payment chain specifically — this is
// exactly the code path that exists because the popup is very likely
// already closed by the time these steps run (see the big comment above),
// so the popup's own toast can't be relied on to ever reach the person.
// Best-effort: chrome.notifications may be unavailable/blocked at the OS
// level, and that should never break the actual payment flow.
function notifyBg(title, message) {
  try {
    chrome.notifications?.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message: message || ""
    });
  } catch (err) {
    // Non-fatal.
  }
}

// Small colored badge on the toolbar icon so queue/slot state is visible
// at a glance without opening the popup. Cleared automatically after a
// while so it doesn't go stale and mislead on a later, unrelated visit.
let badgeClearTimer = null;
function setBadge(text, color) {
  try {
    chrome.action?.setBadgeText({ text: text || "" });
    if (color) chrome.action?.setBadgeBackgroundColor({ color });
    if (badgeClearTimer) clearTimeout(badgeClearTimer);
    if (text) {
      badgeClearTimer = setTimeout(() => {
        chrome.action?.setBadgeText({ text: "" });
      }, 10 * 60 * 1000);
    }
  } catch (err) {
    // Non-fatal — badge is a convenience, not load-bearing.
  }
}

// ---- injected step wrappers (executed in the page context) ----
async function injDrive(opts) {
  return window.__pilgrimDrive ? await window.__pilgrimDrive(opts) : { ok: false, reason: "not ready" };
}
async function injClickContinue() {
  return window.__pilgrimClickContinue ? await window.__pilgrimClickContinue() : { ok: false, reason: "not ready" };
}
async function injClickReviewPay() {
  return window.__pilgrimClickReviewPay ? await window.__pilgrimClickReviewPay() : { ok: false, reason: "not ready" };
}
async function injSelectCard() {
  return window.__pilgrimSelectCardOption
    ? await window.__pilgrimSelectCardOption()
    : { ok: false, reason: "not ready" };
}
async function injHasCardNumberField() {
  return window.__pilgrimHasCardNumberField ? window.__pilgrimHasCardNumberField() : false;
}
async function injFillCard(card) {
  return window.__pilgrimFillCardFields ? await window.__pilgrimFillCardFields(card) : { filledCount: 0 };
}
async function injCardProceed(opts) {
  return window.__pilgrimCardProceed ? await window.__pilgrimCardProceed(opts) : { ok: false, reason: "not ready" };
}
async function injFill(payload) {
  return window.__pilgrimAutofillRun ? await window.__pilgrimAutofillRun(payload) : { filledCount: 0, error: "content script not ready" };
}

// Quick Book target: the whole run, CVV window included, in about this long.
// (Waits inside the extension are kept short to fit; the TTD site's own load
// time is outside its control.) The on-page bubble shows the running clock.
const QUICK_TARGET_SECONDS = 40;
const CVV_WINDOW_SECONDS = 10;
function elapsedTag(session) {
  if (!session || !session.quick || !session.startedAt) return "";
  const sec = Math.round((Date.now() - session.startedAt) / 1000);
  return `[${sec}s / ${QUICK_TARGET_SECONDS}s] `;
}
function tshow(tabId, session, msg, isError = false) {
  return showStatus(tabId, elapsedTag(session) + msg, isError);
}

// TTD's payment gateway commonly renders the actual Card Number/Expiry
// fields, the Card option itself, and the final Proceed button inside a
// same-page but cross-origin payment-gateway iframe (Razorpay/Billdesk/
// PayU-style embeds), not the top-level document. executeScript only
// touches the top frame unless told otherwise, so every card-related step
// below needs allFrames: true — otherwise hasCardNumberField() (and the
// select/fill/proceed steps that depend on it) can poll forever against a
// frame that was never going to have the field, and eventually give up
// with "Card page didn't finish loading" even though the real card form
// loaded just fine one frame over.
async function runStep(tabId, func, args = [], opts = {}) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId, allFrames: !!opts.allFrames },
      func,
      args
    });
    if (!opts.allFrames) return results?.[0]?.result;

    const values = results.map((r) => r?.result).filter((v) => v !== undefined);
    if (!values.length) return undefined;

    // hasCardNumberField()-style: true if the field exists in ANY frame.
    if (values.every((v) => typeof v === "boolean")) {
      return values.some(Boolean);
    }

    // fillCardFields()-style {filledCount}: different card fields can
    // legitimately live in different frames — a payment gateway commonly
    // scopes Card Number/Expiry/CVV inside a separate PCI-compliance
    // iframe from a plain field like Name on Card sitting in the main
    // page or a different iframe. Picking only the first frame that
    // filled *anything* was silently dropping whichever field lived in
    // whatever frame didn't happen to be checked first — sum every
    // frame's contribution instead.
    if (values.some((v) => typeof v?.filledCount === "number")) {
      const total = values.reduce((sum, v) => sum + (v?.filledCount || 0), 0);
      const expected = values.reduce((sum, v) => sum + (v?.expected || 0), 0);
      const failed = values.flatMap((v) => v?.failed || []);
      const located = values.flatMap((v) => v?.located || []);
      return { filledCount: total, expected, failed, located };
    }

    // {ok, reason}-style (selectCard, cardProceed, clickContinue, …):
    // success if any frame succeeded; otherwise surface a real reason
    // instead of an empty result.
    const okHit = values.find((v) => v?.ok === true);
    if (okHit) return okHit;
    return values.find((v) => v?.terminal) || values.find((v) => v?.reason) || values[0];
  } catch (err) {
    return { ok: false, reason: (err && err.message) || String(err) };
  }
}

// Advances a session by one step. Called right after starting, and again
// on every subsequent page load for that tab. Safe to call when a step
// isn't ready yet (e.g. still on an intermediate "Redirecting…" screen) —
// it just records a failed attempt and waits for the next page-load event
// rather than treating that as a hard failure.

// Why chrome.alarms instead of setTimeout for retries:
//
// retryAdvance used to be `setTimeout(() => advance(tabId), delayMs)` — a
// plain JS timer living in this service worker. That works right up until
// Chrome (or a mobile browser) decides to tear the idle worker down while
// that timer is still pending, which MV3 allows at any moment. A bare
// setTimeout does not keep the worker alive, and once the worker is
// killed mid-wait, that pending callback is simply gone: the retry chain
// dies silently. Nothing calls advance() again (most of these steps are
// same-page SPA transitions, so chrome.tabs.onUpdated won't fire either),
// and the retry-limit/error-reporting code further down in advance() never
// runs either, since it lives inside the same dead callback. From the
// outside this looks exactly like "stopped after filling details, no
// error, nothing happens" — specifically at whichever retry happened to
// be in flight when the worker got killed (click_review_pay's own retry,
// most commonly, since the review screen can take a beat to render its
// Pay Now button).
//
// chrome.alarms fixes this because an alarm is registered with the
// browser itself, not just held in the worker's memory — it fires (and
// wakes the service worker back up if needed) even after the worker was
// killed in the meantime. The tradeoff is coarser timing (some browsers
// clamp very short delays upward), which is a fine trade against a
// silently permanent stall.
const ADVANCE_ALARM_PREFIX = "pilgrim_pay_advance_";

function retryAdvance(tabId, delayMs = 700) {
  // Fast path (works while the worker is alive) + alarm as the safety net
  // for a worker that gets killed. Alarms alone can be clamped to 30s in
  // some browsers, which looks like "it stopped".
  //
  // The alarm is only a fallback: advance() clears it as soon as it runs,
  // so a step that already ran from the timer is never run a second time
  // when the alarm would otherwise fire (that duplicate run could click
  // Pay Now twice). Note the unit fix too: delayMs is milliseconds and
  // delayInMinutes needs minutes (the old code divided a value already
  // clamped to >=1 ms, which made every alarm fire at the browser's floor).
  setTimeout(() => { advance(tabId).catch(() => {}); }, delayMs);
  chrome.alarms.create(`${ADVANCE_ALARM_PREFIX}${tabId}`, { delayInMinutes: Math.max(delayMs / 60000, 0.5) });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm.name.startsWith(ADVANCE_ALARM_PREFIX)) return;
  const tabId = Number(alarm.name.slice(ADVANCE_ALARM_PREFIX.length));
  if (!Number.isFinite(tabId)) return;
  advance(tabId).catch(() => {});
});

// Serialised per tab: a page-load event and a retry timer must never run
// two steps at once (that could double-click). A call that arrives while a
// step is running is queued and re-run once afterwards.
const __advState = new Map();
async function advance(tabId) {
  // Whatever triggered this call (timer, page load, or the alarm itself)
  // is now handling the pending retry, so the fallback alarm is redundant.
  chrome.alarms.clear(`${ADVANCE_ALARM_PREFIX}${tabId}`).catch(() => {});
  const st = __advState.get(tabId) || { running: false, again: false };
  __advState.set(tabId, st);
  if (st.running) { st.again = true; return; }
  st.running = true;
  try {
    do { st.again = false; await advanceStep(tabId); } while (st.again);
  } finally {
    st.running = false;
  }
}

async function advanceStep(tabId) {
  const session = await getSession(tabId);
  if (!session) return;

  if (Date.now() - session.startedAt > SESSION_TIMEOUT_MS) {
    await tshow(tabId, session, "⚠️ Auto Continue → Pay timed out — finish this step yourself", true);
    notifyBg("⚠️ Stopped at payment", "Auto Continue → Pay timed out — check the tab.");
    await clearMine(tabId, session);
    return;
  }

  // Quick Book step 1: date / slot / tickets -> Continue -> pilgrim + contact details,
  // all through the same fill the per-service tabs always used (content.js
  // __pilgrimAutofillRun). Then straight into the generic button driver below.
  if (session.step === "fill") {
    const res = await runStep(tabId, injFill, [{ ...(session.fillPayload || {}), dryRun: false }]);
    const count = res?.filledCount || 0;
    const failed = !!(res && (res.error || res.ok === false)) && count === 0;
    if (failed && (session.attempts || 0) < 2) {
      // Page may have been mid-navigation after the date step; run it again.
      session.attempts = (session.attempts || 0) + 1;
      if (!(await saveMine(tabId, session))) return;
      retryAdvance(tabId, 350);
      return;
    }
    const fp = session.fillPayload || {};
    session.payload = { pilgrims: fp.pilgrims || [], contact: fp.contact || null, dateSlot: null, dryRun: false };
    session.step = "drive";
    session.attempts = 0;
    if (!(await saveMine(tabId, session))) return;
    const missed = (res?.missed || []).filter(Boolean);
    if (missed.length) await tshow(tabId, session, `Filled ${count} field(s) — note: ${missed.slice(0, 2).join("; ")}. Continuing…`);
    else await tshow(tabId, session, count > 0 ? `Filled ${count} field(s) — continuing…` : "Nothing new to fill here — continuing…");
    return advanceStep(tabId);
  }

  if (session.step === "click_continue" || session.step === "click_review_pay" || session.step === "drive") {
    // One generic step: look at whatever screen is showing and click
    // Continue / Pay Now as many times as THIS flow needs, until the
    // payment-method page is reached. Flows differ (2, 3 or 4 screens), so
    // nothing here assumes a fixed count.
    session.step = "drive";
    const res = await runStep(tabId, injDrive, [{ mode: "auto", finalPay: "click", payload: session.payload || null, maxMs: 50000, cancelSecs: session.quick ? 1 : 2 }]);
    if (res?.superseded) return; // a newer Fill started; it owns the session now
    if (res?.ok && res.booked) {
      await tshow(tabId, session, "Booking submitted" + (res.confirmationRef ? ` — ref ${res.confirmationRef}` : "."));
      notifyBg("✅ Booking submitted", res.confirmationRef ? `Reference: ${res.confirmationRef}` : "Check the tab for the confirmation.");
      await clearMine(tabId, session);
      return;
    }
    if (res?.ok && res.arrived) {
      session.step = session.useCard ? "select_card" : "done";
      session.attempts = 0;
      if (!(await saveMine(tabId, session))) return;
      await tshow(tabId, session, "Reached the payment page" + (session.useCard ? " — selecting Card…" : "."));
      if (!session.useCard) { await clearMine(tabId, session); return; }
      return advanceStep(tabId);
    }
    if (res?.terminal) {
      await tshow(tabId, session, `⚠️ ${res.reason} — finish this step yourself`, true);
      notifyBg("⚠️ Stopped before payment", res.reason || "check the tab.");
      await clearMine(tabId, session);
      return;
    }
    // Not terminal: the page navigated mid-script, hasn't rendered yet, or
    // the 50s window ran out. Try again (also re-triggered by page loads).
    session.attempts = (session.attempts || 0) + 1;
    if (session.attempts >= STEP_RETRY_LIMIT) {
      const why = res?.reason || "couldn't reach the payment page";
      await tshow(tabId, session, `⚠️ ${why}`, true);
      notifyBg("⚠️ Stopped before payment", why);
      await clearMine(tabId, session);
      return;
    }
    if (!(await saveMine(tabId, session))) return;
    if (res?.clicks) await tshow(tabId, session, `Clicked ${res.clicks} step(s) — continuing…`);
    retryAdvance(tabId, 300);
    return;
  }

  if (session.step === "select_card") {
    if (!session.useCard) {
      // Non-card path doesn't hand off to the background worker (see
      // content.js's comment on __pilgrimAutoContinuePay) — nothing left
      // to drive from here.
      await clearMine(tabId, session);
      return;
    }
    const res = await runStep(tabId, injSelectCard, [], { allFrames: true });
    if (res?.ok) {
      session.step = "fill_card";
      session.attempts = 0;
      if (!(await saveMine(tabId, session))) return;
      await tshow(tabId, session, "Card option selected — filling in your details…");
      return advanceStep(tabId);
    }
    session.attempts = (session.attempts || 0) + 1;
    if (session.attempts >= STEP_RETRY_LIMIT) {
      await tshow(tabId, session, `⚠️ ${res?.reason || "Couldn't find the Card option"} — select it yourself`, true);
      notifyBg("⚠️ Stopped at payment", `${res?.reason || "Couldn't find the Card option"} — check the tab.`);
      await clearMine(tabId, session);
      return;
    }
    if (!(await saveMine(tabId, session))) return;
    retryAdvance(tabId, 400); // payment gateway can render without a full load
    return;
  }

  if (session.step === "fill_card") {
    let ready = await runStep(tabId, injHasCardNumberField, [], { allFrames: true });
    if (!ready && (session.attempts || 0) % 3 === 0) {
      // Card form not visible yet: the earlier Card tap may have been
      // ignored (or the chooser re-rendered). Tap the Card option again.
      await runStep(tabId, injSelectCard, [], { allFrames: true });
      ready = await runStep(tabId, injHasCardNumberField, [], { allFrames: true });
    }
    if (!ready) {
      session.attempts = (session.attempts || 0) + 1;
      if (session.attempts >= CARD_FIELD_RETRY_LIMIT) {
        await tshow(tabId, session, "⚠️ Card page didn't finish loading — fill it in yourself", true);
        notifyBg("⚠️ Stopped at payment", "Card page didn't finish loading — check the tab.");
        await clearMine(tabId, session);
        return;
      }
      if (!(await saveMine(tabId, session))) return;
      // The gateway redirect's own page-load event got us here, but the
      // card number field can still take a beat to render after that —
      // this used to just save state and stop, relying entirely on
      // another chrome.tabs.onUpdated firing (which won't, since nothing
      // navigates again from here) to ever check again.
      retryAdvance(tabId, 300);
      return;
    }

    let fillRes = await runStep(tabId, injFillCard, [session.card], { allFrames: true });
    // The gateway can re-render and wipe values a moment after typing —
    // a second pass re-checks and refills only what didn't stick.
    await new Promise((r) => setTimeout(r, 300));
    const fillRes2 = await runStep(tabId, injFillCard, [session.card], { allFrames: true });
    if ((fillRes2?.filledCount || 0) > (fillRes?.filledCount || 0)) fillRes = fillRes2;
    const filled = fillRes?.filledCount || 0;
    if (filled > 0 && (fillRes?.failed || []).length) {
      const miss = fillRes.failed.join(", ");
      await tshow(tabId, session, `⚠️ Filled ${filled} card field(s) but couldn't fill: ${miss}. Enter those + CVV yourself — auto-pay skipped.`, true);
      notifyBg("⚠️ Card partly filled", `Couldn't fill: ${miss}. Finish the card page manually.`);
      await clearMine(tabId, session);
      return;
    }
    if (filled > 0) {
      await tshow(tabId, session, `✓ Card details filled. Type your CVV now (${CVV_WINDOW_SECONDS}s) — it pays as soon as it is complete.`);
      // CVV is never touched by the extension. The user gets the full
      // 10-second visible cancellation window to enter CVV; if they don't
      // cancel, the extension clicks the gateway's Proceed/Pay button.
      // Because CVV remains blank, the payment gateway should not be able
      // to complete authorization without the user's manual CVV entry.
      session.step = "card_proceed";
      session.attempts = 0;
      if (!(await saveMine(tabId, session))) return;
      retryAdvance(tabId, 250);
      return;
    } else {
      await tshow(tabId, session, "⚠️ Couldn't find the card fields — fill those (and CVV) yourself", true);
      notifyBg("⚠️ Stopped at payment", "Couldn't find the card fields — check the tab.");
    }
    await clearMine(tabId, session);
    return;
  }

  if (session.step === "card_proceed") {
    const res = await runStep(tabId, injCardProceed, [{ cvvSeconds: CVV_WINDOW_SECONDS }], { allFrames: true });
    if (res?.ok) {
      await tshow(tabId, session, "Pay tapped. Complete any bank/OTP authorization in the tab.");
      notifyBg("💳 Proceed clicked — payment not complete yet", "Finish the CVV / bank authorization in the tab. The booking is only confirmed once the payment succeeds.");
      await clearMine(tabId, session);
      return;
    }
    if (res?.reason === "Proceed cancelled" || res?.terminal) {
      if (res?.terminal && res.reason !== "Proceed cancelled") {
        await tshow(tabId, session, `⚠️ ${res.reason}`, true);
        notifyBg("⚠️ Stopped at payment", res.reason);
      }
      await clearMine(tabId, session);
      return;
    }
    session.attempts = (session.attempts || 0) + 1;
    if (session.attempts >= (session.quick ? 2 : 10)) {
      await tshow(tabId, session, `⚠️ ${res?.reason || "Proceed button not found"} — enter CVV and continue manually`, true);
      notifyBg("⚠️ Stopped at payment", `${res?.reason || "Proceed button not found"} — check the tab.`);
      await clearMine(tabId, session);
      return;
    }
    if (!(await saveMine(tabId, session))) return;
    retryAdvance(tabId, 700);
    return;
  }
}


// ---- Trusted tap (genuine mouse click via the debugger protocol) ----------
// Used by the content script when synthetic DOM events can't open a site's
// custom dropdown. Fails gracefully where chrome.debugger isn't available.
const __pilgrimDbg = new Map();

try {
  chrome.debugger?.onDetach.addListener((src) => {
    if (src && src.tabId != null) {
      clearTimeout(__pilgrimDbg.get(src.tabId));
      __pilgrimDbg.delete(src.tabId);
    }
  });
} catch (_) {}

async function dbgReallyAttached(tabId) {
  try {
    const targets = await chrome.debugger.getTargets();
    return targets.some((t) => t.tabId === tabId && t.attached);
  } catch (_) {
    return false;
  }
}

// Attaches (or re-attaches) the debugger, trusting the browser's own view of
// whether it's attached rather than our cached map — the user closing the
// "debugging this browser" bar silently detaches it, after which every tap
// would otherwise fail until the cache expired.
async function dbgEnsure(tabId, force = false) {
  if (typeof chrome === "undefined" || !chrome.debugger) throw new Error("debugger API unavailable");
  // A forced re-attach must detach first even when our in-memory map has
  // no entry: after the service worker is restarted the map is empty, but
  // the browser can still hold the previous attachment, and attaching again
  // just reports "already attached" and reuses the broken session.
  if (force || (__pilgrimDbg.has(tabId) && !(await dbgReallyAttached(tabId)))) {
    clearTimeout(__pilgrimDbg.get(tabId));
    __pilgrimDbg.delete(tabId);
    if (force) { try { await chrome.debugger.detach({ tabId }); } catch (_) {} }
  }
  if (!__pilgrimDbg.has(tabId)) {
    try { await chrome.debugger.attach({ tabId }, "1.3"); }
    catch (e) { if (!/already attached/i.test(String(e?.message || e))) throw e; }
  }
  clearTimeout(__pilgrimDbg.get(tabId));
  __pilgrimDbg.set(tabId, setTimeout(() => {
    chrome.debugger.detach({ tabId }).catch(() => {});
    __pilgrimDbg.delete(tabId);
  }, 60000));
}

// Runs fn(send) with a live debugger session; on failure re-attaches once.
async function withDbg(tabId, fn) {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      await dbgEnsure(tabId, attempt > 0);
      return await fn((method, params) => chrome.debugger.sendCommand({ tabId }, method, params));
    } catch (e) {
      if (attempt === 1) throw e;
    }
  }
}

async function pilgrimTrustedTap(tabId, x, y) {
  try {
    await withDbg(tabId, async (send) => {
      await send("Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
      await send("Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", buttons: 1, clickCount: 1 });
      await send("Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", buttons: 0, clickCount: 1 });
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

// Genuine keystrokes into whatever element currently has focus (the content
// script focuses the field first). Needed for card inputs that ignore
// scripted value changes.
function keyInfo(ch) {
  if (/[0-9]/.test(ch)) return { code: "Digit" + ch, vk: ch.charCodeAt(0) };
  if (/[a-z]/i.test(ch)) return { code: "Key" + ch.toUpperCase(), vk: ch.toUpperCase().charCodeAt(0) };
  if (ch === " ") return { code: "Space", vk: 32 };
  if (ch === "/") return { code: "Slash", vk: 191 };
  if (ch === "-") return { code: "Minus", vk: 189 };
  if (ch === ".") return { code: "Period", vk: 190 };
  return { code: "", vk: 0 };
}

async function pilgrimTrustedType(tabId, text) {
  try {
    await withDbg(tabId, async (send) => {
      // select-all so a stray existing value is replaced
      await send("Input.dispatchKeyEvent", { type: "keyDown", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
      await send("Input.dispatchKeyEvent", { type: "keyUp", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
      for (const ch of String(text)) {
        const { code, vk } = keyInfo(ch);
        await send("Input.dispatchKeyEvent", { type: "keyDown", key: ch, code, text: ch, unmodifiedText: ch, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
        await send("Input.dispatchKeyEvent", { type: "keyUp", key: ch, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
        await new Promise((r) => setTimeout(r, 25));
      }
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.action === "pilgrimDbgAttach") {
    const tabId = sender?.tab?.id;
    if (tabId == null) { sendResponse({ ok: false, error: "no tab" }); return false; }
    dbgEnsure(tabId).then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }
  if (msg?.action === "pilgrimTrustedMove") {
    const tabId = sender?.tab?.id;
    if (tabId == null || !chrome.debugger) { sendResponse({ ok: false }); return false; }
    chrome.debugger
      .sendCommand({ tabId }, "Input.dispatchMouseEvent", { type: "mouseMoved", x: Number(msg.x), y: Number(msg.y) })
      .then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }
  if (msg?.action === "pilgrimTrustedTap") {
    const tabId = sender?.tab?.id;
    if (tabId == null) { sendResponse({ ok: false, error: "no tab" }); return false; }
    pilgrimTrustedTap(tabId, Number(msg.x), Number(msg.y)).then(sendResponse);
    return true;
  }
  if (msg?.action === "pilgrimTrustedKey") {
    const tabId = sender?.tab?.id;
    if (tabId == null) { sendResponse({ ok: false, error: "no tab" }); return false; }
    const key = String(msg.key || "Escape");
    const vk = { Escape: 27, Backspace: 8, Enter: 13, Tab: 9 }[key] || 0;
    withDbg(tabId, async (send) => {
      if (msg.selectAll) {
        await send("Input.dispatchKeyEvent", { type: "keyDown", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
        await send("Input.dispatchKeyEvent", { type: "keyUp", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
      }
      await send("Input.dispatchKeyEvent", { type: "keyDown", key, code: key, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
      await send("Input.dispatchKeyEvent", { type: "keyUp", key, code: key, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
    }).then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }
  if (msg?.action === "pilgrimTrustedType") {
    const tabId = sender?.tab?.id;
    if (tabId == null) { sendResponse({ ok: false, error: "no tab" }); return false; }
    pilgrimTrustedType(tabId, String(msg.text || "")).then(sendResponse);
    return true;
  }
  // Fired by content.js's scheduler loop the moment TTD's virtual-queue
  // interstitial appears/clears, and by popup.js's runWaitForSlot the
  // moment a watched slot opens up — both cases where the person is very
  // likely not looking at the tab. Best-effort, fire-and-forget: no
  // response is expected or sent.
  if (msg?.type === "PILGRIM_QUEUE_STATUS") {
    if (msg.state === "queued") {
      setBadge("Q", "#f59e0b");
    } else if (msg.state === "cleared") {
      setBadge("", null);
      notifyBg("✅ Queue cleared", "TTD's virtual queue cleared — the booking page should load next.");
    } else if (msg.state === "slot-found") {
      setBadge("!", "#16a34a");
      notifyBg("🎉 Slot opened up", msg.detail || "A watched slot became available.");
    }
    return false;
  }

  // Sent by popup.js's Settings panel any time the scheduled-tab queue is
  // added to/edited/deleted — reschedules every alarm from scratch rather
  // than diffing, since the whole queue is small and this only fires on
  // an explicit edit, not on any kind of loop.
  if (msg?.type === "PILGRIM_SYNC_TAB_QUEUE") {
    syncTabQueueAlarms(msg.queue).then(() => sendResponse({ ok: true })).catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }

  if (msg?.type === "PILGRIM_START_AUTO_PAY") {
    // popup.js always supplies msg.tabId (it has the tab object already
    // in hand). A content script triggering this itself — e.g. the
    // scheduler's own service-click/workflow hand-off, which runs with no
    // popup open at all — has no tabId to send, so fall back to the
    // sender's own tab, which chrome fills in automatically for any
    // message that came from a content script.
    const tabId = msg.tabId || sender?.tab?.id;
    if (!tabId) {
      sendResponse({ started: false, reason: "no tab id available" });
      return;
    }
    (async () => {
      try {
        // A visible, ON-PAGE checkpoint (not just this popup's toast, which
        // is about to disappear the moment the person stops looking at
        // it) confirming the message actually arrived here and the chain
        // is genuinely starting — several reports of "fills Pilgrim
        // Details, then nothing" turned out to be genuinely ambiguous
        // about whether this handler ever ran at all. If this message
        // itself doesn't show up on-page, the problem is upstream of
        // background.js entirely (popup.js's autoOn/count check, or the
        // message never arriving); if it DOES show up but nothing follows,
        // the problem is in click_continue or later.
        try {
          await chrome.scripting.executeScript({
            target: { tabId, allFrames: true },
            func: () => { window.__pilgrimDriveToken = (window.__pilgrimDriveToken || 0) + 1; }
          });
        } catch (_) {}
        await showStatus(tabId, msg.quick ? `⚡ Quick Book started — target ${QUICK_TARGET_SECONDS}s including the ${CVV_WINDOW_SECONDS}s CVV window` : "Auto Continue: starting…");
        await setSession(tabId, {
          useCard: !!msg.useCard,
          card: msg.card || null,
          payload: msg.payload || null,
          fillPayload: msg.fillPayload || null,
          quick: !!msg.quick,
          runId: Date.now() + "-" + Math.random().toString(36).slice(2, 8),
          step: msg.startStep || "drive",
          attempts: 0,
          startedAt: Date.now()
        });
        await advance(tabId);
        sendResponse({ started: true });
      } catch (err) {
        // This whole block used to have no try/catch at all — an
        // exception anywhere in here (setSession, advance, or anything
        // they call) became an unhandled rejection in the service worker
        // with nothing surfaced anywhere: no popup toast (long gone by
        // the time anything here even runs), no on-page status, nothing.
        // That is indistinguishable from the chain simply never having
        // started, which is exactly what "nothing happened" reports have
        // described. Now it's at least visible on the page.
        await showStatus(tabId, `⚠️ Auto Continue failed to start: ${err?.message || err}`, true);
        notifyBg("⚠️ Stopped at payment", `Auto Continue failed to start: ${err?.message || err}`);
        sendResponse({ started: false, reason: err?.message || String(err) });
      }
    })();
    return true; // keep the message channel open for the async response
  }
  return false;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status !== "complete") return;
  advance(tabId).catch(() => {});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  clearSession(tabId).catch(() => {});
});
