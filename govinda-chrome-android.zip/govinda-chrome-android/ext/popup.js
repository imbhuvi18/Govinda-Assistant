const MAX_PILGRIMS = 6;
const MAX_SRIVANI = 9;
const MAX_SEVA_MEMBERS = 10;
const STORAGE_KEY = "pilgrimAutofillData";

const ALL_TABS = [
  { key: "quick", label: "⚡ Quick Book (all services)" },
  { key: "pilgrims", label: "Special Entry Darshan (Sri PAT)" },
  { key: "sedPilgrims", label: "Special Entry Darshan (Tirumala)" },
  { key: "accommodation", label: "Accommodation" },
  { key: "angapradakshana", label: "Angapradakshana" },
  { key: "srivani", label: "Srivani" },
  { key: "srivariseva", label: "Srivari Seva" },
  { key: "sevagroup", label: "Seva (Group)" },
  { key: "contact", label: "Contact" }
];

function defaultTabVisibility() {
  return Object.fromEntries(ALL_TABS.map((t) => [t.key, true]));
}

let state = {
  theme: "light",
  quickPilgrims: [],
  pilgrims: [],
  sedPilgrims: [],
  angPilgrims: [],
  sriPilgrims: [],
  contact: {},
  srivariSeva: {},
  sevaLeader: {},
  sevaMembers: [],
  autoPay: true,
  timeSyncBooking: false,
  timeSyncTarget: "10:00:00",
  timeSyncAction: "reload",
  timeSyncService: "",
  // Matches content.js's SERVICE_INFO keys — lets the extension navigate
  // straight to a service's confirmed real URL instead of hunting for its
  // tile by on-screen text. "custom" falls back to the old free-typed
  // timeSyncService text + DOM-click matching, for anything not listed.
  serviceKey: "spat",
  cardAutofill: false,
  // Card number/expiry are only ever used to type them into the page's own
  // payment form on this device — never sent anywhere. CVV is intentionally
  // not part of this object at all: it's never collected or stored.
  card: { name: "", number: "", expiry: "" },
  // Each service tab that has its own booking calendar keeps its own
  // date/slot/ticket-count — the calendar's ticket-count/slot pickers
  // don't exist until a date's been picked, so this drives a pre-step
  // (see content.js's selectDateSlot) rather than being just another
  // field to fill alongside pilgrims/contact. Angapradakshinam gets one
  // too even though it never auto-continues past Pilgrim Details — the
  // date/slot/ticket step and its own Continue click still happen
  // automatically, same as every other tab (see GROUPS below).
  quickDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "" },
  dateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "" },
  sedDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "" },
  angDateSlot: { date: "", slot: "", ticketCount: "" },
  // Accommodation is a separate multi-step TTD flow.
  accommodation: {
    location: "",
    service: "",
    checkInSlot: "",
    noOfPilgrims: "2",
    date: "",
    roomPrice: "100",
    pilgrimSelectCount: "2",
    contact: { email: "", city: "", state: "", country: "", pincode: "" }
  },
  tabVisibility: defaultTabVisibility(),
  // Reliability / power-user additions:
  dryRunMode: false, // highlight-only preview, no typing/clicking/submitting
  profiles: [], // saved reusable pilgrim entries: { id, label, name, age, gender, idType, idNumber }
  activityLog: [], // last N fill attempts, newest first: { id, time, label, filledCount, missed, error }
  pageSignatures: {}, // per-page "field counts last seen", for the layout-change detector
  cardLockHash: "", // SHA-256 hex of the card-form passphrase, if one's set (empty = no lock)
  tabQueue: [] // scheduled-tab-opener entries: { id, label, url, time }
};

const MAX_ACTIVITY_LOG = 30;

// Pilgrim-list groups share the same card UI/logic: "Special Entry Darshan
// (Sri PAT)" and "(Tirumala)" (both Continue → PhonePe/Card → Pay Now,
// auto-continue on by default), "Angapradakshana" (autofills date/slot/
// tickets + Continue + Pilgrim Details, then stops — Continue and Book Now
// after that stay manual on TTD's own page), and "Srivani" (same fields, up
// to 9 people, no auto-continue chain at all). Keeping them data-driven
// avoids duplicating every
// render/add/remove/fill handler below.
const GROUPS = [
  // ONE flow for every service: Fill All → date/slot/tickets → Continue → pilgrims + contact → Continue
  // → whatever final button the page shows (Continue / Book Now / Pay Now) → Card → card details →
  // 10s CVV window → Pay. Runs entirely in the background worker (see background.js, quick session).
  { key: "quickPilgrims", listSel: "#quickPilgrimList", addBtnSel: "#quickAddPilgrimBtn", fillBtnSel: "#quickFillAllBtn", mode: "auto", max: MAX_PILGRIMS, dateSlotKey: "quickDateSlot", dsPrefix: "quick" },
  { key: "pilgrims", listSel: "#pilgrimList", addBtnSel: "#addPilgrimBtn", fillBtnSel: "#fillAllBtn", waitBtnSel: "#waitForSlotBtn", mode: "pay", max: MAX_PILGRIMS, dateSlotKey: "dateSlot", dsPrefix: "" },
  { key: "sedPilgrims", listSel: "#sedPilgrimList", addBtnSel: "#sedAddPilgrimBtn", fillBtnSel: "#sedFillAllBtn", waitBtnSel: "#sedWaitForSlotBtn", mode: "pay", max: MAX_PILGRIMS, dateSlotKey: "sedDateSlot", dsPrefix: "sed" },
  // "book": once Pilgrim Details are filled, Angapradakshinam gets the
  // same one-Continue-then-Book-Now chase as Special Entry Darshan gets
  // Continue-then-Pay-Now — see __pilgrimAutoContinueBook. Unlike the
  // "pay" tabs this isn't gated behind a toggle at all (see runFill's
  // autoOn below): there's no payment step to be cautious about here, so
  // it always fires once fields are actually filled.
  { key: "angPilgrims", listSel: "#angPilgrimList", addBtnSel: "#angAddPilgrimBtn", fillBtnSel: "#angFillAllBtn", waitBtnSel: "#angWaitForSlotBtn", mode: "book", max: MAX_PILGRIMS, dateSlotKey: "angDateSlot", dsPrefix: "ang" },
  // "pay", not "none": Srivani and other Arjitha-Seva-style bookings
  // (including the ones without their own dedicated tab, like the Homam —
  // this tab's generic field-matching fills those pilgrim details fine
  // too) do have a real payment step, so they get the same Continue →
  // Pay Now chase as Special Entry Darshan once Pilgrim Details are
  // filled — driven by the same state.autoPay / cardAutofill toggle
  // shown on the Pilgrim Booking tab (see runFill's autoOn below).
  { key: "sriPilgrims", listSel: "#sriPilgrimList", addBtnSel: "#sriAddPilgrimBtn", fillBtnSel: "#sriFillAllBtn", mode: "pay", max: MAX_SRIVANI }
];

const el = (sel, root = document) => root.querySelector(sel);
const els = (sel, root = document) => [...root.querySelectorAll(sel)];

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function digitsOnly(v) {
  return String(v || "").replace(/\D/g, "");
}

// ---------- pre-submit validation ----------
// Flags obviously-bad data BEFORE Fill All Details is even sent to the
// page, so a typo (an extra digit in Aadhaar, a stray letter in Age)
// doesn't burn a real queue slot on a booking TTD would reject anyway.
// Only checks fields that are actually filled in — leaving something
// blank is never flagged here, only a value that looks wrong.
function validatePilgrim(p, idx) {
  const problems = [];
  const label = `Pilgrim ${idx + 1}`;
  if (p.age !== "" && p.age !== undefined && p.age !== null) {
    const age = Number(p.age);
    if (!Number.isFinite(age) || age < 1 || age > 120) {
      problems.push(`${label}: age "${p.age}" looks out of range (1–120)`);
    }
  }
  if (p.idNumber) {
    const digits = digitsOnly(p.idNumber);
    if ((p.idType || "Aadhaar") === "Aadhaar" && digits.length !== 12) {
      problems.push(`${label}: Aadhaar number should be 12 digits (got ${digits.length})`);
    }
  }
  return problems;
}

function validateContact(contact) {
  const problems = [];
  if (contact?.pincode) {
    const digits = digitsOnly(contact.pincode);
    if (digits.length !== 6) problems.push(`Contact: pincode should be 6 digits (got ${digits.length})`);
  }
  return problems;
}

function validatePersonLike(person, label) {
  const problems = [];
  if (person.mobile) {
    const digits = digitsOnly(person.mobile);
    if (digits.length !== 10) problems.push(`${label}: mobile number should be 10 digits (got ${digits.length})`);
  }
  if (person.pincode) {
    const digits = digitsOnly(person.pincode);
    if (digits.length !== 6) problems.push(`${label}: pincode should be 6 digits (got ${digits.length})`);
  }
  if (person.idNumber && (person.idType || "Aadhaar") === "Aadhaar") {
    const digits = digitsOnly(person.idNumber);
    if (digits.length !== 12) problems.push(`${label}: Aadhaar number should be 12 digits (got ${digits.length})`);
  }
  if (person.age !== undefined && person.age !== "" && person.age !== null) {
    const age = Number(person.age);
    if (!Number.isFinite(age) || age < 1 || age > 120) {
      problems.push(`${label}: age "${person.age}" looks out of range (1–120)`);
    }
  }
  return problems;
}

// ---------- desktop notifications ----------
// Best-effort — chrome.notifications may be unavailable/blocked at the OS
// level; a failed notification should never interrupt the actual flow.
function notify(title, message) {
  try {
    chrome.notifications?.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message: message || ""
    });
  } catch (err) {
    // Non-fatal — the on-page/toast status already carries the real signal.
  }
}

// ---------- activity log (last N fill attempts, for on-demand diagnosis) ----------
function logActivity(entry) {
  state.activityLog = state.activityLog || [];
  state.activityLog.unshift({ id: uid(), time: Date.now(), ...entry });
  if (state.activityLog.length > MAX_ACTIVITY_LOG) state.activityLog.length = MAX_ACTIVITY_LOG;
  save();
  renderActivityLog();
}

function renderActivityLog() {
  const list = el("#activityLogList");
  if (!list) return;
  const entries = state.activityLog || [];
  if (!entries.length) {
    list.innerHTML = '<p class="hint" style="margin:0;">No fill attempts logged yet.</p>';
    return;
  }
  list.innerHTML = entries
    .map((e) => {
      const t = new Date(e.time).toLocaleString();
      let status;
      if (e.error) status = `⚠️ ${e.error}`;
      else {
        const count = e.filledCount ?? 0;
        status = `Filled ${count} field(s)`;
        // Field NAMES only — never values — a masked, non-PII audit trail
        // of which categories of data actually went onto the page.
        if (e.filledKeys?.length) status += ` (${e.filledKeys.join(", ")})`;
        if (e.missed?.length) status += ` — missed: ${e.missed.join("; ")}`;
        if (e.confirmationRef) status += ` — ref: ${e.confirmationRef}`;
      }
      return `<div class="activity-entry"><div class="activity-time">${escapeHtml(t)} · ${escapeHtml(e.label || "")}</div><div class="activity-detail">${escapeHtml(status)}</div></div>`;
    })
    .join("");
}

// ---------- saved pilgrim profiles ----------
function renderProfileList() {
  const list = el("#profileList");
  if (!list) return;
  const profiles = state.profiles || [];
  if (!profiles.length) {
    list.innerHTML = '<p class="hint" style="margin:0;">No saved profiles yet — use on a pilgrim card to add one.</p>';
    return;
  }
  list.innerHTML = "";
  profiles.forEach((prof) => {
    const row = document.createElement("div");
    row.className = "tab-visibility-row";
    const span = document.createElement("span");
    span.textContent = `${prof.label || prof.name || "Unnamed"} (${prof.age || "?"}, ${prof.gender || "?"})`;
    row.appendChild(span);
    const del = document.createElement("button");
    del.className = "link-btn";
    del.textContent = "Remove";
    del.title = "Delete this profile";
    del.addEventListener("click", () => {
      state.profiles = (state.profiles || []).filter((x) => x.id !== prof.id);
      save();
      renderProfileList();
      refreshProfileSelects();
    });
    row.appendChild(del);
    list.appendChild(row);
  });
}

function profileSelectOptionsHtml(selectedId) {
  const profiles = state.profiles || [];
  return (
    '<option value="">Load profile…</option>' +
    profiles
      .map((p) => `<option value="${p.id}"${p.id === selectedId ? " selected" : ""}>${escapeHtml(p.label || p.name || "Unnamed")}</option>`)
      .join("")
  );
}

function refreshProfileSelects() {
  els(".profile-select").forEach((sel) => {
    sel.innerHTML = profileSelectOptionsHtml(sel.value);
  });
}

function showToast(msg) {
  const t = el("#toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(showToast._timer);
  // Longer messages (e.g. diagnostic detail) need more time to read.
  const duration = Math.min(9000, Math.max(2200, msg.length * 60));
  showToast._timer = setTimeout(() => (t.hidden = true), duration);
}

// ---------- storage ----------
function load() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
      const saved = res[STORAGE_KEY];
      if (saved) {
        state = {
          theme: "light",
          quickPilgrims: [],
          pilgrims: [],
          sedPilgrims: [],
          angPilgrims: [],
          sriPilgrims: [],
          contact: {},
          srivariSeva: {},
          sevaLeader: {},
          sevaMembers: [],
          autoPay: true,
          timeSyncBooking: false,
          timeSyncTarget: "10:00:00",
          timeSyncAction: "reload",
          timeSyncService: "",
          serviceKey: "spat",
          cardAutofill: false,
          card: { name: "", number: "", expiry: "" },
          quickDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "" },
          dateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "" },
          sedDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "" },
          angDateSlot: { date: "", slot: "", ticketCount: "" },
          accommodation: {
            location: "", service: "", checkInSlot: "", noOfPilgrims: "2", date: "", roomPrice: "100", pilgrimSelectCount: "2",
            contact: { email: "", city: "", state: "", country: "", pincode: "" }
          },
          tabVisibility: defaultTabVisibility(),
          dryRunMode: false,
          profiles: [],
          activityLog: [],
          pageSignatures: {},
          cardLockHash: "",
          tabQueue: [],
          ...saved,
          card: { name: "", number: "", expiry: "", ...(saved.card || {}) },
          quickDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "", ...(saved.quickDateSlot || {}) },
          dateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "", ...(saved.dateSlot || {}) },
          sedDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "", ...(saved.sedDateSlot || {}) },
          angDateSlot: { date: "", slot: "", ticketCount: "", ...(saved.angDateSlot || {}) },
          accommodation: {
            location: "", service: "", checkInSlot: "", noOfPilgrims: "2", date: "", roomPrice: "100", pilgrimSelectCount: "2",
            ...(saved.accommodation || {}),
            contact: { email: "", city: "", state: "", country: "", pincode: "", ...((saved.accommodation || {}).contact || {}) }
          },
          tabVisibility: { ...defaultTabVisibility(), ...(saved.tabVisibility || {}) },
          profiles: Array.isArray(saved.profiles) ? saved.profiles : [],
          activityLog: Array.isArray(saved.activityLog) ? saved.activityLog : [],
          pageSignatures: (saved.pageSignatures && typeof saved.pageSignatures === "object") ? saved.pageSignatures : {},
          tabQueue: Array.isArray(saved.tabQueue) ? saved.tabQueue : []
        };
        // A damaged/hand-edited value must not break every render below.
        for (const k of ["quickPilgrims", "pilgrims", "sedPilgrims", "angPilgrims", "sriPilgrims", "sevaMembers"]) {
          if (!Array.isArray(state[k])) state[k] = [];
        }
        // Queue entries stay in state after their alarm fires; drop ones that
        // are more than a day old so the list doesn't grow forever.
        state.tabQueue = state.tabQueue.filter((e) => { const t = Date.parse(e && e.time); return !Number.isFinite(t) || t > Date.now() - 24 * 3600 * 1000; });
      }
      resolve();
    });
  });
}

let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    chrome.storage.local.set({ [STORAGE_KEY]: state });
  }, 250); // debounced
}

// ---------- Layover (desktop window) ----------
// "Layover" opens the exact same extension UI in a full browser tab/window
// instead of the small popup — no different booking logic, just a layout
// that isn't squeezed into the 360px popup width. popup.html?layout=desktop
// is what tells this same page to render itself with the wider CSS.
(function initLayoverMode() {
  const params = new URLSearchParams(location.search);
  if (params.get("layout") === "desktop") {
    document.body.dataset.layout = "desktop";
  }
})();

const layoverBtn = el("#layoverToggle");
if (layoverBtn) {
  if (document.body.dataset.layout === "desktop") {
    // Already in the desktop window — the button would just open a
    // duplicate of itself, so hide it instead.
    layoverBtn.hidden = true;
  } else {
    layoverBtn.addEventListener("click", () => {
      const url = chrome.runtime.getURL("popup.html") + "?layout=desktop";
      chrome.windows.create({ url, type: "popup", width: 1000, height: 780 });
    });
  }
}

// ---------- theme ----------
function applyTheme() {
  document.body.dataset.theme = state.theme;
}

el("#themeToggle").addEventListener("click", () => {
  state.theme = state.theme === "dark" ? "light" : "dark";
  applyTheme();
  save();
});

// ---------- panic-stop ----------
// A single in-memory flag (never persisted — always false on a fresh
// popup open) that the Wait for Slot polling loop checks between every
// attempt. Deliberately NOT wired into runAutoContinuePay/Book or the
// card-payment chain in background.js — those are short, bounded
// sequences (a handful of clicks) rather than an open-ended loop, and
// the countdown overlay's own Cancel button already covers stopping the
// one truly irreversible click (Pay Now/Proceed/Book Now) in those.
let stopRequested = false;

el("#stopBtn")?.addEventListener("click", () => {
  stopRequested = true;
  showToast("🛑 Stop requested — any in-progress Wait for Slot will end on its next check");
});

// ---------- scheduled tab queue ----------
function syncTabQueueAlarms() {
  try {
    Promise.resolve(chrome.runtime.sendMessage({ type: "PILGRIM_SYNC_TAB_QUEUE", queue: state.tabQueue || [] })).catch(() => {});
  } catch (_) {
    // Best-effort — the queue is still saved in state either way; this
    // just means background.js's alarms won't be (re)scheduled until the
    // next successful sync.
  }
}

function renderTabQueue() {
  const list = el("#tabQueueList");
  if (!list) return;
  const queue = state.tabQueue || [];
  if (!queue.length) {
    list.innerHTML = '<p class="hint" style="margin:0;">No scheduled tabs queued.</p>';
    return;
  }
  list.innerHTML = "";
  [...queue]
    .sort((a, b) => new Date(a.time) - new Date(b.time))
    .forEach((entry) => {
      const row = document.createElement("div");
      row.className = "tab-visibility-row";
      const span = document.createElement("span");
      const when = entry.time ? new Date(entry.time).toLocaleString() : "?";
      const past = entry.time && new Date(entry.time).getTime() <= Date.now();
      span.textContent = `${entry.label || entry.url} — ${when}${past ? " (past)" : ""}`;
      row.appendChild(span);
      const del = document.createElement("button");
      del.className = "link-btn";
      del.textContent = "Remove";
      del.title = "Remove from queue";
      del.addEventListener("click", () => {
        state.tabQueue = (state.tabQueue || []).filter((x) => x.id !== entry.id);
        save();
        renderTabQueue();
        syncTabQueueAlarms();
      });
      row.appendChild(del);
      list.appendChild(row);
    });
}

el("#addQueueBtn")?.addEventListener("click", () => {
  const labelInput = el("#newQueueLabel");
  const urlInput = el("#newQueueUrl");
  const timeInput = el("#newQueueTime");
  const label = (labelInput?.value || "").trim();
  const url = (urlInput?.value || "").trim();
  const time = timeInput?.value;
  if (!url || !time) {
    showToast("A URL and a time are both required");
    return;
  }
  try {
    new URL(url);
  } catch (_) {
    showToast("That doesn't look like a valid URL");
    return;
  }
  const iso = new Date(time).toISOString();
  if (new Date(iso).getTime() <= Date.now()) {
    showToast("Pick a time in the future");
    return;
  }
  state.tabQueue = state.tabQueue || [];
  state.tabQueue.push({ id: uid(), label: label || url, url, time: iso });
  save();
  labelInput.value = "";
  urlInput.value = "";
  timeInput.value = "";
  renderTabQueue();
  syncTabQueueAlarms();
  showToast(`Queued "${label || url}" for ${new Date(iso).toLocaleString()}`);
});

// ---------- card-form passphrase lock ----------
// A separate local passphrase gating the saved card fields specifically.
// The hash lives in synced state; whether it's UNLOCKED does not — that
// resets to locked every time the popup is freshly opened, on purpose.
async function sha256Hex(text) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

let cardUnlockedThisSession = false;

function applyCardLockUI() {
  const gate = el("#cardLockGate");
  const inner = el("#cardFieldsInner");
  if (!gate || !inner) return;
  const locked = !!state.cardLockHash && !cardUnlockedThisSession;
  gate.hidden = !locked;
  inner.hidden = locked;
}

el("#cardUnlockBtn")?.addEventListener("click", async () => {
  const input = el("#cardLockPassInput");
  const hash = await sha256Hex(input?.value || "");
  if (hash === state.cardLockHash) {
    cardUnlockedThisSession = true;
    if (input) input.value = "";
    applyCardLockUI();
  } else {
    showToast("⚠️ Wrong passphrase");
  }
});

el("#setCardLockBtn")?.addEventListener("click", async () => {
  const input = el("#cardLockPassSet");
  const pass = input?.value || "";
  if (!pass) {
    showToast("Type a passphrase first");
    return;
  }
  state.cardLockHash = await sha256Hex(pass);
  save();
  cardUnlockedThisSession = true;
  if (input) input.value = "";
  applyCardLockUI();
  showToast("Card lock set — you'll need this passphrase next time the popup opens");
});

el("#removeCardLockBtn")?.addEventListener("click", () => {
  if (!state.cardLockHash) {
    showToast("No card lock is set");
    return;
  }
  if (!confirm("Remove the card-lock passphrase? The saved card fields will be visible/editable without it from now on.")) return;
  state.cardLockHash = "";
  save();
  cardUnlockedThisSession = false;
  applyCardLockUI();
  showToast("Removed card lock");
});

// ---------- settings panel (show/hide tabs) ----------
el("#settingsToggle").addEventListener("click", () => {
  const panel = el("#settingsPanel");
  panel.hidden = !panel.hidden;
});

// ---------- activity log panel ----------
el("#activityLogToggle")?.addEventListener("click", () => {
  const panel = el("#activityLogPanel");
  panel.hidden = !panel.hidden;
  if (!panel.hidden) renderActivityLog();
});

el("#clearActivityLogBtn")?.addEventListener("click", () => {
  state.activityLog = [];
  save();
  renderActivityLog();
});

// ---------- dry-run mode ----------
el("#dryRunToggle")?.addEventListener("change", (e) => {
  state.dryRunMode = e.target.checked;
  save();
  showToast(state.dryRunMode
    ? "Dry run is on — fills will only highlight fields, nothing is submitted"
    : "Dry run is off — fills behave normally");
});

// ---------- export / import settings ----------
el("#exportSettingsBtn")?.addEventListener("click", () => {
  try {
    // The backup is a plain, unencrypted file, so saved card details and the
    // card-lock hash are left out of it. (CVV is never stored at all.)
    const safe = { ...state, card: { name: "", number: "", expiry: "" } };
    delete safe.cardLockHash;
    const blob = new Blob([JSON.stringify(safe, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `govinda-assistant-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    showToast("Exported settings (saved card details are not included)");
  } catch (err) {
    showToast(`⚠️ Export failed: ${err?.message || err}`);
  }
});

el("#importSettingsBtn")?.addEventListener("click", () => el("#importSettingsFile")?.click());

el("#importSettingsFile")?.addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  e.target.value = "";
  if (!file) return;
  try {
    const text = await file.text();
    const incoming = JSON.parse(text);
    if (!incoming || typeof incoming !== "object") throw new Error("not a valid backup file");
    // A hand-edited file could in theory include a "cvv" key under card —
    // this extension has never asked for or stored one, so refuse to
    // import it even if present.
    if (incoming.card && typeof incoming.card === "object") delete incoming.card.cvv;
    // A backup must not be able to replace the lock, and a backup without a
    // card section must not erase the card already saved on this device.
    delete incoming.cardLockHash;
    const keepCard = state.card;
    // Only take the backup's card if it really contains something; the export
    // writes an empty card object, which must not overwrite the saved one.
    const hasCardData = !!(incoming.card && typeof incoming.card === "object" &&
      (incoming.card.name || incoming.card.number || incoming.card.expiry));
    const asList = (v) => (Array.isArray(v) ? v : []);
    state = {
      ...state,
      ...incoming,
      quickPilgrims: asList(incoming.quickPilgrims ?? state.quickPilgrims),
      pilgrims: asList(incoming.pilgrims ?? state.pilgrims),
      sedPilgrims: asList(incoming.sedPilgrims ?? state.sedPilgrims),
      angPilgrims: asList(incoming.angPilgrims ?? state.angPilgrims),
      sriPilgrims: asList(incoming.sriPilgrims ?? state.sriPilgrims),
      sevaMembers: asList(incoming.sevaMembers ?? state.sevaMembers),
      card: { name: "", number: "", expiry: "", ...(hasCardData ? incoming.card : keepCard) },
      quickDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "", ...(incoming.quickDateSlot || {}) },
      dateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "", ...(incoming.dateSlot || {}) },
      sedDateSlot: { date: "", slot: "", ticketCount: "", additionalLaddus: "", hundiOffering: "", ...(incoming.sedDateSlot || {}) },
      angDateSlot: { date: "", slot: "", ticketCount: "", ...(incoming.angDateSlot || {}) },
      accommodation: {
        location: "", service: "", checkInSlot: "", noOfPilgrims: "2", date: "", roomPrice: "100", pilgrimSelectCount: "2",
        ...(incoming.accommodation || {}),
        contact: { email: "", city: "", state: "", country: "", pincode: "", ...((incoming.accommodation || {}).contact || {}) }
      },
      tabVisibility: { ...defaultTabVisibility(), ...(incoming.tabVisibility || {}) },
      profiles: Array.isArray(incoming.profiles) ? incoming.profiles : [],
      activityLog: Array.isArray(incoming.activityLog) ? incoming.activityLog : [],
      pageSignatures: (incoming.pageSignatures && typeof incoming.pageSignatures === "object") ? incoming.pageSignatures : {},
      tabQueue: Array.isArray(incoming.tabQueue) ? incoming.tabQueue : []
    };
    saveNow();
    applyTheme();
    renderContact();
    renderAccommodation();
    renderSrivariSeva();
    renderAllGroups();
    renderSevaLeader();
    renderSevaMembers();
    renderTabVisibilityList();
    applyTabVisibility();
    renderProfileList();
    refreshProfileSelects();
    renderActivityLog();
    renderTabQueue();
    syncTabQueueAlarms();
    el("#dryRunToggle").checked = !!state.dryRunMode;
    el("#autoPayToggle").checked = !!state.autoPay;
    el("#cardAutofillToggle").checked = !!state.cardAutofill;
    el("#cardFormWrap").hidden = !state.cardAutofill;
    renderCardForm();
    applyCardLockUI();
    renderAllDateSlots();
    showToast("✅ Settings imported");
  } catch (err) {
    showToast(`⚠️ Import failed: ${err?.message || err}`);
  }
});

function renderTabVisibilityList() {
  const list = el("#tabVisibilityList");
  list.innerHTML = "";
  ALL_TABS.forEach((tab) => {
    const row = document.createElement("label");
    row.className = "tab-visibility-row";
    const labelText = document.createElement("span");
    labelText.textContent = tab.label;
    row.appendChild(labelText);
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = state.tabVisibility[tab.key] !== false;
    input.addEventListener("change", () => {
      state.tabVisibility[tab.key] = input.checked;
      save();
      applyTabVisibility();
    });
    row.appendChild(input);
    list.appendChild(row);
  });
}

function applyTabVisibility() {
  let activeStillVisible = false;
  els(".tab-btn").forEach((btn) => {
    const key = btn.dataset.tab;
    const visible = state.tabVisibility[key] !== false;
    btn.classList.toggle("hidden-tab", !visible);
    if (visible && btn.classList.contains("active")) activeStillVisible = true;
  });
  if (!activeStillVisible) {
    // The tab that was active just got hidden — fall back to the first
    // remaining visible tab so the panel area is never left blank.
    const firstVisible = els(".tab-btn").find((b) => !b.classList.contains("hidden-tab"));
    if (firstVisible) firstVisible.click();
  }
}

el("#resetTabsBtn").addEventListener("click", () => {
  state.tabVisibility = defaultTabVisibility();
  save();
  renderTabVisibilityList();
  applyTabVisibility();
});

// ---------- auto-pay / auto-book toggles ----------
el("#autoPayToggle").addEventListener("change", (e) => {
  state.autoPay = e.target.checked;
  save();
});

function normalizeTime(value) {
  const m = String(value || "").match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (!m) return "10:00:00";
  const h = Number(m[1]), min = Number(m[2]), sec = Number(m[3] || 0);
  if (h > 23 || min > 59 || sec > 59) return "10:00:00";
  return `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

const SERVICE_OPTIONS = [
  { key: "spat", label: "Special Entry Darshan (Ammavari Temple)" },
  { key: "sed", label: "Special Entry Darshan" },
  { key: "apd", label: "Angapradakshinam" },
  { key: "srivari-seva", label: "Srivari Seva" },
  { key: "homam", label: "Sri Srinivasa Divyanugraha Homam" },
  { key: "custom", label: "Other (type the exact tile text below)" }
];

function updateTimeSyncServiceDisplay() {
  const select = el("#timeSyncServiceSelect");
  if (select) select.value = state.serviceKey || "spat";
  const customWrap = el("#timeSyncCustomWrap");
  if (customWrap) customWrap.hidden = (state.serviceKey || "spat") !== "custom";
  const field = el("#timeSyncService");
  if (field) field.value = state.timeSyncService || "";
}

function updateTimeSyncDisplay() {
  const current = el("#timeSyncCurrent");
  if (current) current.textContent = `Selected: ${state.timeSyncTarget || "10:00:00"} IST`;
}

function saveNow() {
  clearTimeout(saveTimer);
  chrome.storage.local.set({ [STORAGE_KEY]: state });
}

el("#timeSyncBookingToggle").addEventListener("change", (e) => {
  state.timeSyncBooking = e.target.checked;
  el("#timeSyncSettings").hidden = !e.target.checked;
  saveNow();
});

el("#timeSyncTarget").addEventListener("change", (e) => {
  state.timeSyncTarget = normalizeTime(e.target.value);
  e.target.value = state.timeSyncTarget;
  updateTimeSyncDisplay();
  updateTimeSyncServiceDisplay();
  saveNow();
});

el("#setTimeSyncBtn").addEventListener("click", async () => {
  state.timeSyncTarget = normalizeTime(el("#timeSyncTarget").value);
  state.timeSyncBooking = true;
  el("#timeSyncBookingToggle").checked = true;
  el("#timeSyncSettings").hidden = false;
  el("#timeSyncTarget").value = state.timeSyncTarget;
  updateTimeSyncDisplay();
  saveNow();
  showToast(`TTD sync time set to ${state.timeSyncTarget} IST`);

  // "Reload" / "Reload + workflow" / "Click booking button" all assume
  // you're already sitting on the real Darshan Slots page they'll act on
  // — only "Click selected service" is meant to be armed from elsewhere
  // (e.g. the homepage) to launch a named service. Catch the common
  // mix-up here, right when arming, instead of only failing silently
  // later once the target time actually arrives.
  const action = state.timeSyncAction || "reload";
  if (action !== "service-click") {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const url = (tab?.url || "").toLowerCase();
      const looksRight = /slot-booking|pilgrim-details|flow=sed|flow=spat/.test(url);
      if (tab?.url && !looksRight) {
        showToast(
          "⚠️ This tab doesn't look like the Darshan Slots booking page yet — navigate there first, then arm this mode from that page."
        );
      }
    } catch {
      // Best-effort check only — if it fails, the on-page warning from
      // content.js still catches it once the target time is reached.
    }
  }
});

el("#timeSyncServiceSelect")?.addEventListener("change", (e) => {
  state.serviceKey = SERVICE_OPTIONS.some((o) => o.key === e.target.value) ? e.target.value : "spat";
  // Keep timeSyncService (the display/DOM-click-match name) in sync too —
  // it's what serviceRetryKey() and status messages use, and it's also
  // exactly what "custom" mode still relies on for its own DOM matching.
  const opt = SERVICE_OPTIONS.find((o) => o.key === state.serviceKey);
  if (state.serviceKey !== "custom") state.timeSyncService = opt?.label || "";
  updateTimeSyncServiceDisplay();
  saveNow();
});

el("#timeSyncService")?.addEventListener("input", (e) => {
  state.timeSyncService = e.target.value.trim();
  saveNow();
});

el("#timeSyncAction")?.addEventListener("change", (e) => {
  state.timeSyncAction = ["reload", "workflow", "click", "service-click"].includes(e.target.value) ? e.target.value : "reload";
  saveNow();
  showToast(state.timeSyncAction === "reload"
    ? "TTD page will reload at the selected server time."
    : state.timeSyncAction === "workflow"
      ? "TTD page will reload, select your saved date/slot/tickets, and fill pilgrim details at the selected server time."
      : "The selected service will be clicked at the synchronized TTD release time; if TTD still shows its release notice, the extension will use bounded refresh/recheck until the notice clears.");
});

// ---------- saved debit card (name / number / expiry only — never CVV) ----------
el("#cardAutofillToggle").addEventListener("change", (e) => {
  state.cardAutofill = e.target.checked;
  el("#cardFormWrap").hidden = !e.target.checked;
  save();
});

function renderCardForm() {
  el("#cardName").value = state.card.name || "";
  el("#cardNumber").value = state.card.number || "";
  el("#cardExpiry").value = state.card.expiry || "";
}

el("#cardName").addEventListener("input", (e) => {
  state.card.name = e.target.value;
  save();
});

// Light formatting only (grouped digits) — the stored value keeps spaces
// out so it matches plainly against whatever format the page field wants.
el("#cardNumber").addEventListener("input", (e) => {
  const digits = e.target.value.replace(/\D/g, "").slice(0, 16);
  const grouped = digits.replace(/(.{4})/g, "$1 ").trim();
  e.target.value = grouped;
  state.card.number = digits;
  save();
});

el("#cardExpiry").addEventListener("input", (e) => {
  let digits = e.target.value.replace(/\D/g, "").slice(0, 4);
  if (digits.length >= 3) digits = `${digits.slice(0, 2)}/${digits.slice(2)}`;
  e.target.value = digits;
  state.card.expiry = digits;
  save();
});

// ---------- preferred date / slot / ticket count (per service tab) ----------
// Optional — Fill All Details only attempts calendar selection when a date
// is actually set (see runFill below); leaving these blank keeps the
// previous plain-fill behavior exactly as before. Driven off GROUPS'
// dateSlotKey/dsPrefix so each service tab (Sri PAT, Tirumala, Angapradakshinam)
// gets its own independent date/slot/ticket fields from one piece of code
// instead of three near-identical hand-copied blocks.
const DATE_SLOT_GROUPS = GROUPS.filter((g) => g.dateSlotKey);

function dateSlotIds(group) {
  const p = group.dsPrefix;
  return p
    ? { date: `#${p}PreferredDate`, slot: `#${p}PreferredSlot`, count: `#${p}TicketCount`, laddus: `#${p}AdditionalLaddus`, hundi: `#${p}HundiOffering` }
    : { date: "#preferredDate", slot: "#preferredSlot", count: "#ticketCount", laddus: "#additionalLaddus", hundi: "#hundiOffering" };
}

function renderAllDateSlots() {
  for (const group of DATE_SLOT_GROUPS) {
    const ids = dateSlotIds(group);
    const ds = state[group.dateSlotKey];
    if (el(ids.date)) el(ids.date).value = ds.date || "";
    if (el(ids.slot)) el(ids.slot).value = ds.slot || "";
    if (el(ids.count)) el(ids.count).value = ds.ticketCount || "";
    if (el(ids.laddus)) el(ids.laddus).value = ds.additionalLaddus || "";
    if (el(ids.hundi)) el(ids.hundi).value = ds.hundiOffering || "";
  }
}

for (const group of DATE_SLOT_GROUPS) {
  const ids = dateSlotIds(group);
  el(ids.date)?.addEventListener("input", (e) => {
    state[group.dateSlotKey].date = e.target.value;
    save();
  });
  el(ids.slot)?.addEventListener("input", (e) => {
    state[group.dateSlotKey].slot = e.target.value;
    save();
  });
  el(ids.count)?.addEventListener("change", (e) => {
    state[group.dateSlotKey].ticketCount = e.target.value;
    save();
  });
  // Optional, page-level "Additional Services" — confirmed against a real
  // recording of the Tirumala (flow=sed) booking page specifically; not
  // wired up for Angapradakshanam, which doesn't have this section.
  el(ids.laddus)?.addEventListener("input", (e) => {
    state[group.dateSlotKey].additionalLaddus = e.target.value;
    save();
  });
  el(ids.hundi)?.addEventListener("input", (e) => {
    state[group.dateSlotKey].hundiOffering = e.target.value;
    save();
  });
}

// ---------- tabs ----------
els(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    els(".tab-btn").forEach((b) => b.classList.remove("active"));
    els(".tab-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    el(`#tab-${btn.dataset.tab}`).classList.add("active");
  });
});

// ---------- contact form ----------
function renderContact() {
  const form = el("#contactForm");
  for (const [key, val] of Object.entries(state.contact)) {
    const input = form.elements[key];
    if (input) input.value = val;
  }
}

el("#contactForm").addEventListener("input", (e) => {
  const { name, value } = e.target;
  if (!name) return;
  state.contact[name] = value;
  save();
});

// ---------- Accommodation form ----------
const ACCOMMODATION_CONTACT_FIELD_MAP = {
  accEmail: "email", accCity: "city", accState: "state", accCountry: "country", accPincode: "pincode"
};
function renderAccommodation() {
  const form = el("#accommodationForm");
  if (!form) return;
  for (const [key, val] of Object.entries(state.accommodation || {})) {
    if (key === "contact") continue;
    const input = form.elements[key];
    if (input) input.value = val;
  }
  for (const [fieldName, contactKey] of Object.entries(ACCOMMODATION_CONTACT_FIELD_MAP)) {
    const input = form.elements[fieldName];
    if (input) input.value = state.accommodation?.contact?.[contactKey] || "";
  }
}
el("#accommodationForm")?.addEventListener("input", (e) => {
  const { name, value } = e.target;
  if (!name) return;
  if (name in ACCOMMODATION_CONTACT_FIELD_MAP) state.accommodation.contact[ACCOMMODATION_CONTACT_FIELD_MAP[name]] = value;
  else state.accommodation[name] = value;
  save();
});
el("#runAccommodationBtn")?.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) { showToast("Couldn't find the active tab"); return; }
  showToast("Running Accommodation flow — watch the page…");
  await runAccommodationFlow(tab.id);
});

// ---------- Srivari Seva form (single profile) ----------
function renderSrivariSeva() {
  const form = el("#srivariSevaForm");
  for (const [key, val] of Object.entries(state.srivariSeva)) {
    const input = form.elements[key];
    if (!input) continue;
    if (input.type === "checkbox") input.checked = !!val;
    else input.value = val;
  }
}

el("#srivariSevaForm").addEventListener("input", (e) => {
  const { name, type, value, checked } = e.target;
  if (!name) return;
  state.srivariSeva[name] = type === "checkbox" ? checked : value;
  save();
});
el("#srivariSevaForm").addEventListener("change", (e) => {
  const { name, type, value, checked } = e.target;
  if (!name) return;
  state.srivariSeva[name] = type === "checkbox" ? checked : value;
  save();
});

el("#ssFillBtn").addEventListener("click", () => {
  const problems = validatePersonLike(state.srivariSeva, "Srivari Seva");
  if (problems.length) {
    showToast(`⚠️ ${problems.join("; ")}`);
    return;
  }
  runFill({ srivariSeva: state.srivariSeva }, "none");
});

// ---------- pilgrims (Pilgrim Booking / Angapradakshana / Srivani) ----------
function newPilgrim() {
  return {
    id: uid(),
    name: "",
    age: "",
    gender: "",
    idType: "Aadhaar",
    idNumber: ""
  };
}

function renderGroup(group) {
  const list = el(group.listSel);
  list.innerHTML = "";
  const tpl = el("#pilgrimCardTemplate");
  const pilgrims = state[group.key];

  pilgrims.forEach((p, idx) => {
    const node = tpl.content.cloneNode(true);
    const card = node.querySelector(".pilgrim-card");
    card.dataset.id = p.id;
    node.querySelector(".pilgrim-title").textContent = `Pilgrim ${idx + 1}`;

    els("[data-field]", node).forEach((input) => {
      const field = input.dataset.field;
      input.value = p[field] ?? "";
      input.addEventListener("input", () => {
        p[field] = input.value;
        save();
      });
      if (input.tagName === "SELECT") {
        input.addEventListener("change", () => {
          p[field] = input.value;
          save();
        });
      }
    });

    node.querySelector(".remove-one").addEventListener("click", () => {
      state[group.key] = state[group.key].filter((x) => x.id !== p.id);
      save();
      renderGroup(group);
    });

    const profileSelect = node.querySelector(".profile-select");
    if (profileSelect) {
      profileSelect.innerHTML = profileSelectOptionsHtml("");
      profileSelect.addEventListener("change", () => {
        const prof = (state.profiles || []).find((x) => x.id === profileSelect.value);
        profileSelect.value = "";
        if (!prof) return;
        Object.assign(p, { name: prof.name, age: prof.age, gender: prof.gender, idType: prof.idType, idNumber: prof.idNumber });
        save();
        renderGroup(group);
        showToast(`Loaded "${prof.label || prof.name || "profile"}" into Pilgrim ${idx + 1}`);
      });
    }

    node.querySelector(".save-profile")?.addEventListener("click", () => {
      const label = prompt("Save this pilgrim as a profile named:", p.name || `Pilgrim ${idx + 1}`);
      if (!label) return;
      state.profiles = state.profiles || [];
      state.profiles.push({ id: uid(), label, name: p.name, age: p.age, gender: p.gender, idType: p.idType, idNumber: p.idNumber });
      save();
      renderProfileList();
      refreshProfileSelects();
      showToast(`Saved profile "${label}"`);
    });

    node.querySelector(".fill-one").addEventListener("click", () => {
      const problems = validatePilgrim(p, idx);
      if (problems.length) {
        showToast(`⚠️ ${problems.join("; ")}`);
        return;
      }
      runFill({ pilgrims: [p], contact: null }, group.mode === "auto" ? "pay" : group.mode);
    });

    list.appendChild(node);
  });

  el(group.addBtnSel).disabled = pilgrims.length >= group.max;
}

function renderAllGroups() {
  GROUPS.forEach(renderGroup);
}

GROUPS.forEach((group) => {
  el(group.addBtnSel).addEventListener("click", () => {
    if (state[group.key].length >= group.max) return;
    state[group.key].push(newPilgrim());
    save();
    renderGroup(group);
  });

  // ---------- fill actions ----------
  el(group.fillBtnSel).addEventListener("click", () => {
    // Only groups with a dateSlotKey (the darshan-booking tabs — Sri PAT,
    // Tirumala, Angapradakshinam) have the date/slot/ticket-count
    // pre-step. Srivani never sends dateSlot at all, so content.js's
    // looksLikeDateSlotPage() gate is skipped for it and it behaves
    // exactly as before.
    const extra = group.dateSlotKey ? { dateSlot: state[group.dateSlotKey] } : {};
    if (group.dateSlotKey && state[group.dateSlotKey].ticketCount) {
      const wanted = Number(state[group.dateSlotKey].ticketCount);
      const filled = state[group.key].length;
      // Confirmed against a real /api/sed/v1/ticket/save request: the
      // server is sent no_of_pilgrims alongside a pilgrims array of that
      // same length — TTD's own booking flow keeps the ticket-count step
      // and the pilgrim-details step in sync for you, but here they're
      // two independently-edited fields, so nothing stops them drifting
      // apart. A mismatch here is a real, confirmed way to end up with a
      // booking the server rejects, not just a cosmetic difference.
      if (wanted && wanted !== filled) {
        const fix = confirm(
          `Number of Tickets is ${wanted} but ${filled} pilgrim(s) are filled in — TTD may reject the booking.\n\nSet Number of Tickets to ${filled} to match? (Cancel to proceed as-is instead.)`
        );
        if (fix) {
          state[group.dateSlotKey].ticketCount = String(filled);
          save();
          const countSel = el(dateSlotIds(group).count);
          if (countSel) countSel.value = String(filled);
          showToast(`Set Number of Tickets to ${filled}`);
        }
      }
    }
    const problems = [
      ...state[group.key].flatMap((p, idx) => validatePilgrim(p, idx)),
      ...validateContact(state.contact)
    ];
    if (problems.length) {
      showToast(`⚠️ Fix before filling: ${problems.join("; ")}`);
      return;
    }
    if (group.mode === "auto") {
      runQuickBook({ pilgrims: state[group.key], contact: state.contact, ...extra });
      return;
    }
    runFill({ pilgrims: state[group.key], contact: state.contact, ...extra }, group.mode);
  });

  // ---------- wait for slot availability, then fill ----------
  if (group.waitBtnSel) {
    el(group.waitBtnSel)?.addEventListener("click", () => runWaitForSlot(group));
  }
});

// ---------- Seva (Group): Team Leader + Team Members ----------
function newSevaPerson() {
  return {
    id: uid(),
    idType: "Aadhaar",
    idNumber: "",
    name: "",
    surname: "",
    fatherSpouseName: "",
    dob: "",
    age: "",
    mobile: "",
    email: "",
    street: "",
    doorNo: "",
    pincode: "",
    country: "India",
    state: "",
    district: "",
    city: "",
    nearestTemple: ""
  };
}

function bindPersonFields(root, person) {
  els("[data-field]", root).forEach((input) => {
    const field = input.dataset.field;
    if (field === "photo") return; // file inputs can't be pre-filled — left disabled
    input.value = person[field] ?? "";
    input.addEventListener("input", () => {
      person[field] = input.value;
      save();
    });
    if (input.tagName === "SELECT") {
      input.addEventListener("change", () => {
        person[field] = input.value;
        save();
      });
    }
  });
}

function renderSevaLeader() {
  const host = el("#sevaLeaderFields");
  host.innerHTML = "";
  const tpl = el("#sevaPersonTemplate");
  const node = tpl.content.cloneNode(true);
  bindPersonFields(node, state.sevaLeader);
  host.appendChild(node);
}

function renderSevaMembers() {
  const list = el("#sevaMemberList");
  list.innerHTML = "";
  const cardTpl = el("#sevaMemberCardTemplate");
  const personTpl = el("#sevaPersonTemplate");

  state.sevaMembers.forEach((m, idx) => {
    const cardNode = cardTpl.content.cloneNode(true);
    const card = cardNode.querySelector(".seva-member-card");
    card.dataset.id = m.id;
    cardNode.querySelector(".pilgrim-title").textContent = `Team Member #${idx + 1}`;

    const slot = cardNode.querySelector(".member-fields-slot");
    const personNode = personTpl.content.cloneNode(true);
    bindPersonFields(personNode, m);
    slot.appendChild(personNode);

    cardNode.querySelector(".remove-one").addEventListener("click", () => {
      state.sevaMembers = state.sevaMembers.filter((x) => x.id !== m.id);
      save();
      renderSevaMembers();
    });

    cardNode.querySelector(".fill-one").addEventListener("click", () => {
      const problems = validatePersonLike(m, `Team Member #${idx + 1}`);
      if (problems.length) {
        showToast(`⚠️ ${problems.join("; ")}`);
        return;
      }
      runFill({ sevaPeople: [m] }, "none");
    });

    list.appendChild(cardNode);
  });

  el("#sgAddMemberBtn").disabled = state.sevaMembers.length >= MAX_SEVA_MEMBERS;
}

el("#sgAddMemberBtn").addEventListener("click", () => {
  if (state.sevaMembers.length >= MAX_SEVA_MEMBERS) return;
  state.sevaMembers.push(newSevaPerson());
  save();
  renderSevaMembers();
});

el("#sgFillLeaderBtn").addEventListener("click", () => {
  const problems = validatePersonLike(state.sevaLeader, "Team Leader");
  if (problems.length) {
    showToast(`⚠️ ${problems.join("; ")}`);
    return;
  }
  runFill({ sevaPeople: [state.sevaLeader] }, "none");
});

el("#sgFillAllMembersBtn").addEventListener("click", () => {
  if (!state.sevaMembers.length) {
    showToast("Add at least one team member first");
    return;
  }
  const problems = state.sevaMembers.flatMap((m, idx) => validatePersonLike(m, `Team Member #${idx + 1}`));
  if (problems.length) {
    showToast(`⚠️ Fix before filling: ${problems.join("; ")}`);
    return;
  }
  runFill({ sevaPeople: state.sevaMembers }, "none");
});

el("#sgCopyAddressBtn").addEventListener("click", () => {
  const { street, doorNo, pincode, country, state: st, district, city } = state.sevaLeader;
  state.sevaMembers.forEach((m) => {
    Object.assign(m, { street, doorNo, pincode, country, state: st, district, city });
  });
  save();
  renderSevaMembers();
  showToast(`Copied address to ${state.sevaMembers.length} member(s)`);
});

// ---------- Srivani "Open Booking Page" link ----------
// Best-guess landing page for the Srivani trust booking flow — update this
// if the real booking URL differs.
el("#sriOpenBookingLink").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "https://ttdevasthanams.ap.gov.in/" });
});

function fillPayloadLabel(payload, mode) {
  if (payload.pilgrims?.length) return `Pilgrim fill (${mode}, ${payload.pilgrims.length})`;
  if (payload.srivariSeva) return "Srivari Seva fill";
  if (payload.sevaPeople?.length) return `Seva Group fill (${payload.sevaPeople.length})`;
  return "Fill";
}

// ---------- page layout-change detector ----------
// content.js's scanAndFill always returns a cheap "how many fields of each
// kind did I find" signature regardless of dry-run. Comparing it against
// what was seen on this same page last time catches a silent TTD
// redesign (idNumber/gender quietly stop matching) BEFORE that surprise
// costs a real queue slot, rather than only after a fill comes up short.
function pageSignatureKey(url) {
  try {
    const u = new URL(url);
    return u.hostname + u.pathname.split("/").slice(0, 3).join("/");
  } catch (_) {
    return url || "unknown";
  }
}

function checkPageSignatureChange(tab, fieldSignature) {
  if (!fieldSignature || !Object.keys(fieldSignature).length) return;
  const key = pageSignatureKey(tab?.url);
  state.pageSignatures = state.pageSignatures || {};
  const prev = state.pageSignatures[key];
  if (prev) {
    const shrunk = Object.entries(prev).filter(([k, n]) => (fieldSignature[k] || 0) < n);
    if (shrunk.length) {
      const detail = shrunk.map(([k, n]) => `${k} ${n}→${fieldSignature[k] || 0}`).join(", ");
      showToast(`⚠️ This page's fields look different than last visit (${detail}) — verify before trusting it with a real queue slot`);
    }
  }
  state.pageSignatures[key] = fieldSignature;
  save();
}

let lastFillPayload = null; // pilgrims/contact, reused to re-fill later steps

// True when this tab is already on the payment-method / card screen.
async function isPaymentPage(tabId) {
  try {
    const probe = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: () => (window.__pilgrimPaymentPageState ? window.__pilgrimPaymentPageState() : null)
    });
    return probe.some((r) => r?.result && (r.result.gateway || r.result.card));
  } catch (_) {
    return false;
  }
}

// ---------- Quick Book: ONE automation for every service ----------
// The popup only hands over the data and closes out of the way. The whole
// chain (date/slot/tickets -> Continue -> pilgrims + contact -> Continue ->
// whichever of Continue / Book Now / Pay Now the page shows -> Card -> card
// details -> 10s CVV window -> Pay) runs in background.js as one session, so it
// keeps going through page navigations and the gateway redirect.
async function runQuickBook(payload) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    showToast("No active tab found");
    return;
  }
  const cardSaved = !!(state.card && state.card.number && state.card.expiry);
  const useCard = !!state.cardAutofill && cardSaved;

  if (state.dryRunMode) {
    await runFill(payload, "pay"); // dry run = preview only, never clicks anything
    return;
  }

  if (await isPaymentPage(tab.id)) {
    if (!useCard) {
      showToast("This is the payment page — turn on \"Save Debit Card\" and save the card to auto-fill it");
      return;
    }
    showToast("Payment page detected — selecting Card and filling it");
    chrome.runtime.sendMessage({ type: "PILGRIM_START_AUTO_PAY", tabId: tab.id, quick: true, useCard: true, card: state.card, startStep: "select_card" })
      .catch((err) => showToast(`⚠️ Couldn't start the card step: ${err?.message || err}`));
    return;
  }

  lastFillPayload = { ...payload, dateSlot: null, dryRun: false };
  logActivity({ label: `Quick Book (${payload.pilgrims?.length || 0})`, filledCount: 0 });
  showToast(
    useCard
      ? "⚡ Quick Book started — watch the on-page timer. You only type the CVV."
      : "⚡ Quick Book started — no saved card, so it will stop at the payment page."
  );
  try {
    const r = await chrome.runtime.sendMessage({
      type: "PILGRIM_START_AUTO_PAY",
      tabId: tab.id,
      quick: true,
      startStep: "fill",
      fillPayload: { ...payload, dryRun: false },
      useCard,
      card: useCard ? state.card : null
    });
    if (r && r.started === false) showToast(`⚠️ Couldn't start Quick Book: ${r.reason || "unknown error"}`);
  } catch (err) {
    showToast(`⚠️ Couldn't start Quick Book: ${err?.message || err}`);
  }
}

async function runFill(payload, mode = "pay") {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    showToast("No active tab found");
    return;
  }
  const dryRun = !!state.dryRunMode;

  // Already on the payment / card screen? Then Fill means "do the card
  // step" — never run the pilgrim fill here (it would type the pilgrim's
  // name into "Name on Card" and nothing else).
  if (!dryRun) {
    let onPay = false;
    try {
      const probe = await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: () => (window.__pilgrimPaymentPageState ? window.__pilgrimPaymentPageState() : null)
      });
      onPay = probe.some((r) => r?.result && (r.result.gateway || r.result.card));
    } catch (_) {}
    if (onPay) {
      if (state.cardAutofill && (state.card.number || state.card.name)) {
        showToast("Payment page detected — selecting Card and filling it (watch the on-page status)");
        try {
          Promise.resolve(chrome.runtime.sendMessage({ type: "PILGRIM_START_AUTO_PAY", tabId: tab.id, useCard: true, card: state.card, startStep: "select_card" }))
            .catch((err) => showToast(`⚠️ Couldn't start the card step: ${err?.message || err}`));
        } catch (err) {
          showToast(`⚠️ Couldn't start the card step: ${err?.message || err}`);
        }
      } else {
        showToast("This is the payment page — turn on \"Save Debit Card\" in Settings to auto-fill it");
      }
      return;
    }
  }

  const fullPayload = { ...payload, dryRun };
  lastFillPayload = { ...payload, dateSlot: null, dryRun: false };
  const label = fillPayloadLabel(payload, mode);
  showToast(dryRun ? "Dry-run: previewing…" : "Filling…"); // the retry pass can take a couple seconds — don't look stuck
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: injectedFill,
      args: [fullPayload]
    });
    const frameResult = results?.[0];
    if (frameResult?.error) {
      // executeScript itself failed for this frame (e.g. blocked page).
      showToast(`⚠️ ${frameResult.error.message || "Couldn't run on this page"}`);
      logActivity({ label, filledCount: 0, error: frameResult.error.message || "Couldn't run on this page" });
      return;
    }
    const inner = frameResult?.result;
    if (inner?.error) {
      // Our content script ran but hit a runtime error — show it verbatim
      // so we're not debugging blind on a device with no dev console.
      showToast(`⚠️ Script error: ${inner.error}`);
      logActivity({ label, filledCount: 0, error: inner.error });
      return;
    }
    const count = inner?.filledCount ?? 0;
    checkPageSignatureChange(tab, inner?.fieldSignature);
    logActivity({ label: dryRun ? `${label} (dry run)` : label, filledCount: count, missed: inner?.missed, filledKeys: inner?.filledKeys });

    if (dryRun) {
      showToast(
        count > 0
          ? `Dry run: would fill ${count} field(s)${inner?.missed?.length ? ` — would miss: ${inner.missed.join("; ")}` : ""} — nothing was submitted`
          : "Dry run: no matching fields found on this page — nothing was submitted"
      );
      return; // dry run never chases Continue/Pay Now/Book Now
    }

    if (inner?.missed?.length) {
      showToast(`✅ Filled ${count} — but ${inner.missed.join("; ")}`);
    } else {
      showToast(count > 0 ? `✅ Filled ${count} field(s)` : "⚠️ No matching fields found on this page");
    }

    if (count === 0) {
      notify("⚠️ Nothing filled", "No matching fields were found on this page — check the tab.");
    }

    await chaseAutoContinue(tab.id, mode, count);
  } catch (err) {
    showToast(`Couldn't run on this page: ${err?.message || err}`);
    logActivity({ label, filledCount: 0, error: err?.message || String(err) });
  }
}

// Chases Continue → Pay Now / Book Now once a fill has actually put
// something on the page — factored out of runFill so runWaitForSlot can
// reuse the exact same post-fill behavior once a watched slot opens up.
async function chaseAutoContinue(tabId, mode, count) {
  // Works the same from EVERY service tab (Special Entry, Srivari, Seva,
  // Accommodation, Angapradakshinam ...): the mode only decides whether the
  // popup-driven Book Now path is used. For everything else the background
  // worker looks at whatever screen is showing and clicks Continue / Pay
  // Now / Book Now by itself, then selects Card and fills it — it survives
  // the gateway redirect that closes this popup.
  const autoOn = mode === "book" ? true : !!(state.autoPay || state.cardAutofill);
  if (!(autoOn && count > 0)) return;

  if (mode === "book") {
    // Same single background driver as every other tab: it looks at the page
    // and taps Continue / Book Now itself (no card involved).
    try {
      const r = await chrome.runtime.sendMessage({ type: "PILGRIM_START_AUTO_PAY", tabId, useCard: false, card: null, payload: lastFillPayload });
      if (r && r.started === false) showToast(`⚠️ Couldn't start Continue → Book Now: ${r.reason || "unknown error"}`);
      else showToast("Started — Continue → Book Now runs automatically (watch the on-page bubble)");
    } catch (err) {
      showToast(`⚠️ Continue → Book Now failed: ${err?.message || err}`);
    }
    return;
  }
  const useCard = !!state.cardAutofill && !!(state.card && (state.card.number || state.card.name));
  if (!useCard) {
    // PhonePe / non-card path (unchanged).
    await runAutoContinuePay(tabId);
    return;
  }
  showToast("Started — Continue → Pay Now → Card runs automatically (watch the on-page bubble)");
  try {
    Promise.resolve(chrome.runtime.sendMessage({
      type: "PILGRIM_START_AUTO_PAY",
      tabId,
      useCard: true,
      card: state.card,
      payload: lastFillPayload
    })).catch((err) => showToast(`⚠️ Couldn't start Auto Continue → Pay: ${err?.message || err}`));
  } catch (err) {
    showToast(`⚠️ Couldn't start Auto Continue → Pay: ${err?.message || err}`);
  }
}

// ---------- wait-for-availability ----------
// Polls the saved date/slot(s) for a group every ~20s (bounded to 10
// minutes) by re-running the exact same fill the "Fill All Details" button
// uses. If the reported miss is specifically about the slot/date not being
// selectable yet, keep waiting; any other outcome (success OR a genuine,
// non-availability error) ends the wait immediately. On success, the pass
// that found availability has already filled pilgrim details too (see
// content.js's __pilgrimAutofillRun), so this then runs the same
// Continue/Pay-Now/Book-Now chase runFill would have.
const UNAVAILABLE_PATTERN = /couldn't select any of the preferred slots|not selectable|not available|ticket\/slot list never appeared|date picker not found/i;
const WAIT_FOR_SLOT_MAX_MS = 10 * 60 * 1000;
const WAIT_FOR_SLOT_POLL_MS = 20 * 1000;

async function runWaitForSlot(group) {
  const ds = state[group.dateSlotKey] || {};
  if (!ds.date) {
    showToast("Set a Preferred Darshan Date (and Slot) first");
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    showToast("No active tab found");
    return;
  }
  const problems = state[group.key].flatMap((p, idx) => validatePilgrim(p, idx));
  if (problems.length) {
    showToast(`⚠️ Fix before waiting: ${problems.join("; ")}`);
    return;
  }

  const label = `Wait for slot (${group.key})`;
  const startedAt = Date.now();
  stopRequested = false;
  showToast("Waiting for the slot to open — keep this tab open (Layover survives longer than the popup). Tap 🛑 to stop.");

  while (Date.now() - startedAt < WAIT_FOR_SLOT_MAX_MS) {
    if (stopRequested) {
      showToast("🛑 Wait for slot stopped");
      logActivity({ label, filledCount: 0, error: "stopped by 🛑" });
      return;
    }
    let inner;
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: injectedFill,
        args: [{ pilgrims: state[group.key], contact: state.contact, dateSlot: ds, dryRun: false }]
      });
      lastFillPayload = { pilgrims: state[group.key], contact: state.contact, dateSlot: null, dryRun: false };
      inner = results?.[0]?.result;
    } catch (err) {
      showToast(`⚠️ Wait for slot failed: ${err?.message || err}`);
      logActivity({ label, filledCount: 0, error: err?.message || String(err) });
      notify("⚠️ Wait for slot failed", err?.message || String(err));
      return;
    }

    const missedText = (inner?.missed || []).join("; ");
    const stillWaiting = !inner?.error && (inner?.filledCount ?? 0) === 0 && UNAVAILABLE_PATTERN.test(missedText);
    if (!stillWaiting) {
      const count = inner?.filledCount ?? 0;
      logActivity({ label, filledCount: count, missed: inner?.missed, error: inner?.error });
      if (inner?.error) {
        showToast(`⚠️ Script error: ${inner.error}`);
        notify("⚠️ Wait for slot failed", inner.error);
        return;
      }
      if (count > 0) {
        showToast(missedText ? `✅ Slot secured — filled ${count} — but ${missedText}` : `✅ Slot secured — filled ${count} field(s)`);
        notify("🎉 Slot opened up", `Filled ${count} field(s) — continuing automatically if enabled.`);
        await chaseAutoContinue(tab.id, group.mode, count);
      } else {
        showToast(`⚠️ Stopped waiting: ${missedText || "no matching fields found"}`);
        notify("⚠️ Stopped waiting for slot", missedText || "no matching fields found");
      }
      return;
    }

    showToast(`Still waiting for "${ds.slot || ds.date}"…`);
    await new Promise((resolve) => setTimeout(resolve, WAIT_FOR_SLOT_POLL_MS));
  }

  showToast("Gave up after 10 minutes — try again if the release window is still open");
  logActivity({ label, filledCount: 0, error: "gave up after 10 minutes of waiting" });
}

async function runAutoContinuePay(tabId) {
  try {
    const useCard = !!state.cardAutofill && !!(state.card.number || state.card.name);
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: injectedAutoContinuePay,
      args: [{ useCard, card: useCard ? state.card : null, payload: lastFillPayload }]
    });
    const inner = results?.[0]?.result;

    if (inner?.ok && inner.cardMode) {
      // The Name/Number/Expiry sub-form can render inside a same-page
      // payment-gateway iframe once "Card" is selected, so this second
      // pass runs across every frame — whichever one actually has the
      // fields fills them; the rest are harmless no-ops. CVV is never
      // touched here. The Proceed/Pay click that follows is gated behind
      // a visible 10s cancel-able countdown (see __pilgrimCardProceed) —
      // that window is the person's chance to type the CVV or cancel.
      let cardFilled = 0;
      try {
        const cardResults = await chrome.scripting.executeScript({
          target: { tabId, allFrames: true },
          func: injectedFillCardFields,
          args: [state.card]
        });
        cardFilled = cardResults.reduce((sum, r) => sum + (r?.result?.filledCount || 0), 0);
      } catch (e) {
        // A frame refusing script injection (e.g. a cross-origin gateway
        // sandbox) isn't fatal — other frames may still have succeeded.
      }
      showToast(
        cardFilled > 0
          ? `✅ Continued, selected Card, filled ${cardFilled} field(s) — enter your CVV, 10s to Proceed automatically`
          : "✅ Continued and selected Card — couldn't find the card fields, so fill those (and CVV) yourself"
      );

      // Only chase the final Proceed click if fields actually got filled —
      // otherwise there's nothing to submit and the button hunt would just
      // be confusing. showCountdownOverlay (10s, Cancel button) still
      // stands between this and an actual click — see __pilgrimCardProceed.
      if (cardFilled > 0) {
        try {
          const proceedResults = await chrome.scripting.executeScript({
            target: { tabId },
            func: injectedCardProceed
          });
          const proceedInner = proceedResults?.[0]?.result;
          if (proceedInner?.ok) {
            showToast("✅ Tapped Proceed — completing the payment");
            notify("💳 Proceed tapped — payment not complete yet", "Finish the CVV / bank authorization in the tab. The booking is only confirmed once the payment succeeds.");
          } else if (proceedInner?.reason === "Proceed cancelled") {
            showToast("Proceed cancelled");
          } else {
            showToast(`⚠️ ${proceedInner?.reason || "Couldn't tap Proceed — do it yourself"}`);
            notify("⚠️ Stopped at payment", proceedInner?.reason || "Couldn't tap Proceed — check the tab.");
          }
        } catch (err) {
          showToast(`⚠️ Proceed step failed: ${err?.message || err}`);
          notify("⚠️ Stopped at payment", `Proceed step failed: ${err?.message || err}`);
        }
      }
    } else if (inner?.ok) {
      showToast(
        inner.phonePeSelected
          ? "✅ Continued, selected PhonePe, and tapped Pay Now — complete the payment in the PhonePe app"
          : "✅ Continued and tapped Pay Now"
      );
      notify(
        "💳 Pay Now tapped — payment not complete yet",
        inner.phonePeSelected ? "Complete the payment in the PhonePe app. The booking is only confirmed once it succeeds." : "Check the tab and finish the payment."
      );
    } else if (inner?.reason === "Payment cancelled") {
      showToast("Payment cancelled");
    } else {
      showToast(`⚠️ ${inner?.reason || "Couldn't complete Continue → Pay Now"}`);
      notify("⚠️ Stopped at payment", inner?.reason || "Couldn't complete Continue → Pay Now — check the tab.");
    }
  } catch (err) {
    showToast(`⚠️ Continue → Pay Now failed: ${err?.message || err}`);
    notify("⚠️ Stopped at payment", `Continue → Pay Now failed: ${err?.message || err}`);
  }
}

async function runAutoContinueBook(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: injectedAutoContinueBook,
      args: [{ payload: lastFillPayload }]
    });
    const inner = results?.[0]?.result;
    if (inner?.ok) {
      showToast("✅ Continued and tapped Book Now");
    } else if (inner?.reason === "Booking cancelled") {
      showToast("Booking cancelled");
    } else {
      showToast(`⚠️ ${inner?.reason || "Couldn't complete Continue → Book Now"}`);
    }
  } catch (err) {
    showToast(`⚠️ Continue → Book Now failed: ${err?.message || err}`);
  }
}

// Runs the whole Accommodation flow in one shot. EXPERIMENTAL, unlike
// every other auto-continue path in this file: Accommodation crosses
// several full-page navigations (Location → the ticket-linked Select
// Service page → back to Accommodation Details → Payment), and a single
// long-running injected function can get killed mid-navigation exactly
// the way the old one-shot card-payment flow used to (see chaseAutoContinue's
// own comment above on why THAT flow was rebuilt as granular,
// chrome.tabs.onUpdated-driven steps in background.js instead). This
// hasn't had the same rebuild yet, so on a navigation-heavy run — the
// ticket-holder branch especially — it may stop partway through with the
// popup simply closing and no further progress, particularly on mobile.
// If that happens, whatever page it left you on is still just the real
// TTD page — carry on manually from there, or reopen the popup and try
// "Run Accommodation Flow" again on the page it stopped at.
async function runAccommodationFlow(tabId) {
  try {
    const payload = {
      ...state.accommodation,
      pilgrimSelectCount: Number(state.accommodation.pilgrimSelectCount) || 2,
      useCard: !!state.cardAutofill,
      card: state.cardAutofill ? state.card : null
    };
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: injectedAccommodationFlow,
      args: [payload]
    });
    const inner = results?.[0]?.result;
    if (inner?.ok) {
      showToast("✅ Accommodation booking flow completed");
    } else {
      showToast(`⚠️ ${inner?.reason || inner?.error || "Accommodation flow stopped partway through"}`);
    }
    logActivity({ label: "Accommodation", filledCount: inner?.ok ? 1 : 0, error: inner?.ok ? undefined : (inner?.reason || inner?.error) });
  } catch (err) {
    // The most common cause of landing here specifically (as opposed to a
    // clean {ok:false,...} result) is exactly the navigation-killed-the-
    // popum scenario described above — executeScript itself throws once
    // the tab it targeted has navigated away mid-call.
    showToast(`⚠️ Accommodation flow stopped — likely a page navigation closed this popup mid-flow. Check the page: ${err?.message || err}`);
  }
}


// Injected into the page context — runs the Continue → Pay Now flow that
// content.js already defined on window. opts.useCard/opts.card select the
// Card payment method instead of PhonePe when the toggle is on.
async function injectedAutoContinuePay(opts) {
  if (window.__pilgrimAutoContinuePay) {
    return await window.__pilgrimAutoContinuePay(opts);
  }
  return { ok: false, reason: "Content script not loaded on this page" };
}

// Injected into (potentially) every frame — fills Name/Number/Expiry into
// whatever card sub-form is present in that frame. Defined this way so it
// can reach a same-page payment-gateway iframe as well as the main page.
async function injectedFillCardFields(card) {
  if (window.__pilgrimFillCardFields) {
    return await window.__pilgrimFillCardFields(card);
  }
  return { filledCount: 0 };
}

// Injected into the page context — after card fields are filled, waits for
// the Proceed/Pay button and clicks it once the visible 10s countdown
// (with Cancel) runs out. This is the actual payment submission, so it's
// only ever called after fields were successfully filled.
async function injectedCardProceed() {
  if (window.__pilgrimCardProceed) {
    return await window.__pilgrimCardProceed();
  }
  return { ok: false, reason: "Content script not loaded on this page" };
}

// Injected into the page context — runs the Continue → Book Now flow
// (Angapradakshana: no payment step) that content.js defines on window.
async function injectedAutoContinueBook(opts) {
  if (window.__pilgrimAutoContinueBook) {
    return await window.__pilgrimAutoContinueBook(opts);
  }
  return { ok: false, reason: "Content script not loaded on this page" };
}

// Injected into the page context — runs the whole Accommodation flow
// (queue wait → instructions → location/service/date/room → pilgrim
// checkboxes → address → payment) that content.js defines on window. See
// window.__pilgrimAccommodationFlow's own long comment in content.js for
// exactly what this drives and what's confirmed-vs-assumed about the flow.
async function injectedAccommodationFlow(payload) {
  if (window.__pilgrimAccommodationFlow) {
    return await window.__pilgrimAccommodationFlow(payload);
  }
  return { ok: false, reason: "Content script not loaded on this page" };
}


// This function is injected into the page context — it must be self-contained.
// It's async because dropdown fields (Gender, Photo ID Proof) open a floating
// menu and need to wait for it before clicking an option.
async function injectedFill(payload) {
  if (window.__pilgrimAutofillRun) {
    return await window.__pilgrimAutofillRun(payload);
  }
  return { filledCount: 0 };
}

async function initExtensionUI(){if(initExtensionUI.done)return;initExtensionUI.done=true;await load();applyTheme();renderContact();renderAccommodation();renderSrivariSeva();renderAllGroups();renderSevaLeader();renderSevaMembers();renderTabVisibilityList();applyTabVisibility();renderProfileList();renderActivityLog();renderTabQueue();syncTabQueueAlarms();el("#dryRunToggle").checked=!!state.dryRunMode;el("#autoPayToggle").checked=!!state.autoPay;el("#timeSyncBookingToggle").checked=!!state.timeSyncBooking;el("#timeSyncSettings").hidden=!state.timeSyncBooking;el("#timeSyncTarget").value=normalizeTime(state.timeSyncTarget||"10:00:00");if(el("#timeSyncAction"))el("#timeSyncAction").value=["reload","workflow","click","service-click"].includes(state.timeSyncAction)?state.timeSyncAction:"reload";updateTimeSyncServiceDisplay();updateTimeSyncDisplay();el("#cardAutofillToggle").checked=!!state.cardAutofill;el("#cardFormWrap").hidden=!state.cardAutofill;renderCardForm();applyCardLockUI();renderAllDateSlots();}

// ---------- init ----------
initExtensionUI();
