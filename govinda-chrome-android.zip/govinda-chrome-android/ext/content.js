/**
 * Govinda Assistant — content script
 *
 * Tailored to the real ttdevasthanams.ap.gov.in "Pilgrim Details" form,
 * which uses Material-UI-style fields:
 *   - Plain text/number inputs: Name, Age, Photo Id Number
 *   - Custom (non-native) dropdowns: Gender (Female/Male/Transgender),
 *     Photo ID Proof (Aadhaar Card/Passport) — these open a floating
 *     option list on click rather than behaving like a native <select>.
 *
 * Still keyword-based (not hard-coded ids), since the site can re-render
 * element ids on every build. If a field isn't picked up, add a keyword
 * to KEYWORDS below.
 */

(function () {
  if (window.__pilgrimAutofillRun) return; // avoid double-injection

  const KEYWORDS = {
    name: ["pilgrim name", "full name", "name as per id", "devotee name", "name"],
    age: ["age"],
    gender: ["gender", "sex"],
    idType: ["photo id proof", "id proof type", "proof type", "document type", "idtype"],
    idNumber: ["photo id number", "id proof number", "aadhaar number", "aadhar number", "passport number", "id number", "idnumber"],
    email: ["email"],
    city: ["city", "town"],
    state: ["state", "province"],
    country: ["country"],
    pincode: ["pincode", "pin code", "zip", "postal"],
    gothram: ["gothram", "gothra"],

    // ---- added for Srivani / Srivari Seva / Seva (Group) tabs ----
    mobile: ["mobile number", "mobile", "phone number"],
    bloodGroup: ["blood group"],
    mentallyFit: ["mentally fit"],
    physicallyFit: ["physically fit"],
    street: ["street"],
    doorNo: ["door no", "door number"],
    district: ["district"],
    qualification: ["specific qualification", "qualification"],
    university: ["university/college name", "university", "college name"],
    yearOfGraduation: ["year of graduation"],
    specialization: ["specialization"],
    profession: ["profession"],
    professionCategory: ["profession category"],
    employmentStatus: ["employment status"],
    sector: ["sector"],
    surname: ["surname", "last name"],
    fatherSpouseName: ["father/spouse name", "father spouse name", "father name", "spouse name"],
    dob: ["date of birth", "dob"],
    nearestTemple: ["nearest ttd temple", "nearest temple"],

    // ---- Additional Services on the date/slot page (optional, page-level
    // — not per-pilgrim). Confirmed exact labels against a real recording:
    // "No. of Additional Laddus" / "Hundi Offerings". ----
    additionalLaddus: ["no. of additional laddus", "additional laddus", "no of additional laddus", "laddus"],
    hundiOffering: ["hundi offerings", "hundi offering", "hundi"],

    // ---- Accommodation tab ----
    noOfPilgrims: ["no of pilgrims", "no. of pilgrims", "number of pilgrims", "no.of pilgrims"]
  };

  // Values as they literally appear in the site's dropdown option lists.
  const VALUE_ALIASES = {
    gender: { male: "Male", female: "Female", other: "Transgender", transgender: "Transgender" },
    idType: { aadhaar: "Aadhaar Card", passport: "Passport" }
  };

  // Keys whose page field is a checkbox that should simply be ticked when
  // truthy — unlike a radio/checkbox group where the value has to match the
  // option's own label text (see setPlainValue's checkbox/radio branch),
  // these are single standalone checkboxes ("Mentally Fit", "Physically
  // Fit") with no value to match against.
  const STANDALONE_CHECKBOX_KEYS = ["mentallyFit", "physicallyFit"];

  // Keys that behave like a dropdown/select (native <select> or a custom
  // widget) rather than a plain text input, when filling a generic
  // profile/person object via fillKeyedFields below.
  const SELECT_LIKE_KEYS = ["gender", "idType", "bloodGroup", "employmentStatus", "sector"];

  function textOf(node) {
    return (node?.textContent || "").trim().toLowerCase();
  }

  function resolveAriaLabelledBy(field) {
    const ids = field.getAttribute("aria-labelledby");
    if (!ids) return "";
    return ids
      .split(/\s+/)
      .map((id) => textOf(document.getElementById(id)))
      .join(" ");
  }

  function labelForField(field) {
    if (field.labels && field.labels.length) {
      return [...field.labels].map(textOf).join(" ");
    }
    if (field.id) {
      const lbl = document.querySelector(`label[for="${CSS.escape(field.id)}"]`);
      if (lbl) return textOf(lbl);
    }
    const byAria = resolveAriaLabelledBy(field);
    if (byAria) return byAria;
    // fallback: nearest label within the same OR a nearby ancestor
    // form-control container. Walk up a few levels since some sites put
    // the caption several levels above the actual field rather than as a
    // direct wrapping <label> or an immediate preceding sibling — TTD's
    // "Number of Tickets" control is exactly this: the caption text sits
    // as a sibling of the input's *grandparent*, two levels up, which the
    // single-level check below used to never reach at all. Missing that
    // label meant this control's signature() came back with nothing
    // mentioning "tickets", so it was invisible to the ticket-count
    // selection step entirely — not a timing issue, just never found.
    let container = field.closest("div,td,li,fieldset");
    for (let hop = 0; hop < 3 && container; hop++) {
      const lbl = container.querySelector("label");
      // Only trust a found <label> if it actually has text — TTD's
      // "Number of Tickets" widget contains a real but EMPTY <label> tag
      // (used purely for a CSS floating-label animation; the actual
      // caption lives in a separate sibling div instead). Returning ""
      // here unconditionally just because *a* <label> element exists was
      // short-circuiting this function before it ever reached the
      // lastCaption climb below — which is the part that actually finds
      // "Number of Tickets" — so the ticket-count control kept coming up
      // with no usable label at all despite the climb existing.
      if (lbl) {
        const lblText = textOf(lbl);
        if (lblText) return lblText;
      }
      // Some fields show their caption as a plain span/div (a floating
      // "Card number" style caption) rather than a real <label> tag —
      // grab the LAST short text-bearing element before the field itself
      // (closest to it), not the first one this container happens to
      // contain, since an outer container can have more than one caption
      // before reaching the field (e.g. a heading followed by the actual
      // field label).
      let lastCaption = "";
      for (const child of container.children) {
        if (child === field || child.contains?.(field)) break;
        const t = textOf(child);
        if (t && t.length <= 40) lastCaption = t;
      }
      if (lastCaption) return lastCaption;
      container = container.parentElement?.closest("div,td,li,fieldset");
    }
    return "";
  }

  function signature(field) {
    return [
      field.id,
      field.getAttribute("name"),
      field.getAttribute("placeholder"),
      field.getAttribute("aria-label"),
      labelForField(field)
    ]
      .filter(Boolean)
      .join(" ")
      // Split camelCase so word-boundary matching still sees "name" in
      // "devoteeName" (pilgrimName -> pilgrim Name).
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .toLowerCase();
  }

  function isVisible(field) {
    return field.getClientRects().length > 0;
  }

  function isFillable(field) {
    if (field.disabled || field.getAttribute("aria-disabled") === "true") return false;
    if (field.readOnly) return false;
    if (field.type === "hidden" || field.type === "submit" || field.type === "button") return false;
    return isVisible(field);
  }

  // Union of trigger patterns used by common custom-dropdown widgets:
  // MUI Select, Angular Material mat-select, PrimeNG p-dropdown,
  // ng-select, select2, react-select, and generic ARIA comboboxes.
  const DROPDOWN_TRIGGER_SELECTOR = [
    '[role="combobox"]',
    '[role="button"][aria-haspopup]',
    '[aria-haspopup="listbox"]',
    'mat-select',
    '.mat-select-trigger',
    '.p-dropdown',
    '.p-dropdown-trigger',
    '.p-multiselect',
    '.ng-select-container',
    '.select2-selection',
    '.select2-container',
    '[class*="-control"][class*="select"]', // react-select control
    '[class*="dropdown-toggle"]',
    '[class*="Dropdown"][role]',
    // TTD's own "Pilgrim Details" form (and similar sites) render Gender /
    // Photo ID Proof as a plain <input readonly> that opens a floating
    // option list on click — no role/aria-haspopup/widget class at all.
    // isFillable() rightly excludes readonly inputs from the plain-value
    // bucket (we shouldn't type into them), but that also meant they were
    // never picked up as dropdown triggers either, so they were invisible
    // to the whole scan. Catching them here (isVisible-only, no isFillable
    // check) is what actually fixes "gender & photo id proof not selecting".
    "input[readonly]"
  ].join(", ");

  function collectFields() {
    const plain = [...document.querySelectorAll("input, select, textarea")].filter(isFillable);
    // Custom dropdown triggers: many widget libraries render these as a
    // div/span rather than a native <select>.
    const dropdownTriggers = [...document.querySelectorAll(DROPDOWN_TRIGGER_SELECTOR)].filter(isVisible);
    return { plain, dropdownTriggers };
  }

  // Short keywords must match a whole word. A plain substring test made
  // "age" fire on "message" / "page" / "usage" and "city" on "capacity",
  // so an unrelated field could be filled with a pilgrim's age or city.
  function keywordHit(sig, kw) {
    if (kw.length > 5 || kw.includes(" ")) return sig.includes(kw);
    return sig.split(/[^a-z0-9]+/).includes(kw);
  }

  function scoreMatch(sig, keywords) {
    let best = 0;
    for (const kw of keywords) {
      if (keywordHit(sig, kw)) best = Math.max(best, kw.length);
    }
    return best;
  }

  // Exact `name` / `id` attribute -> key map (normalized: lowercase, letters
  // and digits only). TTD's real fields use names like pilgrimEmail,
  // pilgrimCity, photoIdType, idProofNumber. These beat fuzzy keyword
  // matching, which could misfire when a nearby caption such as
  // "pilgrim name" outscored the field's own attribute.
  const NAME_ATTR_MAP = {
    pilgrimemail: "email", email: "email", emailid: "email",
    pilgrimcity: "city", city: "city",
    pilgrimstate: "state", state: "state",
    pilgrimcountry: "country", country: "country",
    pilgrimpincode: "pincode", pincode: "pincode", pilgrimzip: "pincode", zipcode: "pincode",
    pilgrimmobile: "mobile", mobile: "mobile", mobileno: "mobile", mobilenumber: "mobile", phone: "mobile",
    pilgrimgothram: "gothram", gothram: "gothram", gothra: "gothram",
    name: "name", fname: "name", fullname: "name", pilgrimname: "name",
    age: "age", pilgrimage: "age",
    gender: "gender", pilgrimgender: "gender",
    idtype: "idType", photoidtype: "idType", photoidproof: "idType", idprooftype: "idType",
    idnumber: "idNumber", idproofnumber: "idNumber", photoidnumber: "idNumber", photoidproofnumber: "idNumber"
  };

  function normAttr(v) {
    return String(v || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  }

  function keyFromAttributes(field) {
    const byName = NAME_ATTR_MAP[normAttr(field.getAttribute("name"))];
    if (byName) return byName;
    const byFormControl = NAME_ATTR_MAP[normAttr(field.getAttribute("formcontrolname"))];
    if (byFormControl) return byFormControl;
    // id="0" style ids are meaningless; only trust ids that look like words.
    const idv = normAttr(field.id);
    if (idv && !/^[0-9]+$/.test(idv) && NAME_ATTR_MAP[idv]) return NAME_ATTR_MAP[idv];
    return null;
  }

  function classifyList(fields) {
    const matches = [];
    for (const field of fields) {
      // 1) exact attribute match wins
      const attrKey = keyFromAttributes(field);
      if (attrKey) {
        matches.push({ field, key: attrKey, score: 1000 });
        continue;
      }
      // 2) fuzzy keyword match on the full signature (spaces/punctuation
      //    ignored on both sides, so "idProofNumber" matches "id proof number")
      const sig = signature(field);
      if (!sig) continue;
      const sigN = normAttr(sig);
      let bestKey = null;
      let bestScore = 0;
      for (const [key, keywords] of Object.entries(KEYWORDS)) {
        let score = scoreMatch(sig, keywords);
        for (const kw of keywords) {
          const kwN = normAttr(kw);
          // Squashed (no-space) matching only for longer keywords, for the same
          // reason as keywordHit above.
          if (kwN.length >= 6 && sigN.includes(kwN)) score = Math.max(score, kwN.length);
        }
        if (score > bestScore) {
          bestScore = score;
          bestKey = key;
        }
      }
      if (bestKey) matches.push({ field, key: bestKey, score: bestScore });
    }
    return matches;
  }

  function waitFor(fn, timeout = 1500, interval = 60) {
    return new Promise((resolve) => {
      const start = Date.now();
      (function check() {
        const result = fn();
        if (result) return resolve(result);
        if (Date.now() - start > timeout) return resolve(null);
        setTimeout(check, interval);
      })();
    });
  }

  function findOpenMenu() {
    return (
      document.querySelector('ul[role="listbox"]:not([style*="display: none"])') ||
      document.querySelector('[role="listbox"]') ||
      document.querySelector('[role="menu"]') ||
      document.querySelector(".MuiMenu-list, .MuiList-root") ||
      document.querySelector(".mat-select-panel, .cdk-overlay-pane .mat-option") ||
      document.querySelector(".p-dropdown-panel, .p-dropdown-items") ||
      document.querySelector(".ng-dropdown-panel, .ng-option") ||
      document.querySelector(".select2-results__options") ||
      document.querySelector('[class*="menu"][class*="select"]') // react-select menu
    );
  }

  // Last-resort option finder: instead of trusting any particular widget
  // library's container class, scan the WHOLE page for a small, visible,
  // leaf-ish element whose text matches one of the values we're actually
  // looking for. This works regardless of what UI library renders the
  // dropdown, as long as *something* clickable with that exact text shows
  // up after the trigger is clicked.
  function findOptionByTextAnywhere(wanted) {
    const candidates = document.querySelectorAll(
      '[role="option"], li, option, .mat-option, .p-dropdown-item, .ng-option, ' +
        ".select2-results__option, div, span, a, button, td"
    );
    let exact = null;
    let partial = null;
    for (const el of candidates) {
      if (!isVisible(el)) continue;
      if (el.children.length > 2) continue; // options are short leaf labels, not containers
      const t = textOf(el);
      if (!t || t.length > 40) continue;
      if (t === wanted) {
        exact = el;
        break;
      }
      const word = (hay, needle) => hay === needle || new RegExp("(^|[^a-z0-9])" + needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "([^a-z0-9]|$)").test(hay);
      if (!partial && (word(t, wanted) || word(wanted, t))) partial = el;
    }
    return exact || partial;
  }

  // Fire touch + pointer/mouse + click events, in that order, at the
  // element's actual on-screen coordinates. This mobile TTD widget opens
  // its menu on a plain click, but many mobile-optimized custom option
  // lists bind the actual "select this" handler to touchstart/touchend
  // instead — a click-only simulation opens the list but never picks an
  // option from it, which matches exactly what's being seen.
  function fireClickSequence(el) {
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;

    try {
      if (typeof Touch !== "undefined" && typeof TouchEvent !== "undefined") {
        const touch = new Touch({
          identifier: Date.now(),
          target: el,
          clientX: x,
          clientY: y,
          pageX: x + window.scrollX,
          pageY: y + window.scrollY
        });
        const touchOpts = { bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] };
        el.dispatchEvent(new TouchEvent("touchstart", touchOpts));
        el.dispatchEvent(new TouchEvent("touchend", { ...touchOpts, touches: [], targetTouches: [] }));
      }
    } catch {
      // Touch constructor unsupported in this engine — mouse/pointer/click below still fire.
    }

    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      try {
        const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
        el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, clientX: x, clientY: y }));
      } catch {
        // Constructor unsupported in this engine; move on.
      }
    }
  }
  // Exposed on window so the scheduler's separate content-script closure
  // can trigger a real click sequence too — it has no access to the
  // plain function above (same reason it needed its own delay() and
  // window.__pilgrimFindReviewPayButton instead of calling
  // clickThroughToPayNow directly).
  window.__pilgrimFireClickSequence = fireClickSequence;

  // Visible short-text leaf-ish elements, used to spot an option list that
  // appears after the trigger is clicked (whatever library draws it).
  function visibleOptionCandidates() {
    const out = new Set();
    const all = document.querySelectorAll(
      '[role="option"], li, option, .mat-option, .p-dropdown-item, .ng-option, .select2-results__option, div, span, a, button, td, p, label'
    );
    for (const el of all) {
      if (!isVisible(el)) continue;
      if (el.children.length > 2) continue;
      const t = textOf(el);
      if (!t || t.length > 40) continue;
      out.add(el);
    }
    return out;
  }

  function fireKey(el, key, code, keyCode) {
    for (const type of ["keydown", "keypress", "keyup"]) {
      try {
        el.dispatchEvent(new KeyboardEvent(type, { bubbles: true, cancelable: true, key, code, keyCode, which: keyCode }));
      } catch {}
    }
  }

  function dropdownLooksSelected(trigger, wanted) {
    const numeric = /^\d{1,2}$/.test(wanted);
    const isInput = trigger.tagName === "INPUT";
    let v = String(isInput ? trigger.value : (trigger.value || trigger.textContent) || "").replace(/\u200b/g, "").trim().toLowerCase();
    if (!v && isInput) {
      // some widgets keep the visible text in a sibling display element
      const d = findSelectDisplay(trigger);
      v = d && trigger.parentElement && trigger.parentElement.contains(d) ? textOf(d).replace(/\u200b/g, "").trim() : "";
    }
    if (!v) return false;
    if (numeric) return v === wanted;
    // Whole-word match only: a plain substring test treated "female" as
    // already being "male", so choosing Male after Female was skipped.
    const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const hasWord = (hay, needle) => new RegExp("(^|[^a-z0-9])" + esc(needle) + "([^a-z0-9]|$)").test(hay);
    return v === wanted || hasWord(v, wanted) || (v.length > 2 && hasWord(wanted, v));
  }

  function findSelectDisplay(trigger) {
    const SEL =
      '[role="combobox"], [aria-haspopup="listbox"], [aria-haspopup="true"], .MuiSelect-select, [class*="Select-select"], ' +
      'mat-select, .mat-select, .mat-mdc-select, .ng-select, .select__control, [role="button"]';
    let node = trigger.parentElement;
    for (let depth = 0; node && depth < 5; depth++, node = node.parentElement) {
      if (node.matches?.(SEL) && isVisible(node)) return node;
      const found = [...node.querySelectorAll(SEL)].find((el) => el !== trigger && isVisible(el) && !el.matches("button[type=submit]"));
      if (found) return found;
    }
    return null;
  }

  // ---- React-aware helpers -------------------------------------------------
  // TTD's dropdowns are readonly <input class="floating-input"> controls
  // (React). Plain DOM events don't open them from a content script, so we
  // also (a) hit-test the real tap point, (b) fire focus events (the page's
  // window isn't focused while the assistant sheet is up, so .focus() alone
  // doesn't emit them), and (c) call the element's React handlers directly.
  function reactPropsOf(el) {
    if (!el) return null;
    const k = Object.keys(el).find((x) => x.startsWith("__reactProps$"));
    return k ? el[k] : null;
  }

  function callReactHandler(el, name) {
    const props = reactPropsOf(el);
    const fn = props && props[name];
    if (typeof fn !== "function") return false;
    const r = el.getBoundingClientRect();
    let native;
    try { native = new MouseEvent(name.slice(2).toLowerCase(), { bubbles: true }); } catch {}
    const ev = {
      type: name.slice(2).toLowerCase(), target: el, currentTarget: el, bubbles: true,
      button: 0, buttons: 1, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2,
      isTrusted: true, defaultPrevented: false, nativeEvent: native,
      preventDefault() {}, stopPropagation() {}, persist() {},
      isDefaultPrevented: () => false, isPropagationStopped: () => false
    };
    try { fn(ev); return true; } catch { return false; }
  }

  function callReactChain(el, names, hops = 4) {
    let any = false;
    let node = el;
    for (let i = 0; node && i <= hops; i++, node = node.parentElement) {
      for (const n of names) if (callReactHandler(node, n)) any = true;
    }
    return any;
  }

  function fireFocusEvents(el) {
    try { el.focus(); } catch {}
    for (const type of ["focusin", "focus"]) {
      try { el.dispatchEvent(new FocusEvent(type, { bubbles: type === "focusin", composed: true })); } catch {}
    }
  }

  // Tap exactly where a finger would: whatever element is really on top at
  // the control's centre (an overlay div can sit above the input).
  function tapAtPoint(el) {
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    const top = document.elementFromPoint(x, y);
    if (top && top !== el) fireClickSequence(top);
    return top;
  }

  // Try ways of opening a custom dropdown one at a time; after each, see
  // whether new visible short-text elements (the options) appeared.
  async function openDropdown(trigger) {
    trigger.scrollIntoView({ block: "center" });
    await delay(150);
    const siblings = [...(trigger.parentElement?.children || [])].filter((e) => e !== trigger && isVisible(e));
    const display = findSelectDisplay(trigger);
    const strategies = [
      ["dom-click+focus", () => { fireFocusEvents(trigger); fireClickSequence(trigger); try { trigger.click(); } catch {} }],
      ["tap-at-point", () => { tapAtPoint(trigger); }],
      ["react-focus", () => { callReactChain(trigger, ["onFocus"], 3); }],
      ["react-mousedown", () => { callReactChain(trigger, ["onMouseDown", "onPointerDown", "onTouchStart"], 3); }],
      ["react-click", () => { callReactChain(trigger, ["onClick"], 4); }],
      ["overlay-sibling", () => { siblings.forEach((e) => { fireClickSequence(e); try { e.click(); } catch {} }); }],
      ["display-control", () => { if (display) { fireClickSequence(display); try { display.click(); } catch {} } }]
    ];
    for (const [name, run] of strategies) {
      const before = visibleOptionCandidates();
      try { run(); } catch {}
      const fresh = await waitFor(() => {
        const now = [...visibleOptionCandidates()].filter(
          (el) => !before.has(el) && el !== trigger && !trigger.contains(el) && !el.contains(trigger)
        );
        return now.length ? now : null;
      }, 700, 80);
      if (fresh) return { method: name, before, fresh };
    }
    return null;
  }

  // ---- Trusted (real) taps via the browser's debugger protocol -----------
  // Synthetic DOM events can't open some React dropdowns. If the browser
  // exposes chrome.debugger, the background script injects a genuine
  // mouse click at the element's coordinates instead.
  const __trusted = { unavailable: false, ready: false, last: 0 };

  async function ensureTrusted() {
    if (__trusted.unavailable) return false;
    if (__trusted.ready && Date.now() - __trusted.last < 50000) return true;
    try {
      if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) throw new Error("no runtime");
      const res = await chrome.runtime.sendMessage({ action: "pilgrimDbgAttach" });
      if (!res || !res.ok) throw new Error((res && res.error) || "attach failed");
      __trusted.ready = true;
      __trusted.last = Date.now();
      // The browser shows a "debugging" bar that resizes the page; let the
      // layout settle once, BEFORE any coordinates are measured.
      await delay(450);
      return true;
    } catch {
      __trusted.unavailable = true;
      __trusted.unavailableAt = Date.now();
      return false;
    }
  }

  async function settleRect(el, max = 700) {
    let prev = null;
    const start = Date.now();
    while (Date.now() - start < max) {
      const r = el.getBoundingClientRect();
      const key = [r.top, r.left, r.width, r.height].map(Math.round).join(",");
      if (key === prev) return r;
      prev = key;
      await delay(50);
    }
    return el.getBoundingClientRect();
  }

  // ---- Coordinate calibration ---------------------------------------------
  // On a zoomed-out page (e.g. a phone browser in "desktop site" mode) the
  // debugger's coordinate space doesn't match the page's clientX/clientY.
  // Learn the mapping with two harmless hover moves: send a point, read back
  // where the page says the pointer arrived, solve  client = a * sent + b.
  function readNextMove(timeout = 500) {
    return new Promise((resolve) => {
      const h = (e) => { cleanup(); resolve([e.clientX, e.clientY]); };
      const cleanup = () => { document.removeEventListener("mousemove", h, true); clearTimeout(t); };
      const t = setTimeout(() => { cleanup(); resolve(null); }, timeout);
      document.addEventListener("mousemove", h, true);
    });
  }

  async function sendMove(x, y) {
    const wait = readNextMove();
    try { await chrome.runtime.sendMessage({ action: "pilgrimTrustedMove", x, y }); } catch {}
    return wait;
  }

  async function calibrateTap() {
    const vv = window.visualViewport;
    const key = [window.innerWidth, window.innerHeight, vv ? vv.scale.toFixed(3) : 1, vv ? Math.round(vv.offsetLeft) : 0, vv ? Math.round(vv.offsetTop) : 0].join("x");
    if (__trusted.map && __trusted.mapKey === key && Date.now() - __trusted.mapAt < 20000) return __trusted.map;
    const identity = { ax: 1, bx: 0, ay: 1, by: 0 };
    const w = Math.max(window.innerWidth, 200), h = Math.max(window.innerHeight, 200);
    const s1 = [Math.round(w * 0.1), Math.round(h * 0.1)];
    const s2 = [Math.round(w * 0.35), Math.round(h * 0.35)];
    const l1 = await sendMove(s1[0], s1[1]);
    const l2 = await sendMove(s2[0], s2[1]);
    let map = identity;
    if (l1 && l2 && s2[0] !== s1[0] && s2[1] !== s1[1]) {
      const ax = (l2[0] - l1[0]) / (s2[0] - s1[0]);
      const ay = (l2[1] - l1[1]) / (s2[1] - s1[1]);
      if (isFinite(ax) && isFinite(ay) && ax > 0.05 && ay > 0.05 && ax < 20 && ay < 20) {
        map = { ax, bx: l1[0] - ax * s1[0], ay, by: l1[1] - ay * s1[1] };
      }
    }
    __trusted.map = map;
    __trusted.mapKey = key;
    __trusted.mapAt = Date.now();
    return map;
  }

  async function trustedTap(el) {
    try {
      if (!el || !(await ensureTrusted())) return false;
      try { el.scrollIntoView({ block: "center", behavior: "instant" }); } catch { el.scrollIntoView({ block: "center" }); }
      let r = await settleRect(el);
      if (r.width <= 0 || r.height <= 0) return false;
      const point = (rect) => [
        Math.round(Math.min(Math.max(rect.left + rect.width / 2, 1), window.innerWidth - 1)),
        Math.round(Math.min(Math.max(rect.top + rect.height / 2, 1), window.innerHeight - 1))
      ];
      const map = await calibrateTap();
      let [x, y] = point(r);
      // Measure again right before tapping; if the element moved (layout
      // shift, smooth scroll), use the fresh position.
      const r2 = el.getBoundingClientRect();
      if (Math.abs(r2.top - r.top) > 2 || Math.abs(r2.left - r.left) > 2) { r = await settleRect(el); [x, y] = point(r); }
      // Convert the wanted page position into the debugger's coordinate space.
      x = Math.max(0, Math.round((x - map.bx) / map.ax));
      y = Math.max(0, Math.round((y - map.by) / map.ay));
      const res = await chrome.runtime.sendMessage({ action: "pilgrimTrustedTap", x, y });
      __trusted.last = Date.now();
      if (!res || !res.ok) { __trusted.ready = false; return false; }
      return true;
    } catch {
      return false;
    }
  }

  function optionNearTrigger(trigger, wanted) {
    const numeric = /^\d{1,2}$/.test(wanted);
    const tr = trigger.getBoundingClientRect();
    const inColumn = (el) => {
      if (!numeric) return true;
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      return cx >= tr.left - 60 && cx <= tr.right + 60 && cy >= tr.top - 10 && cy <= tr.bottom + 600;
    };
    let scope = trigger.parentElement;
    for (let hop = 0; scope && hop < 6; hop++, scope = scope.parentElement) {
      const f = [...scope.querySelectorAll("*")].find(
        (el) => el !== trigger && !trigger.contains(el) && isVisible(el) && el.children.length === 0 && textOf(el) === wanted && inColumn(el)
      );
      if (f) return f;
    }
    return numeric ? null : findOptionByTextAnywhere(wanted);
  }

  function fiberOf(el) {
    if (!el) return null;
    const k = Object.keys(el).find((x) => x.startsWith("__reactFiber$") || x.startsWith("__reactInternalInstance$"));
    return k ? el[k] : null;
  }

  function fiberName(f) {
    const t = f?.type;
    if (!t) return "?";
    return typeof t === "string" ? t : t.displayName || t.name || (t.render && t.render.name) || "Component";
  }

  // Human-readable summary of the React component chain above an element,
  // used by the debug probe: component names, handler-ish prop names, and
  // any short arrays (likely the dropdown options).
  function describeFibers(el, max = 9) {
    const out = [];
    let f = fiberOf(el);
    for (let i = 0; f && i < max; f = f.return, i++) {
      const props = f.memoizedProps;
      if (!props || typeof props !== "object") { out.push(`${fiberName(f)}`); continue; }
      const fns = Object.keys(props).filter((k) => typeof props[k] === "function").join(",");
      const arrs = Object.keys(props)
        .filter((k) => Array.isArray(props[k]) && props[k].length && props[k].length < 40)
        .map((k) => `${k}=${JSON.stringify(props[k]).slice(0, 70)}`)
        .join(" ");
      out.push(`${fiberName(f)}{${fns}} ${arrs}`.trim());
    }
    return out;
  }

  const FN_OK = /change|select|choose|pick|^set|value/i;
  const FN_BAD = /click|focus|blur|key|mouse|touch|submit|close|open|toggle|remove|delete|scroll|press|drag|hover/i;

  async function setViaReactProps(trigger, wanted, text) {
    let f = fiberOf(trigger);
    let attempts = 0;
    for (let depth = 0; f && depth < 12 && attempts < 40; f = f.return, depth++) {
      const props = f.memoizedProps;
      if (!props || typeof props !== "object") continue;
      // exact option object from any options-like array on this component
      let option = text;
      for (const v of Object.values(props)) {
        if (!Array.isArray(v) || !v.length || v.length > 60) continue;
        const hit = v.find((e) =>
          typeof e === "string"
            ? e.trim().toLowerCase() === wanted
            : e && typeof e === "object" && Object.values(e).some((x) => typeof x === "string" && x.trim().toLowerCase() === wanted)
        );
        if (hit !== undefined) { option = hit; break; }
      }
      const optText = typeof option === "string" ? option : (Object.values(option).find((x) => typeof x === "string" && x.trim().toLowerCase() === wanted) || text);
      const fns = Object.keys(props).filter((k) => typeof props[k] === "function" && FN_OK.test(k) && !FN_BAD.test(k));
      for (const k of fns) {
        const argSets = [
          [option],
          [optText],
          [{ target: { name: trigger.name, value: optText }, currentTarget: { name: trigger.name, value: optText }, preventDefault() {}, stopPropagation() {}, persist() {} }],
          [trigger.name, optText],
          [optText, trigger.name]
        ];
        for (const args of argSets) {
          attempts++;
          try { props[k](...args); } catch {}
          await delay(140);
          if (dropdownLooksSelected(trigger, wanted)) return true;
        }
      }
    }
    return false;
  }

  function clickOptionEl(target) {
    target.scrollIntoView({ block: "center" });
    const row = target.closest('li, [role="option"], [class*="option"], [class*="item"]') || target;
    const nodes = row === target ? [target] : [target, row];
    for (const n of nodes) {
      fireClickSequence(n);
      try { n.click?.(); } catch {}
    }
  }

  async function selectFromDropdownOnce(trigger, rawValue, key, dryRun) {
    if (!rawValue) return { ok: false, reason: "no value provided" };
    const alias = VALUE_ALIASES[key]?.[String(rawValue).toLowerCase()];
    const wanted = (alias || rawValue).toString().trim().toLowerCase();
    // "Real taps unavailable" is only ever a temporary state (the debugger
    // bar was dismissed, a stale attach…) — retry instead of staying broken
    // until the page is reloaded.
    if (__trusted.unavailable && Date.now() - (__trusted.unavailableAt || 0) > 4000) {
      __trusted.unavailable = false; __trusted.ready = false; __trusted.map = null;
    }

    if (dryRun) {
      markDry(trigger);
      return { ok: true, dryRun: true };
    }

    if (trigger.tagName && trigger.tagName.toLowerCase() === "select") {
      return setPlainValue(trigger, alias || rawValue)
        ? { ok: true }
        : { ok: false, reason: `no <option> matching "${wanted}"` };
    }

    const done = () => {
      flashField(trigger);
      __recentSets.push({ field: trigger, value: null, dropdown: true });
      return { ok: true };
    };

    if (dropdownLooksSelected(trigger, wanted) && String(trigger.value || "").trim()) return done();

    const numeric = /^\d{1,2}$/.test(wanted);

    // STEP A — a genuine tap on the trigger, then on the option (fast path;
    // the page ignores synthetic events for these custom dropdowns).
    if (!__trusted.unavailable) {
      if (await trustedTap(trigger)) {
        let opt = await waitFor(() => optionNearTrigger(trigger, wanted), 1200, 50);
        if (!opt) opt = await scrollListToFind(trigger, wanted);
        if (opt && (await trustedTap(opt))) {
          if (await waitFor(() => dropdownLooksSelected(trigger, wanted), 700, 50)) return done();
        }
        // close a half-open list with a tap-free Escape and fall through
        document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        await delay(100);
      }
    }

    // STEP B — synthetic events (the original flow). Short timeouts.
    {
      trigger.scrollIntoView({ block: "center" });
      try { trigger.focus?.(); } catch {}
      fireClickSequence(trigger);
      const t1 = await waitFor(() => {
        const menu = findOpenMenu();
        if (menu) {
          const o = [...menu.querySelectorAll('[role="option"], li, .mat-option, .p-dropdown-item, .ng-option, .select2-results__option')]
            .find((el) => textOf(el) === wanted);
          if (o) return o;
        }
        return optionNearTrigger(trigger, wanted);
      }, 600, 60);
      if (t1) {
        t1.scrollIntoView({ block: "center" });
        fireClickSequence(t1);
        if (await waitFor(() => dropdownLooksSelected(trigger, wanted), 400, 50)) return done();
        callReactChain(t1, ["onMouseDown", "onClick"], 3);
        if (await waitFor(() => dropdownLooksSelected(trigger, wanted), 400, 50)) return done();
      }
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    }

    let lastReason = __trusted.unavailable
      ? "real taps unavailable in this browser and synthetic clicks did not open the list"
      : "real tap did not open/select the option" +
        (__trusted.map ? ` [tap map x×${__trusted.map.ax.toFixed(2)} y×${__trusted.map.ay.toFixed(2)}]` : "");

    // STEP C — extra opening strategies (slow; only if real taps aren't available).
    if (__trusted.unavailable) {
      const opened = await openDropdown(trigger);
      if (opened) {
        const target = opened.fresh.find((el) => textOf(el) === wanted);
        if (target) {
          clickOptionEl(target);
          if (await waitFor(() => dropdownLooksSelected(trigger, wanted), 500, 50)) return done();
          callReactChain(target, ["onMouseDown", "onClick"], 3);
          if (await waitFor(() => dropdownLooksSelected(trigger, wanted), 500, 50)) return done();
        }
      }
    }

    // STEP D — drive the React component directly.
    if (!numeric && (await setViaReactProps(trigger, wanted, String(alias || rawValue)))) return done();

    console.warn("[Pilgrim] dropdown failed", key, wanted, lastReason, trigger);
    return { ok: false, reason: lastReason };
  }


  // ---- menu cleanup / long-list search (v2.12.2) ------------------------
  // A dropdown that failed to pick (e.g. State) can leave its floating list
  // or an invisible full-screen backdrop behind. That survives in-page
  // navigation (home -> booking page), so the next visit's taps land on the
  // stale backdrop instead of Gender / Photo ID Proof until a full reload.
  function visibleBackdrops() {
    const out = [];
    for (const el of document.querySelectorAll('.MuiBackdrop-root, .MuiModal-backdrop, .cdk-overlay-backdrop, .p-component-overlay, [class*="backdrop" i]')) {
      if (!isVisible(el)) continue;
      if (el.id === "__pilgrimPayCountdown" || el.id === "__pilgrimBgStatus") continue;
      const r = el.getBoundingClientRect();
      if (r.width >= window.innerWidth * 0.9 && r.height >= window.innerHeight * 0.9) out.push(el);
    }
    return out;
  }

  function anyMenuOpen() {
    const m = findOpenMenu();
    return !!(m && isVisible(m)) || visibleBackdrops().length > 0;
  }

  async function closeOpenMenus() {
    if (!anyMenuOpen()) return false;
    for (let i = 0; i < 3 && anyMenuOpen(); i++) {
      for (const t of [document.activeElement, document, document.body]) {
        if (!t) continue;
        for (const type of ["keydown", "keyup"]) {
          try { t.dispatchEvent(new KeyboardEvent(type, { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true })); } catch {}
        }
      }
      for (const b of visibleBackdrops()) { try { fireClickSequence(b); } catch {} }
      await delay(150);
      if (anyMenuOpen() && !__trusted.unavailable) {
        try { await chrome.runtime.sendMessage({ action: "pilgrimTrustedKey", key: "Escape" }); } catch {}
        await delay(150);
      }
    }
    return true;
  }

  // The wanted option can sit below the fold of a scrollable list (State has
  // ~36 entries). Scroll the list in steps until it renders.
  async function scrollListToFind(trigger, wanted) {
    const tr = trigger.getBoundingClientRect();
    const boxes = [...document.querySelectorAll("ul, div, [role=listbox], [role=menu]")].filter((el) => {
      if (!isVisible(el) || el === document.body || el.contains(trigger)) return false;
      if (el.scrollHeight <= el.clientHeight + 8) return false;
      if (!/(auto|scroll)/.test(getComputedStyle(el).overflowY)) return false;
      const r = el.getBoundingClientRect();
      return r.top > tr.top - 700 && r.top < tr.bottom + 700 && r.width < window.innerWidth * 0.95;
    });
    for (const box of boxes) {
      box.scrollTop = 0;
      for (let i = 0; i < 25; i++) {
        const opt = optionNearTrigger(trigger, wanted);
        if (opt && isVisible(opt)) return opt;
        const before = box.scrollTop;
        box.scrollTop += Math.max(60, box.clientHeight * 0.7);
        await delay(80);
        if (box.scrollTop === before) break;
      }
      const opt = optionNearTrigger(trigger, wanted);
      if (opt && isVisible(opt)) return opt;
    }
    return null;
  }

  async function selectFromDropdown(trigger, rawValue, key, dryRun) {
    if (dryRun || !rawValue || (trigger.tagName && trigger.tagName.toLowerCase() === "select")) {
      return selectFromDropdownOnce(trigger, rawValue, key, dryRun);
    }
    let res = { ok: false, reason: "not attempted" };
    for (let attempt = 0; attempt < 3; attempt++) {
      if (!trigger.isConnected) break; // re-rendered; the next scan pass finds the new control
      await closeOpenMenus();
      if (attempt > 0) {
        __trusted.ready = false; __trusted.unavailable = false; __trusted.map = null;
        await delay(400 * attempt);
      }
      res = await selectFromDropdownOnce(trigger, rawValue, key, dryRun);
      if (res.ok) return res;
    }
    await closeOpenMenus(); // never leave a half-open list behind
    return res;
  }

  // ---------------------------------------------------------------------
  // Dry-run support: instead of actually writing a value / clicking an
  // option, outline the field/element that WOULD have been used so a
  // person can verify TTD hasn't changed the page before trusting it with
  // a real queue slot. Never dispatches input/change/click — purely
  // visual, and the outline clears itself after a few seconds.
  // ---------------------------------------------------------------------
  function markDry(field, ok = true) {
    if (!field || !field.style) return;
    const prevOutline = field.style.outline;
    const prevOffset = field.style.outlineOffset;
    field.style.outline = ok ? "3px solid #22c55e" : "3px solid #f59e0b";
    field.style.outlineOffset = "1px";
    field.scrollIntoView?.({ block: "center" });
    clearTimeout(field.__pilgrimDryTimer);
    field.__pilgrimDryTimer = setTimeout(() => {
      field.style.outline = prevOutline;
      field.style.outlineOffset = prevOffset;
    }, 4000);
  }

  // Field-confidence flash: a brief, quieter green outline right after a
  // REAL write succeeds (as opposed to markDry's dry-run preview above) —
  // lets you visually confirm, glancing at the actual page, which fields
  // this pass touched, without needing the popup's toast/log for that.
  function flashField(field, ok = true) {
    if (!field || !field.style) return;
    const prevOutline = field.style.outline;
    const prevOffset = field.style.outlineOffset;
    field.style.outline = ok ? "2px solid #22c55e" : "2px solid #f59e0b";
    field.style.outlineOffset = "1px";
    clearTimeout(field.__pilgrimFlashTimer);
    field.__pilgrimFlashTimer = setTimeout(() => {
      field.style.outline = prevOutline;
      field.style.outlineOffset = prevOffset;
    }, 1100);
  }

  function setPlainValue(field, value, dryRun) {
    if (value === undefined || value === null || value === "") return false;
    if (dryRun) {
      markDry(field);
      return true;
    }
    const tag = field.tagName.toLowerCase();

    if (tag === "select") {
      const opt = [...field.options].find(
        (o) =>
          o.value.toLowerCase() === String(value).toLowerCase() ||
          textOf(o) === String(value).toLowerCase() ||
          textOf(o).includes(String(value).toLowerCase())
      );
      if (!opt) return false;
      field.value = opt.value;
    } else if (field.type === "radio" || field.type === "checkbox") {
      const label = labelForField(field);
      if (!label.includes(String(value).toLowerCase())) return false;
      field.checked = true;
    } else {
      typeLikeUser(field, String(value));
      trackSet(field, String(value));
      flashField(field);
      return true;
    }

    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
    field.dispatchEvent(new Event("blur", { bubbles: true }));
    flashField(field);
    return true;
  }

  // Values we wrote, so we can verify the page didn't wipe them afterwards.
  let __recentSets = [];
  function trackSet(field, value) {
    __recentSets.push({ field, value });
  }

  // Types into a field the way a real keyboard/IME would. execCommand
  // ("insertText") makes the browser itself fire beforeinput + input with
  // proper InputEvent data, which React/Angular/Vue form models accept.
  // A bare `.value = x` + synthetic Event is ignored (or overwritten on the
  // next re-render) by many frameworks — manual typing worked for that reason.
  function typeLikeUser(field, value) {
    const nativeSetter = Object.getOwnPropertyDescriptor(
      field.tagName.toLowerCase() === "textarea" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype,
      "value"
    )?.set;
    try { field.scrollIntoView?.({ block: "center" }); } catch {}
    try { field.focus(); } catch {}
    try { fireClickSequence(field); } catch {}
    try { field.focus(); } catch {}

    // Clear any existing text, then insert as a real edit.
    let ok = false;
    try {
      if (field.value) {
        if (nativeSetter) nativeSetter.call(field, ""); else field.value = "";
        field.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward", data: null }));
      }
      try { field.select(); } catch {}
      ok = document.execCommand("insertText", false, value);
    } catch {
      ok = false;
    }

    // Fallback: native setter + realistic InputEvent + key events.
    if (!ok || field.value !== value) {
      if (nativeSetter) nativeSetter.call(field, value); else field.value = value;
      try {
        field.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: value.slice(-1) }));
        field.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertText", data: value }));
        field.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
        field.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: value.slice(-1) }));
      } catch {
        field.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }
    field.dispatchEvent(new Event("change", { bubbles: true }));
    // A real blur (not a synthetic one) so touched/validation state updates.
    try { field.blur(); } catch { field.dispatchEvent(new Event("blur", { bubbles: true })); }
  }

  /**
   * Bucket matches by key, sort each bucket by document order, then assign
   * the n-th matching field/trigger to the n-th pilgrim — mirrors how a
   * multi-pilgrim table repeats the same columns.
   */
  function bucketByKey(matches) {
    const byKey = {};
    for (const m of matches) (byKey[m.key] ||= []).push(m.field);
    for (const list of Object.values(byKey)) {
      list.sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
    }
    return byKey;
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Pick whichever match we actually found for a select-like field: a real
  // native <select> (matched into the plain-fields bucket) takes priority
  // since it's the simplest/most reliable to set; otherwise fall back to a
  // custom-widget trigger (matched into the dropdown-triggers bucket).
  function pickSelectOrTrigger(key, idx, plainByKey, dropdownByKey) {
    const plainField = plainByKey[key]?.[idx];
    if (plainField && plainField.tagName && plainField.tagName.toLowerCase() === "select") {
      return plainField;
    }
    return dropdownByKey[key]?.[idx] || plainField || null;
  }

  // Fresh scan of the plain (input/select/textarea) fields, bucketed by key.
  // Re-running this — instead of reusing a snapshot from before the
  // dropdowns were touched — matters because some sites (TTD's form
  // included) keep "Photo Id Number" disabled until "Photo ID Proof" has
  // been chosen. A field disabled at scan time is filtered out by
  // isFillable and never reconsidered unless we scan again afterward.
  function currentPlainByKey() {
    const { plain } = collectFields();
    return bucketByKey(classifyList(plain));
  }

  async function fillPilgrims(pilgrims, initialPlainByKey, dropdownByKey, dryRun) {
    let filledCount = 0;
    const missed = [];
    const keys = new Set();
    for (let idx = 0; idx < pilgrims.length; idx++) {
      const pilgrim = pilgrims[idx];

      const nameField = initialPlainByKey.name?.[idx];
      if (nameField && setPlainValue(nameField, pilgrim.name, dryRun)) { filledCount++; keys.add("name"); }

      const ageField = initialPlainByKey.age?.[idx];
      if (ageField && setPlainValue(ageField, pilgrim.age, dryRun)) { filledCount++; keys.add("age"); }

      // Dropdowns first — selecting these can reveal/enable a dependent
      // field (Photo Id Number depends on Photo ID Proof). Run them one at
      // a time since each opens/closes a floating menu.
      //
      // Gender/idType can be matched into EITHER bucket depending on how
      // the site renders them: a real native <select> lands in
      // initialPlainByKey (same bucket as Name/Age), while a custom
      // MUI/Angular/etc widget lands in dropdownByKey. Previously only
      // dropdownByKey was checked here, so a native <select> match was
      // found during scanning but then never actually filled — which is
      // exactly the "gender & photo id proof not selecting" symptom.
      // selectFromDropdown() already knows how to set a native <select>
      // directly (no menu-hunting needed), so just feed it whichever kind
      // of match we found, preferring the native <select> when present.
      const genderTrigger = pickSelectOrTrigger("gender", idx, initialPlainByKey, dropdownByKey);
      if (genderTrigger) {
        const res = await selectFromDropdown(genderTrigger, pilgrim.gender, "gender", dryRun);
        if (res.ok) { filledCount++; keys.add("gender"); }
        else missed.push(`gender: ${res.reason}`);
      } else if (pilgrim.gender) {
        missed.push("gender: no field/dropdown found on page");
      }

      const idTypeTrigger = pickSelectOrTrigger("idType", idx, initialPlainByKey, dropdownByKey);
      if (idTypeTrigger) {
        const value = pilgrim.idType === "Passport" ? "Passport" : "Aadhaar";
        const res = await selectFromDropdown(idTypeTrigger, value, "idType", dryRun);
        if (res.ok) { filledCount++; keys.add("idType"); }
        else missed.push(`idType: ${res.reason}`);
      } else if (pilgrim.idType) {
        missed.push("idType: no field/dropdown found on page");
      }

      // Give the page a moment to react (enable/render) to the idType
      // selection, then re-scan for the id number field before trying it.
      // Dry-run never actually selects idType above, so the dependent
      // field is very likely still disabled — that's an accepted
      // limitation of previewing a fresh page, not a bug: it just means
      // idNumber may show up as "missed" until idType is genuinely picked.
      await delay(200);
      let idNumberField = currentPlainByKey().idNumber?.[idx];
      if (!idNumberField) {
        // Field may need a beat longer on slower pages — try once more.
        await delay(400);
        idNumberField = currentPlainByKey().idNumber?.[idx];
      }
      if (!idNumberField) idNumberField = initialPlainByKey.idNumber?.[idx];
      if (idNumberField && setPlainValue(idNumberField, pilgrim.idNumber, dryRun)) { filledCount++; keys.add("idNumber"); }
      else if (pilgrim.idNumber) missed.push("idNumber: field not found or still disabled");
    }
    return { filledCount, missed, keys: [...keys] };
  }

  async function fillContact(contact, plainByKey, dropdownByKey, dryRun) {
    let filledCount = 0;
    const keys = [];
    const skipped = [];
    // Fresh scan fallback: contact inputs can render after the first snapshot.
    let fresh = null;
    for (const key of ["email", "city", "state", "country", "pincode", "gothram"]) {
      const value = contact?.[key];
      if (value == null || value === "") {
        skipped.push(`${key}: no value saved`);
        continue;
      }
      let trigger = pickSelectOrTrigger(key, 0, plainByKey, dropdownByKey);
      if (!trigger || !trigger.isConnected) {
        fresh ||= currentPlainByKey();
        trigger = pickSelectOrTrigger(key, 0, fresh, dropdownByKey);
      }
      if (!trigger) {
        skipped.push(`${key}: not on this page`);
        continue;
      }
      const tag = trigger.tagName?.toLowerCase();
      const looksLikeDropdown = tag === "select" || tag !== "input" ||
        trigger.readOnly || trigger.getAttribute("role") === "combobox";
      const ok = looksLikeDropdown
        ? (await selectFromDropdown(trigger, value, key, dryRun)).ok
        : setPlainValue(trigger, value, dryRun);
      if (ok) { filledCount++; keys.push(key); }
      else skipped.push(`${key}: present but rejected`);
    }
    return { filledCount, keys, skipped };
  }

  function setStandaloneCheckbox(field, truthy, dryRun) {
    if (!field) return false;
    if (dryRun) {
      markDry(field);
      return true;
    }
    // A real click toggles the control AND updates React/Angular state;
    // assigning .checked and firing "change" does neither for most forms.
    if (checkboxIsChecked(field) !== !!truthy) {
      field.scrollIntoView?.({ block: "center" });
      fireClickSequence(field);
      if (checkboxIsChecked(field) !== !!truthy) { try { field.click(); } catch {} }
    }
    flashField(field);
    return checkboxIsChecked(field) === !!truthy;
  }

  /**
   * Generic single-record filler, used for the Srivari Seva profile and
   * for each person in a Seva (Group) roster (Team Leader + Team Members).
   * `keys` is the ordered list of data keys to try; `idx` picks which
   * repeated field (n-th on the page) to use for that key — 0 for a
   * single-instance form like Srivari Seva, or the person's position for a
   * repeated table like Seva (Group) members.
   */
  async function fillKeyedFields(data, idx, keys, plainByKey, dropdownByKey, dryRun) {
    let filledCount = 0;
    const missed = [];
    const filledKeys = [];

    for (const key of keys) {
      const value = data[key];

      if (STANDALONE_CHECKBOX_KEYS.includes(key)) {
        const field = plainByKey[key]?.[idx];
        if (field) {
          if (setStandaloneCheckbox(field, value, dryRun)) { filledCount++; filledKeys.push(key); }
        } else if (value) {
          missed.push(`${key}: no checkbox found on page`);
        }
        continue;
      }

      if (SELECT_LIKE_KEYS.includes(key)) {
        const trigger = pickSelectOrTrigger(key, idx, plainByKey, dropdownByKey);
        if (trigger) {
          if (!value) continue;
          const res = await selectFromDropdown(trigger, value, key, dryRun);
          if (res.ok) { filledCount++; filledKeys.push(key); }
          else missed.push(`${key}: ${res.reason}`);
        } else if (value) {
          missed.push(`${key}: no field/dropdown found on page`);
        }
        continue;
      }

      const field = plainByKey[key]?.[idx];
      if (field) {
        if (setPlainValue(field, value, dryRun)) { filledCount++; filledKeys.push(key); }
      } else if (value) {
        missed.push(`${key}: field not found on page`);
      }
    }

    return { filledCount, missed, keys: filledKeys };
  }

  const SRIVARI_SEVA_KEYS = [
    "mobile", "email", "bloodGroup", "gender", "mentallyFit", "physicallyFit",
    "street", "doorNo", "pincode", "country", "state", "district", "city",
    "qualification", "university", "yearOfGraduation", "specialization",
    "profession", "employmentStatus", "sector", "professionCategory"
  ];

  const SEVA_PERSON_KEYS = [
    "idType", "idNumber", "name", "surname", "fatherSpouseName", "dob", "age",
    "mobile", "email", "street", "doorNo", "pincode", "country", "state",
    "district", "city", "nearestTemple"
  ];

  async function fillSrivariSeva(profile, plainByKey, dropdownByKey, dryRun) {
    return fillKeyedFields(profile, 0, SRIVARI_SEVA_KEYS, plainByKey, dropdownByKey, dryRun);
  }

  // Fills a roster of Seva (Group) people (Team Leader is just a
  // one-person roster) against the n-th repeated field on the page —
  // mirrors fillPilgrims' "n-th match goes to n-th person" approach.
  async function fillSevaPeople(people, plainByKey, dropdownByKey, dryRun) {
    let filledCount = 0;
    let missed = [];
    const keys = new Set();
    for (let idx = 0; idx < people.length; idx++) {
      const res = await fillKeyedFields(people[idx], idx, SEVA_PERSON_KEYS, plainByKey, dropdownByKey, dryRun);
      filledCount += res.filledCount;
      missed = missed.concat(res.missed);
      (res.keys || []).forEach((k) => keys.add(k));
    }
    return { filledCount, missed, keys: [...keys] };
  }

  // Diagnostic helper: run window.__pilgrimAutofillDebug() in the page's
  // dev console (F12 → Console tab) while the pilgrim form is on screen.
  // It logs what the extension actually sees for Gender / Photo ID Proof
  // so a mismatch can be fixed precisely instead of guessed at.
  window.__pilgrimAutofillDebug = function () {
    const { plain, dropdownTriggers } = collectFields();
    console.group("Pilgrim Assistant — field scan");
    console.log(`Plain inputs/selects found: ${plain.length}`);
    console.log(`Dropdown-like triggers found: ${dropdownTriggers.length}`);
    [...plain, ...dropdownTriggers].forEach((f) => {
      const sig = signature(f);
      if (/gender|sex|photo id|id proof|document type/i.test(sig)) {
        console.log("Candidate:", f, "| signature:", sig, "| tag:", f.tagName, "| classes:", f.className);
      }
    });
    console.groupEnd();
    return { plainCount: plain.length, dropdownCount: dropdownTriggers.length };
  };

  // TTD's Srivari Seva (and similar Seva) review screen renders each
  // pilgrim as a card with a small checkbox at the top-left. Filling the
  // card's text is NOT enough: Continue stays disabled until that card is
  // explicitly selected. Do this after all fields have been filled, and
  // only click checkboxes that are inside a visible pilgrim-like card so
  // we never accidentally toggle unrelated consent/fitness checkboxes.
  function pilgrimCardSignature(card) {
    return textOf(card).replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function findPilgrimCardCheckboxes() {
    const out = [];
    const checkboxes = [...document.querySelectorAll('input[type="checkbox"], [role="checkbox"]')].filter(isVisible);
    for (const cb of checkboxes) {
      let node = cb;
      let found = null;
      for (let hop = 0; node && hop < 7; hop++, node = node.parentElement) {
        const sig = pilgrimCardSignature(node);
        // A pilgrim card normally contains identifying fields such as a
        // person's name, gender/age, DOB, or masked ID number. Require at
        // least one strong identity cue and enough text to avoid matching
        // tiny standalone checkboxes.
        const identityCue = /(\bdob\b|\bage\b|\bmale\b|\bfemale\b|transgender|aadhaar|aadhar|passport|\bname\b|\byears?\b|sevak|pilgrim)/i.test(sig);
        if (identityCue && sig.length >= 20) {
          found = cb;
          break;
        }
      }
      if (found) out.push(cb);
    }
    return [...new Set(out)];
  }

  function checkboxIsChecked(cb) {
    if (cb instanceof HTMLInputElement) return !!cb.checked;
    return cb.getAttribute('aria-checked') === 'true' || cb.classList.contains('checked') || cb.classList.contains('Mui-checked');
  }

  async function ensurePilgrimCardsSelected(expectedCount = 0, dryRun) {
    const boxes = findPilgrimCardCheckboxes();
    // Confirmed against a real recording: Special Entry Darshan's Pilgrim
    // Details page has no such checkbox at all — the review page's own
    // Note even says clicking Pay Now itself is what confirms acceptance,
    // nothing to tick beforehand. Only Srivari Seva actually uses this
    // per-card checkbox pattern. So finding zero checkboxes on the page
    // is the NORMAL case for most flows, not a problem — report it as ok
    // so scanAndFill doesn't add a false "pilgrim selection: not found"
    // warning to every single successful Special Entry Darshan fill.
    if (!boxes.length) return { ok: true, selected: 0, none: true };

    if (dryRun) {
      boxes.forEach((cb) => markDry(cb));
      // Report success without actually clicking anything — there's
      // nothing further to verify here in a preview.
      return { ok: true, selected: boxes.length };
    }

    let selected = 0;
    for (const cb of boxes) {
      if (!checkboxIsChecked(cb)) {
        cb.scrollIntoView({ block: 'center' });
        fireClickSequence(cb);
        await delay(120);
      }
      if (checkboxIsChecked(cb)) selected++;
    }

    // The number shown in the Seva Details card is the authoritative
    // requested count when available. If we know it, require at least that
    // many selected cards before declaring success. Otherwise at least one
    // selected pilgrim is enough for a one-person booking.
    const needed = expectedCount > 0 ? expectedCount : 1;
    if (selected >= needed) return { ok: true, selected };
    return { ok: false, selected, reason: `only ${selected} pilgrim card(s) selected; ${needed} required` };
  }

  function continueButtonReady(btn) {
    if (!btn) return false;
    if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') return false;
    if (btn.classList?.contains('disabled')) return false;
    const opacity = parseFloat(getComputedStyle(btn).opacity || '1');
    return opacity > 0.2;
  }

  async function waitForEnabledContinue(timeout = 6000) {
    // Two passes: most of the time the SAME Continue button just flips
    // from disabled to enabled once React catches up with the fill, which
    // waitFor's own polling already covers. But occasionally the button is
    // replaced outright (a re-render swaps the element, not just its
    // disabled attribute) — a fresh findButtonByText() call after a short
    // pause catches that case the first pass's stale reference can't.
    const first = await waitFor(() => {
      const btn = findButtonByText(CONTINUE_TEXTS);
      return continueButtonReady(btn) ? btn : null;
    }, timeout, 120);
    if (first) return first;
    await delay(400);
    return waitFor(() => {
      const btn = findButtonByText(CONTINUE_TEXTS);
      return continueButtonReady(btn) ? btn : null;
    }, 1500, 150);
  }

  async function scanAndFill(payload) {
    // Fresh scan each attempt — reusing triggers found on the first pass
    // could point at whatever new elements React/Angular swapped in
    // during whatever it does on the page after the first pass runs.
    const { plain, dropdownTriggers } = collectFields();
    const plainByKey = bucketByKey(classifyList(plain));
    const dropdownByKey = bucketByKey(classifyList(dropdownTriggers));

    // Page layout-change detector: a cheap signature of how many fields of
    // each kind were actually found on THIS pass, independent of what the
    // payload asked to fill. The caller (popup.js) keeps the last
    // signature seen per page and warns if it shrinks — e.g. TTD swaps in
    // a redesigned form and idNumber/gender quietly stop matching — before
    // that surprise costs a real queue slot instead of just this preview.
    const SIGNATURE_KEYS = ["name", "age", "gender", "idType", "idNumber", "email", "city", "state", "country", "pincode", "mobile", "surname", "dob"];
    const fieldSignature = {};
    for (const k of SIGNATURE_KEYS) {
      const n = (plainByKey[k]?.length || 0) + (dropdownByKey[k]?.length || 0);
      if (n) fieldSignature[k] = n;
    }

    let filledCount = 0;
    let missed = [];
    const filledKeys = new Set();
    const dryRun = !!payload.dryRun;
    if (payload.pilgrims?.length) {
      const res = await fillPilgrims(payload.pilgrims, plainByKey, dropdownByKey, dryRun);
      filledCount += res.filledCount;
      missed = missed.concat(res.missed);
      (res.keys || []).forEach((k) => filledKeys.add(k));
    }
    if (payload.contact) {
      const res = await fillContact(payload.contact, plainByKey, dropdownByKey, dryRun);
      filledCount += res.filledCount;
      (res.keys || []).forEach((k) => filledKeys.add(k));
      if (res.skipped?.length) console.log("[contact]", res.skipped.join(" | "));
    }
    if (payload.srivariSeva) {
      const res = await fillSrivariSeva(payload.srivariSeva, plainByKey, dropdownByKey, dryRun);
      filledCount += res.filledCount;
      missed = missed.concat(res.missed);
      (res.keys || []).forEach((k) => filledKeys.add(k));
    }
    if (payload.sevaPeople?.length) {
      const res = await fillSevaPeople(payload.sevaPeople, plainByKey, dropdownByKey, dryRun);
      filledCount += res.filledCount;
      missed = missed.concat(res.missed);
      (res.keys || []).forEach((k) => filledKeys.add(k));
    }

    // On the Srivari Seva review screen, field filling alone leaves the
    // pilgrim card unchecked and therefore keeps Continue disabled. Select
    // the cards only after data is present, then wait for React/MUI to
    // propagate the checked state into the Continue button.
    if (payload.srivariSeva || payload.pilgrims?.length || payload.sevaPeople?.length) {
      const expected = Number(payload.ticketCount || payload.dateSlot?.ticketCount || payload.srivariSeva?.noOfSevak || payload.sevaPeople?.length || payload.pilgrims?.length || 0);
      const selection = await ensurePilgrimCardsSelected(expected, dryRun);
      if (!selection.ok && selection.selected === 0) missed.push(`pilgrim selection: ${selection.reason}`);
    }
    // Required-field verification is page-aware: contact fields are
    // required only when this page actually renders them.
    if (payload.pilgrims?.length) {
      const pilgrimRequired = ["name", "age", "gender", "idType", "idNumber"];
      const missingPilgrim = pilgrimRequired.filter((k) => !filledKeys.has(k));
      if (missingPilgrim.length) missed.push(`REQUIRED NOT FILLED: ${missingPilgrim.join(", ")}`);
    }
    if (payload.contact) {
      const contactKeys = ["email", "city", "state", "country", "pincode"];
      const contactOnPage = contactKeys.filter((k) =>
        (plainByKey[k]?.length || 0) + (dropdownByKey[k]?.length || 0) > 0
      );
      const missingContact = contactOnPage.filter((k) => !filledKeys.has(k));
      if (missingContact.length) missed.push(`CONTACT NOT FILLED: ${missingContact.join(", ")}`);
    }
    return { filledCount, missed, filledKeys: [...filledKeys], fieldSignature };
  }

  // Diagnostic: describes the Gender / Photo ID Proof controls and what
  // appears when they are opened. Run from the popup's "Debug dropdowns"
  // button; output is plain text for a screenshot.
  window.__pilgrimDropdownProbe = async function () {
    const lines = [];
    const desc = (el) => {
      if (!el) return "null";
      const cls = (el.getAttribute?.("class") || "").slice(0, 60);
      return `<${el.tagName.toLowerCase()}${el.id ? "#" + el.id : ""}${cls ? "." + cls.replace(/\s+/g, ".") : ""}>`;
    };
    const attrs = (el) =>
      [...el.attributes].map((a) => `${a.name}="${String(a.value).slice(0, 25)}"`).join(" ");
    lines.push(`frame: ${window === window.top ? "top" : "iframe"}  iframes:${document.querySelectorAll("iframe").length}`);
    const all = [...document.querySelectorAll("input,select,textarea")].filter(isVisible);
    for (const wantKey of ["gender", "idType", "idNumber"]) {
      const f = all.find((el) => keyFromAttributes(el) === wantKey);
      if (!f) { lines.push(`\n[${wantKey}] NOT FOUND among ${all.length} visible inputs`); continue; }
      lines.push(`\n[${wantKey}] ${desc(f)}`);
      lines.push(`attrs: ${attrs(f)}`);
      lines.push(`value="${f.value}" readOnly=${f.readOnly} disabled=${f.disabled}`);
      let up = f.parentElement;
      for (let i = 0; i < 4 && up; i++, up = up.parentElement) lines.push(`up${i + 1}: ${desc(up)} ${attrs(up).slice(0, 120)}`);
      // Raw HTML of the control's wrapper so the real structure is visible.
      const box = f.closest("div") ? (f.parentElement?.parentElement || f.parentElement) : f.parentElement;
      lines.push(`html: ${(box?.outerHTML || "").replace(/\s+/g, " ").slice(0, 700)}`);
      const disp = findSelectDisplay(f);
      lines.push(`display control: ${desc(disp)} text="${disp ? textOf(disp).slice(0, 20) : ""}"`);
      if (wantKey === "idNumber") continue;
      const propNames = [];
      for (let n = f, i = 0; n && i < 4; n = n.parentElement, i++) {
        const pr = reactPropsOf(n);
        if (pr) propNames.push(`${n.tagName.toLowerCase()}:${Object.keys(pr).filter((k) => /^on/.test(k)).join(",")}`);
      }
      lines.push(`react handlers: ${propNames.join("  ") || "none (not React?)"}`);
      for (const l of describeFibers(f)) lines.push(`fiber: ${l}`);
      const opened = await openDropdown(f);
      lines.push(opened ? `OPENED via ${opened.method}: ${opened.fresh.length} new elements` : "NOT opened by any method");
      for (const el of (opened ? opened.fresh : []).slice(0, 12)) lines.push(`  ${desc(el)} "${textOf(el).slice(0, 25)}"`);
      const lb = document.querySelector('[role="listbox"],[role="menu"],.mat-select-panel,.cdk-overlay-pane,.p-dropdown-panel,.dropdown-menu,ul.options');
      lines.push(`listbox-like container: ${lb ? desc(lb) : "none"}`);
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      await delay(200);
    }
    return lines.join("\n");
  };

  window.__pilgrimAutofillRun = async function (payload) {
    try {
      // Start every run from a clean slate: this content script survives
      // in-page (SPA) navigation, so state left by a previous run — a stale
      // "real taps unavailable" flag, an open dropdown, old calibration —
      // used to make the 2nd Fill on a re-opened booking page skip Gender /
      // Photo ID Proof until the page was reloaded.
      __trusted.unavailable = false; __trusted.ready = false; __trusted.map = null;
      try { await closeOpenMenus(); } catch (_) {}
      // The booking calendar's ticket-count dropdown and slot list don't
      // exist in the DOM at all until a date's actually been picked, and
      // Pilgrim Details doesn't exist until Continue's been clicked after
      // that — so a requested date/slot/ticket-count can't just be folded
      // into the same scanAndFill pass as pilgrims/contact. Handle it as a
      // pre-step instead, only when this page still looks like the
      // calendar (skipped entirely for Angapradakshana/Srivani, which
      // never send payload.dateSlot, and for a second "Fill All Details"
      // tap once the person's already past this screen).
      let dateSlotResult = null;
      if (payload.dateSlot?.date && looksLikeDateSlotPage()) {
        dateSlotResult = await selectDateSlot(payload.dateSlot, !!payload.dryRun);
        if (dateSlotResult.ok && !payload.dryRun) {
          // Continue was already clicked inside selectDateSlot on success —
          // give the next page (Pilgrim Details) a moment to render before
          // scanning it. Dry-run never actually clicks Continue (see
          // selectDateSlot), so there's no new page to wait for here.
          await delay(300);
        }
      }

      __recentSets = [];
      let result = await scanAndFill(payload);

      // The very first fill right after page load can race ahead of the
      // page finishing its own setup (dropdowns not yet interactive,
      // dependent fields not yet enabled). Rather than make the person
      // tap Fill twice, retry automatically once things settle.
      for (let pass = 0; pass < 3 && result.missed.length; pass++) {
        await delay(350 + pass * 250);
        __trusted.unavailable = false; __trusted.ready = false;
        const retry = await scanAndFill(payload);
        // Keep the attempt with fewer leftovers (then more fills).
        if (retry.missed.length < result.missed.length || (retry.missed.length === result.missed.length && retry.filledCount >= result.filledCount)) result = retry;
      }

      // The form can wipe values a moment after we write them (its own
      // async init / re-render). Verify they stuck and refill if not.
      if (!payload.dryRun) {
        for (let attempt = 0; attempt < 2; attempt++) {
          await delay(300);
          const lost = __recentSets.filter((r) => {
            if (!r.field.isConnected) return true;
            if (r.dropdown) {
              const d = findSelectDisplay(r.field);
              return !String(r.field.value || (d && d.textContent) || "").replace(/\u200b/g, "").trim();
            }
            return r.field.value !== r.value;
          });
          if (!lost.length) break;
          __recentSets = [];
          const again = await scanAndFill(payload);
          if (again.filledCount >= result.filledCount) result = again;
        }
      }

      if (dateSlotResult && !dateSlotResult.ok) {
        result.missed = [...(result.missed || []), `date/slot: ${dateSlotResult.reason}`];
      }

      return result;
    } catch (err) {
      // Surface the real failure instead of letting it fail silently —
      // popup.js shows this in the toast so we're not debugging blind.
      return { filledCount: 0, error: (err && err.message) || String(err) };
    }
  };

  // ---------------------------------------------------------------------
  // Auto Continue → Pay Now
  //
  // After the form is filled, this clicks the "Continue" button once, waits
  // for the next screen's "Pay Now" button to appear, then gives the person
  // a visible on-page countdown with a Cancel button before clicking Pay Now
  // for them. Nothing about a real payment should happen invisibly, so the
  // countdown overlay is not optional — it's the only thing standing between
  // "auto-fill" and "auto-pay," and it always shows before that final click.
  // ---------------------------------------------------------------------

  const CONTINUE_TEXTS = ["continue", "proceed", "next"];
  const PAY_TEXTS = ["pay now", "proceed to pay", "make payment", "pay"];
  // Accept both the app's real name and the common "phone pay" misspelling.
  const PHONEPE_TEXTS = ["phonepe", "phone pe", "phone pay"];
  // Card / Debit Card payment option, matched against a payment tile the
  // same way PHONEPE_TEXTS is (label text, aria-label, alt text, etc.).
  // TTD's own page renders this as "Credit/Debit/ATM Card" — a chevron row
  // in a separate "How would you want to pay?" list that NAVIGATES to a
  // new screen, rather than a radio in the UPI list above it.
  const CARD_TEXTS = [
    "credit/debit/atm card",
    "debit/credit/atm card",
    "debit/credit card",
    "credit/debit card",
    "credit/debit cards",
    "credit/debit/atm cards",
    "credit card/debit card",
    "credit card",
    "debit card",
    "atm/debit card",
    "atm card",
    "cards",
    "card"
  ];
  // Angapradakshana bookings have no payment step — the final action on that
  // flow is a "Book Now" / "Confirm Booking" button instead of Pay Now.
  const BOOK_TEXTS = ["book now", "confirm booking", "book slot", "book"];

  function isClickEnabled(el) {
    if (!el) return false;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    if (el.classList?.contains("disabled")) return false;
    return isVisible(el);
  }

  // Finds the best visible/enabled clickable element whose own text
  // (not a descendant's) matches one of the candidate phrases. Exact
  // matches are preferred over "contains" matches so "Continue" doesn't
  // get shadowed by an unrelated button like "Continue shopping".
  function findButtonByText(candidateTexts) {
    // TTD's Arjitha/Homam review screen can render the visible "Continue"
    // label inside a div/span while the click handler is attached to a
    // parent button-like container. Search normal controls first, then
    // resolve text-bearing descendants to their nearest clickable ancestor.
    const nodes = document.querySelectorAll(
      'button, a, input[type="submit"], input[type="button"], [role="button"], [role="link"], ' +
      '[tabindex]:not([tabindex="-1"])'
    );
    let partial = null;
    const candidates = [...nodes];

    for (const el of candidates) {
      if (!isClickEnabled(el)) continue;
      const t = (el.innerText || el.value || textOf(el)).trim().toLowerCase();
      if (!t || t.length > 80) continue;
      for (const candRaw of candidateTexts) {
        const cand = String(candRaw).trim().toLowerCase();
        if (t === cand) return el;
        if (!partial && t.includes(cand)) partial = el;
      }
    }

    // Second pass: find the actual visible text and climb to the nearest
    // interactive ancestor. This covers Material/Angular/React wrappers
    // where the button's own text is empty but a child span contains it.
    const wanted = candidateTexts.map(x => String(x).trim().toLowerCase());
    const textNodes = document.querySelectorAll('span, div, p, label, strong');
    let descendantMatch = null;
    for (const node of textNodes) {
      if (!isVisible(node)) continue;
      const t = (node.innerText || textOf(node)).trim().toLowerCase();
      if (!t || t.length > 60) continue;
      if (!wanted.some(c => t === c || t.includes(c))) continue;

      const clickable = node.closest(
        'button, a, [role="button"], [role="link"], [tabindex]:not([tabindex="-1"])'
      );
      if (clickable && isClickEnabled(clickable)) return clickable;

      // Some component libraries put the handler on a parent div without
      // a role/tabindex. Only accept a small, nearby container to avoid
      // accidentally clicking an unrelated page section.
      const parent = node.parentElement;
      if (parent && isVisible(parent) && isClickEnabled(parent)) {
        const pt = (parent.innerText || textOf(parent)).trim().toLowerCase();
        if (pt.length <= 100 && wanted.some(c => pt === c || pt.includes(c))) {
          descendantMatch = parent;
        }
      }
    }
    return partial || descendantMatch;
  }

  function waitForButton(candidateTexts, timeout, interval = 200) {
    return waitFor(() => findButtonByText(candidateTexts), timeout, interval);
  }

  // Some booking flows (Special Entry Darshan in particular) insert an
  // extra confirmation/review screen — its own "Continue" button, not
  // "Pay Now" — between the Pilgrim Details form and the actual
  // payment-method page. The rest of this file used to assume exactly one
  // Continue click always lands on Pay Now, which on that flow meant
  // waitForButton(PAY_TEXTS) polled for several seconds, found nothing
  // (only a Continue button was there), and gave up — looking from the
  // outside exactly like "stuck on Continue, nothing happens next". This
  // hops through however many such screens actually exist: at each step
  // it looks for Pay Now first, and if that's not there yet but a
  // Continue button is, clicks it and checks again — so a flow with zero
  // extra review screens (Pay Now shows up immediately) and one with one
  // or two both resolve the same way, without hard-coding the hop count.
  //
  // Some other flows (Arjitha Seva / the Homam, confirmed against a real
  // recording) never show a "Pay Now"-labeled button at all — the last
  // Continue click there lands directly on the payment-method chooser
  // (the UPI/PhonePe/Card options list), with no separate Pay-Now step in
  // between. Treating "no Pay Now button found" as failure in that case
  // was the actual bug: the flow had already arrived exactly where it
  // needed to be, there was just nothing left to click to get there.
  // Returns null (nothing usable found), or an object:
  //   { arrived: true }              — already on the payment-method
  //                                     chooser, nothing more to click
  //   { arrived: false, payBtn: el } — found an explicit Pay Now button
  //                                     the caller still needs to click
  //
  // Deliberately checks actual radio inputs only, NOT findPaymentOption's
  // broader tile-matching fallback (which matches by substring against
  // any small div/li/button-ish element). That fallback's generic "card"
  // candidate was confirmed (against a real recording) to false-match
  // "Photo ID Proof: Aadhaar Card" — plain text on the Pilgrim Details
  // form/review screen itself, nothing to do with payment at all. That
  // false match made this return "arrived" immediately, before Pilgrim
  // Details was even submitted, which from the outside looked exactly
  // like "not selecting Continue after filling pilgrim details": the
  // code believed it had already reached the payment chooser and had
  // nothing left to click. A genuine chooser page renders its options as
  // actual radio inputs (confirmed against the real page), so checking
  // those specifically avoids matching unrelated page text entirely.
  function isOnPaymentMethodPage() {
    const radios = [...document.querySelectorAll('input[type="radio"], [role="radio"]')].filter(isVisible);
    for (const radio of radios) {
      const sig = stripWs([labelForField(radio), paymentOptionSignature(radio)].join(" ").toLowerCase());
      if (PHONEPE_TEXTS.some((t) => sig.includes(stripWs(t)))) return true;
      // Drop the bare "card"/"cards" fallbacks here too, same reasoning —
      // require at least "debit card"/"credit card"/"atm card" or longer.
      if (CARD_TEXTS.filter((t) => t.length > 4).some((t) => sig.includes(stripWs(t)))) return true;
    }
    return /choose the payment method|how would you want to pay|pay via (qr|new card|upi)/i.test(document.body.innerText || "");
  }

  // Signature of "which screen is this": URL + visible headings/labels.
  function pageSig() {
    const heads = [...document.querySelectorAll("h1,h2,h3,h4,label")]
      .filter((e) => e.getClientRects().length > 0)
      .map((e) => (e.textContent || "").trim())
      .join("|");
    return location.href + "||" + heads.slice(0, 400);
  }

  // Click Continue; if the page doesn't move on, retry with a genuine tap.
  // The real tap is only used while the SAME button is still on screen and
  // enabled (so it can never land on a different button after navigation).
  async function clickContinueSmart(btn) {
    const before = pageSig();
    btn.scrollIntoView({ block: "center" });
    fireClickSequence(btn);
    const moved = () => pageSig() !== before || !btn.isConnected || !isVisible(btn);
    if (await waitFor(moved, 1300, 80)) return true;
    if (!__trusted.unavailable && btn.isConnected && isVisible(btn) && continueButtonReady(btn)) {
      await trustedTap(btn);
      await waitFor(moved, 1500, 80);
    }
    return true;
  }

  async function clickThroughToPayNow(maxHops = 4) {
    for (let hop = 0; hop < maxHops; hop++) {
      const outcome = await waitFor(() => {
        if (isOnPaymentMethodPage()) return { arrived: true };
        const btn = findButtonByText(PAY_TEXTS);
        return btn ? { arrived: false, payBtn: btn } : null;
      }, hop === 0 ? 6000 : 4000, 150);
      if (outcome) return outcome;

      const contBtn = await waitForButton(CONTINUE_TEXTS, 2500);
      if (!contBtn) return isOnPaymentMethodPage() ? { arrived: true } : null; // genuinely nothing left to try
      await clickContinueSmart(contBtn);
      await delay(250);
    }
    return isOnPaymentMethodPage() ? { arrived: true } : null;
  }


  // Payment-method pickers (PhonePe / GPay / Paytm / cards / netbanking...)
  // are usually a list of radio inputs or radio-like tiles, each labelled
  // with the app's name and often a logo image. Unlike findButtonByText
  // (which wants an element's *own* short text), the matching text here is
  // frequently on a sibling/child label, or only in an <img alt="PhonePe">,
  // so this looks at a wider net of signals per candidate.
  function paymentOptionSignature(el) {
    const parts = [textOf(el), el.getAttribute("aria-label"), el.getAttribute("alt"), el.getAttribute("title"), el.getAttribute("data-testid"), el.getAttribute("data-value")];
    const img = el.querySelector?.("img[alt]");
    if (img) parts.push(img.getAttribute("alt"));
    return parts.filter(Boolean).join(" ").toLowerCase();
  }

  // Strips ALL whitespace (not just collapsing runs of it) before matching
  // — a slot tile's actual text ("Slot Time 1:00 pm") and a hand-typed
  // preferred-slot value ("1:00PM") are the same time written two
  // different ways, differing only in whether there's a space before
  // "pm"/"am" and around the colon. A plain substring check treats those
  // as entirely different strings and finds nothing, no matter how
  // correct the typed value is — this was confirmed directly against a
  // real TTD slot tile's rendered text. Removing whitespace from both
  // sides entirely (rather than only lowercasing/trimming, which textOf()
  // already does) makes the comparison insensitive to exactly this kind
  // of formatting difference without weakening it in any other way — it
  // only ever makes a previously-failed match succeed, never the reverse.
  function stripWs(s) {
    return String(s || "").replace(/\s+/g, "");
  }

  function findPaymentOption(candidateTexts, maxSigLen = 180) {
    // Prefer an actual radio input tied to a matching label — clicking the
    // radio (or its label) is the most reliable way to select it and keeps
    // whatever native "checked" state/validation the page relies on.
    const radios = [...document.querySelectorAll('input[type="radio"], [role="radio"]')].filter(isVisible);
    for (const radio of radios) {
      const sig = stripWs([labelForField(radio), paymentOptionSignature(radio)].join(" ").toLowerCase());
      if (candidateTexts.some((t) => sig.includes(stripWs(t)))) return radio;
    }

    // Fall back to a clickable tile/card/list item — common on payment
    // pages that render custom (non-radio) selectable option buttons.
    // Prefer the MOST SPECIFIC match (shortest signature) rather than the
    // first one found in document order: a wrapping list container (e.g.
    // the whole "How would you want to pay?" section) can itself match a
    // generic candidate like "card" simply because it contains the real
    // row's text as a descendant, and clicking that outer wrapper doesn't
    // trigger the actual row's click handler — it just silently does
    // nothing, which is what "not selecting Card" looks like from outside.
    // maxSigLen defaults to a tight 60 chars for payment-method tiles
    // ("PhonePe", "Credit/Debit/ATM Card" — always short) but a caller can
    // raise it: a Darshan slot tile routinely also shows seat count and
    // price alongside the time, which can easily run past 60 characters
    // on its own even for the exact right tile.
    const tiles = [...document.querySelectorAll('li, div, button, a, [role="button"], [role="option"]')].filter(
      (el) => isVisible(el) && el.children.length <= 8
    );
    let best = null;
    let bestSigLength = Infinity;
    for (const el of tiles) {
      const rawSig = paymentOptionSignature(el);
      if (!rawSig || rawSig.length > maxSigLen) continue;
      const sig = stripWs(rawSig);
      if (candidateTexts.some((t) => sig.includes(stripWs(t))) && rawSig.length < bestSigLength) {
        best = el;
        bestSigLength = rawSig.length;
      }
    }
    return best;
  }

  // Clicks the radio itself when found (plus its <label>, since some sites
  // only bind the "select" handler to the label, not the input), otherwise
  // clicks the matched tile. Returns true only if something was actually
  // found and clicked — never invents a selection.
  function selectPaymentOption(candidateTexts, maxSigLen = 180) {
    const target = findPaymentOption(candidateTexts, maxSigLen);
    if (!target) return false;

    if (target.matches?.('input[type="radio"], [role="radio"]')) {
      if (target.labels && target.labels.length) {
        fireClickSequence(target.labels[0]);
      }
      target.checked = true;
      target.dispatchEvent(new Event("input", { bubbles: true }));
      target.dispatchEvent(new Event("change", { bubbles: true }));
    }
    target.scrollIntoView({ block: "center" });
    fireClickSequence(target);
    return true;
  }

  // Best-effort short beep (WebAudio) + a brief vibration (mobile), fired
  // once right as a countdown overlay appears — useful if the person
  // isn't looking at the screen when the CVV countdown starts. Never
  // throws: a blocked/unsupported AudioContext or a missing
  // navigator.vibrate on desktop should never break the actual countdown.
  function playAlertCue() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (Ctx) {
        const ctx = new Ctx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.0001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
        osc.onended = () => ctx.close?.();
      }
    } catch (_) {
      // Autoplay policies can block this until the page has had a user
      // gesture — silently skip rather than surface an error.
    }
    try {
      navigator.vibrate?.([200, 100, 200]);
    } catch (_) {
      // Not supported on this device — nothing to do.
    }
  }

  // Small floating overlay: counts down from `seconds`, resolves true if it
  // runs out, resolves false immediately if the person clicks Cancel.
  // opts.alertSound plays a short beep + vibration once, right as the
  // overlay appears — used for the payment-Proceed countdown specifically,
  // so it's noticeable even if you're not looking at the screen when the
  // CVV window opens.
  function showCountdownOverlay(seconds, label, opts = {}) {
    return new Promise((resolve) => {
      if (opts.alertSound) playAlertCue();
      const overlay = document.createElement("div");
      overlay.id = "__pilgrimPayCountdown";
      overlay.style.cssText =
        "position:fixed;z-index:2147483647;right:16px;bottom:16px;" +
        "background:#1f2430;color:#fff;padding:14px 16px;border-radius:10px;" +
        "font:14px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;" +
        "box-shadow:0 6px 20px rgba(0,0,0,.35);max-width:280px;";

      const text = document.createElement("div");
      text.style.marginBottom = "10px";
      overlay.appendChild(text);

      const btn = document.createElement("button");
      btn.type = "button";
      btn.textContent = "Cancel";
      btn.style.cssText =
        "background:#e0455a;color:#fff;border:0;border-radius:6px;" +
        "padding:6px 12px;cursor:pointer;font-weight:600;font-size:13px;";
      overlay.appendChild(btn);

      document.body.appendChild(overlay);

      let remaining = seconds;
      const render = () => (text.textContent = `${label} in ${remaining}s… (tap Cancel to stop)`);
      render();

      const timer = setInterval(() => {
        remaining -= 1;
        if (remaining <= 0) {
          clearInterval(timer);
          overlay.remove();
          resolve(true);
          return;
        }
        render();
      }, 1000);

      btn.addEventListener("click", () => {
        clearInterval(timer);
        overlay.remove();
        resolve(false);
      });
    });
  }

  // ---------------------------------------------------------------------
  // Card sub-form (Name on Card / Card Number / Expiry) — shown after a
  // Debit/Credit Card payment option is selected. CVV is deliberately kept
  // out of this entirely: it's never collected from the person in the
  // popup, never stored, and this function refuses to match a field whose
  // label/name looks like a CVV/security-code field even by accident. The
  // person still has to type the CVV in themselves — the 10s countdown in
  // __pilgrimCardProceed below is their window to do that (or cancel)
  // before the actual Proceed/Pay click happens.
  // ---------------------------------------------------------------------
  const CARD_FIELD_KEYWORDS = {
    name: ["name on card", "cardholder name", "card holder name", "name as on card", "name on the card"],
    number: ["card number", "card no", "debit card number", "credit card number", "16 digit card", "cardnumber"],
    expiry: ["expiry", "expiration", "exp date", "exp.", "valid thru", "valid till", "mm/yy", "mm / yy", "expirydate"]
  };
  const CVV_BLOCK_PATTERN = /cvv|cvc|security code|card verification/;

  // Some card-number/expiry fields are controlled inputs backed by an
  // input-mask library that formats as you type (spacing digits, inserting
  // the "/" in MM/YY) and tracks its own state off real keyboard events —
  // setting .value once and firing a single "input" event (fine for plain
  // fields like Name on Card) can get silently ignored or immediately
  // overwritten back to empty by that library. Typing character-by-character
  // with a small yield in between gives the framework's own state a chance
  // to catch up, the same way a real keystroke would.
  function setNativeValue(field, value) {
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    if (nativeSetter) nativeSetter.call(field, value);
    else field.value = value;
  }

  async function typeIntoField(field, value) {
    const str = String(value);
    // A masked input is sometimes a display-only element until a genuine
    // pointer interaction "activates" it (some custom card-number/expiry
    // widgets render a non-editable-looking box that only wires up real
    // typing after an actual click) — mirror the same pointer/mouse
    // sequence fireClickSequence uses elsewhere before focusing, in case
    // .focus() alone isn't enough to arm the field's own input handling.
    try {
      const rect = field.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
        const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
        field.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, clientX: x, clientY: y }));
      }
    } catch (_) {
      // Constructor unsupported in this engine — .focus() below still runs.
    }
    field.focus();
    setNativeValue(field, "");
    field.dispatchEvent(new Event("input", { bubbles: true }));
    await delay(30);

    for (const ch of str) {
      field.dispatchEvent(new KeyboardEvent("keydown", { key: ch, bubbles: true }));
      // Some masked-input libraries (card-number spacing, expiry's "/")
      // only react correctly to document.execCommand's own synthesized
      // input event, not one dispatched manually — try it first since
      // it's the closer approximation to a real keystroke, and fall back
      // to setting the value directly if execCommand isn't available or
      // does nothing (execCommand is deprecated but still broadly
      // supported, and there's no equivalent replacement yet for
      // reliably driving a masked field this way from outside the page).
      let usedExecCommand = false;
      try {
        usedExecCommand = document.execCommand && document.execCommand("insertText", false, ch);
      } catch (_) {
        usedExecCommand = false;
      }
      if (!usedExecCommand) {
        setNativeValue(field, field.value + ch);
        field.dispatchEvent(new InputEvent("input", { bubbles: true, data: ch, inputType: "insertText" }));
      }
      field.dispatchEvent(new KeyboardEvent("keyup", { key: ch, bubbles: true }));
      await delay(25);
    }
    field.dispatchEvent(new Event("change", { bubbles: true }));
    field.dispatchEvent(new Event("blur", { bubbles: true }));
    // Success is judged by "did something end up in the field" rather than
    // an exact match, since a mask library may reformat digits with spaces
    // or insert the "/" in an expiry date itself.
    return field.value.trim().length > 0;
  }

  // =====================================================================
  // v2.12 — GENERIC PAGE DRIVER + DESKTOP/MOBILE CARD FORM
  //
  // 1) __pilgrimDrive: instead of assuming a fixed number of Continue
  //    clicks, it looks at whatever page is showing and clicks the one
  //    button that moves the flow forward — Continue (any number of
  //    times), Pay Now, or Book Now — until the destination is reached:
  //      pay mode  -> the payment-method page (UPI / Card / Netbanking)
  //      book mode -> Book Now clicked (after a cancel-able 2s countdown)
  //    If Continue is disabled it tries to fix the page first (ticks
  //    pilgrim-card / consent checkboxes, re-fills empty known fields).
  //
  // 2) Card form: fields are located by autocomplete/placeholder/label
  //    text — INCLUDING labels that sit after the input (floating
  //    labels) — with a layout-order fallback. CVV is never touched.
  // =====================================================================

  const NEXT_EXACT = ["continue", "proceed", "next", "save & continue", "save and continue", "continue booking", "continue to payment"];
  const PAY_EXACT = ["pay now", "proceed to pay", "proceed to payment", "make payment", "pay"];
  const BOOK_EXACT = ["book now", "confirm booking", "book slot", "confirm & book", "confirm and book", "book"];
  const FINAL_PAY_EXACT = ["pay now", "pay", "proceed", "proceed to pay", "make payment", "submit", "pay securely"];
  const CONSENT_RE = /\b(agree|accept|terms|conditions|declaration|declare|undertak|consent|i have read|i confirm|acknowledge)/i;

  // Letters/&/space only, lowercased — "Pay ₹400.00" -> "pay", "CONTINUE »" -> "continue".
  function btnText(el) {
    return String(el.innerText || el.value || el.textContent || "")
      .toLowerCase().replace(/[^a-z& ]+/g, " ").replace(/\s+/g, " ").trim();
  }

  function isTabLike(el) {
    return el.getAttribute("role") === "tab" || !!el.closest('[role="tab"], [role="tablist"], nav');
  }

  function actionClickable(node) {
    let n = node;
    for (let i = 0; i < 5 && n && n !== document.body; i++, n = n.parentElement) {
      if (n.matches('button, a, input[type="submit"], input[type="button"], [role="button"], [tabindex]:not([tabindex="-1"])')) return n;
      try { if (getComputedStyle(n).cursor === "pointer") return n; } catch (_) {}
    }
    return null;
  }

  // EXACT-text match only (so "Pay via QR" can never be mistaken for "Pay").
  // Returns { el, enabled } or null.
  function findActionButton(texts) {
    const wanted = new Set(texts);
    const hits = [];
    const direct = document.querySelectorAll('button, a, input[type="submit"], input[type="button"], [role="button"], [tabindex]:not([tabindex="-1"])');
    for (const el of direct) {
      if (!isVisible(el) || isTabLike(el)) continue;
      if (wanted.has(btnText(el))) hits.push(el);
    }
    if (!hits.length) {
      for (const node of document.querySelectorAll("span, div, p, strong, b, label")) {
        if (node.children.length > 1 || !isVisible(node)) continue;
        const t = btnText(node);
        if (!t || t.length > 30 || !wanted.has(t)) continue;
        const target = actionClickable(node);
        if (target && isVisible(target) && !isTabLike(target) && !hits.includes(target)) hits.push(target);
      }
    }
    if (!hits.length) return null;
    const ready = (el) => isClickEnabled(el) && continueButtonReady(el);
    const el = hits.find(ready) || hits[0];
    return { el, enabled: ready(el) };
  }

  // Changes whenever the visible screen changes (URL, controls, or text).
  function driveSig() {
    const btns = [...document.querySelectorAll("button, [role=button], a, input[type=submit]")].filter(isVisible).map(btnText).join("|");
    const inputs = [...document.querySelectorAll("input, select, textarea")].filter(isVisible).length;
    return location.href + "#" + inputs + "#" + btns + "#" + (document.body.innerText || "").replace(/\s+/g, " ").slice(0, 400);
  }

  async function tickConsentBoxes() {
    let n = 0;
    const pilgrimBoxes = new Set(findPilgrimCardCheckboxes());
    for (const cb of document.querySelectorAll('input[type="checkbox"], [role="checkbox"]')) {
      if (!isVisible(cb) || pilgrimBoxes.has(cb) || checkboxIsChecked(cb)) continue;
      if (cb.disabled || cb.getAttribute("aria-disabled") === "true") continue;
      let ctx = labelForField(cb);
      if (!ctx) ctx = textOf(cb.closest("label, div, li")).slice(0, 300);
      if (!CONSENT_RE.test(ctx)) continue;
      cb.scrollIntoView({ block: "center" });
      fireClickSequence(cb);
      await delay(120);
      if (checkboxIsChecked(cb)) n++;
    }
    return n;
  }

  function hasEmptyKnownFields() {
    const { plain, dropdownTriggers } = collectFields();
    const fields = [...plain, ...dropdownTriggers.filter((d) => d.tagName === "INPUT")];
    return classifyList(fields).some((m) => !String(m.field.value || "").trim() && !classifyCardField(m.field));
  }

  async function prepareForContinue(ctx, payload) {
    if (findPilgrimCardCheckboxes().length) await ensurePilgrimCardsSelected(0);
    const ticked = await tickConsentBoxes();
    if (ticked) ctx.notes.push(`ticked ${ticked} consent box(es)`);
    const sig = driveSig();
    if (payload && !ctx.filledSigs.has(sig) && hasEmptyKnownFields() && typeof window.__pilgrimAutofillRun === "function") {
      ctx.filledSigs.add(sig);
      const r = await window.__pilgrimAutofillRun({ ...payload, dateSlot: null, dryRun: false });
      ctx.notes.push(`filled ${r?.filledCount || 0} field(s) on a later step`);
      await delay(300);
    }
  }

  // allowTrusted=false: a second, real click is only ever added for
  // navigation-style buttons (Continue). Pay / Book must never get a second
  // click, because a slow page can look "unmoved" and the repeat submits twice.
  async function clickSmart(btn, sigBefore, allowTrusted = true) {
    btn.scrollIntoView({ block: "center" });
    fireClickSequence(btn);
    const moved = () => driveSig() !== sigBefore || !btn.isConnected || !isVisible(btn);
    if (await waitFor(moved, 1500, 80)) return true;
    if (allowTrusted && !__trusted.unavailable && btn.isConnected && isVisible(btn) && isClickEnabled(btn)) {
      await trustedTap(btn);
      return !!(await waitFor(moved, 1800, 80));
    }
    return false;
  }

  function onPaymentGateway() {
    try { return isOnPaymentMethodPage() || hasCardNumberField(); } catch (_) { return false; }
  }

  // opts: { mode: "pay"|"book", finalPay: "click"|"stop", payload, maxMs }
  window.__pilgrimDrive = async function (opts) {
    opts = opts || {};
    const mode = opts.mode === "book" ? "book" : opts.mode === "auto" ? "auto" : "pay";
    const finalTexts = (kind) => (kind === "book" ? BOOK_EXACT : PAY_EXACT);
    const finalPay = opts.finalPay === "stop" ? "stop" : "click";
    const maxMs = opts.maxMs || 70000;
    const cancelSecs = opts.cancelSecs || 2; // cancel-able pause before Book Now / Pay Now (Quick Book uses 1s)
    const start = Date.now();
    const token = (window.__pilgrimDriveToken = (window.__pilgrimDriveToken || 0) + 1);
    __trusted.unavailable = false; __trusted.ready = false;
    const ctx = { filledSigs: new Set(), notes: [], clicks: 0, sigClicks: new Map(), waitSig: "", waitSince: 0, preppedSig: null };
    const out = (o) => ({ clicks: ctx.clicks, notes: ctx.notes, ...o });
    try {
      while (Date.now() - start < maxMs) {
        if (window.__pilgrimDriveToken !== token) return out({ ok: false, superseded: true, reason: "superseded by a newer run" });
        if (mode !== "book" && onPaymentGateway()) return out({ ok: true, arrived: true });

        const sig = driveSig();
        // "auto": the page decides — Pay Now (payment flows) or Book Now
        // (Angapradakshinam-style flows). Works from any service tab.
        let finalKind = mode === "book" ? "book" : "pay";
        let final = findActionButton(finalTexts(finalKind));
        if (!final && mode === "auto") {
          final = findActionButton(BOOK_EXACT);
          if (final) finalKind = "book";
        }
        const next = findActionButton(NEXT_EXACT);
        const cand = final || next;
        if (!cand) { await delay(120); continue; }
        const isFinal = !!final;

        if (!cand.enabled || ctx.preppedSig !== sig) {
          ctx.preppedSig = sig;
          await prepareForContinue(ctx, opts.payload);
          const again = findActionButton(isFinal ? finalTexts(finalKind) : NEXT_EXACT);
          if (!again || !again.enabled) {
            if (ctx.waitSig !== sig) { ctx.waitSig = sig; ctx.waitSince = Date.now(); }
            if (Date.now() - ctx.waitSince > 9000) {
              return out({ ok: false, terminal: true, reason: `${isFinal ? (finalKind === "book" ? "Book Now" : "Pay Now") : "Continue"} stays disabled — a required field or checkbox on this page is still empty` });
            }
            ctx.preppedSig = null;
            await delay(200);
            continue;
          }
          cand.el = again.el;
        }

        if (isFinal && finalKind === "book") {
          const go = await showCountdownOverlay(cancelSecs, "Booking now");
          if (!go) return out({ ok: false, terminal: true, reason: "Booking cancelled" });
          const fresh = findActionButton(BOOK_EXACT);
          const btn = (fresh && fresh.el) || cand.el;
          btn.scrollIntoView({ block: "center" });
          fireClickSequence(btn);
          await delay(1200);
          return out({ ok: true, booked: true, confirmationRef: scrapeConfirmationRef() });
        }
        if (isFinal && finalPay === "stop") return out({ ok: true, stage: "pay_now" });

        if (isFinal) {
          // Pay Now is one-shot. Tap it once, then wait for the page to move
          // (gateway redirect or confirmation). If it never moves, stop with a
          // message instead of tapping again — a repeat tap can pay twice, and
          // the background retry loop would otherwise re-run this step.
          // Visible, cancel-able 3s window first (same pattern as Book Now and
          // the card Pay step), then re-find the button in case it re-rendered.
          const go = await showCountdownOverlay(cancelSecs, "Tapping Pay Now");
          if (!go) return out({ ok: false, terminal: true, reason: "Payment cancelled" });
          const freshPay = findActionButton(PAY_EXACT);
          if (freshPay && freshPay.el) cand.el = freshPay.el;
          await clickSmart(cand.el, sig, false);
          ctx.clicks++;
          const moved = await waitFor(() => driveSig() !== sig || !cand.el.isConnected, 15000, 300);
          if (!moved) {
            return out({ ok: false, terminal: true, reason: "Tapped Pay Now but the page didn't respond — check the tab before tapping again" });
          }
          await delay(150);
          continue;
        }
        const n = (ctx.sigClicks.get(sig) || 0) + 1;
        ctx.sigClicks.set(sig, n);
        if (n > 3) {
          return out({ ok: false, terminal: true, reason: "Clicked the button 3 times but the page didn't move — a required field is probably missing or invalid" });
        }
        const moved = await clickSmart(cand.el, sig);
        ctx.clicks++;
        await delay(moved ? 120 : 350);
      }
      return out({ ok: false, reason: "Timed out waiting for the next step" });
    } catch (err) {
      return out({ ok: false, reason: (err && err.message) || String(err) });
    }
  };

  // ---------------- card form ----------------

  function deepAll(selector, root = document, out = []) {
    root.querySelectorAll(selector).forEach((e) => out.push(e));
    root.querySelectorAll("*").forEach((e) => { if (e.shadowRoot) deepAll(selector, e.shadowRoot, out); });
    return out;
  }

  function usableInput(el) {
    if (!isVisible(el) || el.disabled) return false;
    return !["hidden", "submit", "button", "checkbox", "radio", "file", "image"].includes(el.type);
  }

  // Text of the widest short wrapper that contains ONLY this input — picks
  // up floating labels placed before OR after the input.
  function ownWrapperText(field) {
    let node = field, best = "";
    for (let i = 0; i < 4 && node.parentElement; i++) {
      const p = node.parentElement;
      if (p.querySelectorAll('input:not([type="hidden"]), textarea, select').length > 1) break;
      node = p;
      const t = String(p.innerText || p.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
      if (t && t.length <= 40) best = t;
    }
    return best;
  }

  function classifyCardHint(h) {
    const n = String(h || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!n) return null;
    if (/aadhaar|aadhar|passport|photoid|idproof|idnumber|voter|licen[sc]e/.test(n)) return null;
    if (/cvv|cvc|csc|securitycode|cardverification|cvn/.test(n)) return "cvv";
    if (/ccexpmonth|expmonth|expirymonth/.test(n) || n === "mm") return "expMonth";
    if (/ccexpyear|expyear|expiryyear/.test(n) || n === "yy" || n === "yyyy") return "expYear";
    if (/expir|expdate|ccexp|mmyy|validthru|validtill|validuntil/.test(n)) return "expiry";
    if (/nameoncard|cardholder|holdername|cardname|ccname|nameasoncard|nameonthecard/.test(n)) return "name";
    if (/cardnumber|cardno|ccnumber|ccnum|numberoncard/.test(n)) return "number";
    return null;
  }

  function classifyCardField(field) {
    const own = [
      field.getAttribute("autocomplete"), field.id, field.getAttribute("name"), field.getAttribute("placeholder"),
      field.getAttribute("aria-label"), field.getAttribute("data-testid"), field.getAttribute("data-name"),
      field.getAttribute("title"),
      field.labels && field.labels.length ? [...field.labels].map(textOf).join(" ") : "",
      ownWrapperText(field)
    ].filter(Boolean).join(" ");
    return classifyCardHint(own) || classifyCardHint(labelForField(field));
  }

  function byPosition(a, b) {
    const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
    const row = Math.round(ra.top / 12) - Math.round(rb.top / 12);
    return row || ra.left - rb.left;
  }

  function locateCardFields() {
    const scan = (list) => {
      const found = {};
      for (const f of list) {
        const k = classifyCardField(f);
        if (k && !found[k]) found[k] = f;
      }
      return found;
    };
    let inputs = [...document.querySelectorAll("input, textarea")].filter(usableInput);
    let found = scan(inputs);
    if (!found.number && !found.expiry && !found.name) {
      const deep = deepAll("input, textarea").filter(usableInput);
      if (deep.length > inputs.length) { inputs = deep; found = scan(inputs); }
    }
    // Layout fallback: a form whose visible text has Card number / Expiry /
    // CVV, laid out number, expiry, cvv, name (reading order).
    if (!found.number && !found.expiry && inputs.length >= 3) {
      for (const f of inputs) {
        let box = f.parentElement, matched = false;
        for (let i = 0; i < 8 && box; i++, box = box.parentElement) {
          const t = String(box.innerText || "").toLowerCase();
          if (t.includes("card number") && t.includes("expiry") && t.includes("cvv")) { matched = true; break; }
        }
        // Without this flag the loop's last ancestor was used even when no
        // ancestor mentioned card number / expiry / CVV, so ANY page with 3+
        // inputs (the pilgrim form!) looked like a card form.
        if (!matched || !box) continue;
        const group = inputs.filter((x) => box.contains(x)).sort(byPosition);
        if (group.length >= 3) {
          found = { number: group[0], expiry: group[1], cvv: group[2], ...(group[3] ? { name: group[3] } : {}), positional: true };
          break;
        }
      }
    }
    return found;
  }

  function hasCardNumberField() {
    try { return !!locateCardFields().number; } catch (_) { return false; }
  }

  function collectCardCandidateFields() {
    return [...document.querySelectorAll("input, textarea")].filter(usableInput);
  }

  const digitsOf = (s) => String(s || "").replace(/\D/g, "");

  function splitExpiry(raw) {
    const d = digitsOf(raw);
    if (d.length < 4) return null;
    const yy = d.length >= 6 ? d.slice(2, 6) : d.slice(2, 4);
    return { mm: d.slice(0, 2), yy2: yy.slice(-2), yy4: yy.length === 4 ? yy : "20" + yy };
  }

  function cardValueOk(field, kind, want) {
    const v = String(field.value || "");
    if (kind === "name") return v.trim().toLowerCase() === String(want).trim().toLowerCase();
    if (kind === "number") return digitsOf(v) === digitsOf(want);
    if (kind === "expiry") { const d = digitsOf(v); return d.startsWith(want.mm) && d.endsWith(want.yy2); }
    if (kind === "expMonth") return digitsOf(v) === want.mm;
    if (kind === "expYear") { const d = digitsOf(v); return d === want.yy2 || d === want.yy4; }
    return false;
  }

  // Last resort: focus the field here, then have the background send REAL
  // key events (browser debugger). Works for masked inputs and iframes that
  // ignore scripted value changes.
  async function trustedTypeInto(field, text) {
    const wasReadonly = field.hasAttribute("readonly");
    try {
      if (wasReadonly) field.removeAttribute("readonly");
      field.scrollIntoView({ block: "center" });
      fireClickSequence(field);
      field.focus();
      setNativeValue(field, "");
      field.dispatchEvent(new Event("input", { bubbles: true }));
      field.focus();
      await delay(80);
      // Real keystrokes go to whichever element has focus. If focusing this
      // field failed, abort instead of typing card digits somewhere else.
      const root = field.getRootNode && field.getRootNode();
      const active = (root && root.activeElement) || document.activeElement;
      if (active !== field) return false;
      const r = await chrome.runtime.sendMessage({ action: "pilgrimTrustedType", text });
      await delay(150);
      return !!(r && r.ok);
    } catch (_) {
      return false;
    } finally {
      if (wasReadonly) field.setAttribute("readonly", "");
    }
  }

  async function setCardValue(field, kind, want, attempts) {
    if (cardValueOk(field, kind, want)) return true;
    // Real keystrokes first: masked / iframe inputs ignore scripted values,
    // and a scripted value can look right while the form's own state is empty.
    for (const text of attempts.slice(0, 2)) {
      if (await trustedTypeInto(field, text)) {
        await delay(160);
        if (cardValueOk(field, kind, want)) return true;
      }
    }
    const wasReadonly = field.hasAttribute("readonly");
    if (wasReadonly) field.removeAttribute("readonly");
    for (const text of attempts) {
      typeLikeUser(field, text);
      await delay(140);
      if (cardValueOk(field, kind, want)) return true;
    }
    for (const text of attempts) {
      if (await typeIntoField(field, text)) { await delay(120); if (cardValueOk(field, kind, want)) return true; }
    }
    if (wasReadonly) field.setAttribute("readonly", "");
    return false;
  }

  async function fillCardFields(card) {
    if (!card) return { filledCount: 0 };
    const loc = locateCardFields();
    const filled = [];
    const exp = splitExpiry(card.expiry);
    const jobs = [];
    if (loc.number && card.number) jobs.push([loc.number, "number", card.number, [digitsOf(card.number), String(card.number)]]);
    if (loc.expiry && exp) jobs.push([loc.expiry, "expiry", exp, [`${exp.mm}/${exp.yy2}`, `${exp.mm}${exp.yy2}`, `${exp.mm}/${exp.yy4}`]]);
    if (loc.expMonth && exp) jobs.push([loc.expMonth, "expMonth", exp, [exp.mm]]);
    if (loc.expYear && exp) jobs.push([loc.expYear, "expYear", exp, [exp.yy2, exp.yy4]]);
    if (loc.name && card.name) jobs.push([loc.name, "name", card.name, [String(card.name)]]);
    // NOTE: loc.cvv is deliberately never used — the person types it.
    const failed = [];
    for (const [field, kind, want, attempts] of jobs) {
      try {
        if (await setCardValue(field, kind, want, attempts)) filled.push(kind);
        else failed.push(kind);
      } catch (_) { failed.push(kind); }
    }
    // Wanted-but-not-found fields count as failures too (only the frame that
    // actually has the form reports them).
    if (jobs.length || loc.name || loc.number || loc.expiry) {
      if (card.number && !loc.number && (loc.name || loc.expiry)) failed.push("number (field not found)");
      if (card.expiry && !loc.expiry && !loc.expMonth && (loc.name || loc.number)) failed.push("expiry (field not found)");
    }
    return { filledCount: filled.length, expected: jobs.length, filled, failed, located: Object.keys(loc).filter((k) => loc[k] && k !== "positional"), positional: !!loc.positional };
  }

  // Run in the page's own DevTools console on the payment screen.
  window.__pilgrimCardDebug = function () {
    console.group("Govinda — card field scan");
    const loc = locateCardFields();
    console.log("located:", Object.fromEntries(Object.entries(loc).map(([k, v]) => [k, v && v.tagName ? (v.id || v.name || v.placeholder || v.tagName) : v])));
    for (const f of collectCardCandidateFields()) {
      console.log({ type: f.type, readOnly: f.readOnly, autocomplete: f.getAttribute("autocomplete"), id: f.id, name: f.name, placeholder: f.placeholder, wrapper: ownWrapperText(f), kind: classifyCardField(f) });
    }
    console.log("card tab:", findCardTab());
    console.groupEnd();
  };

  window.__pilgrimFillCardFields = async function (card) {
    try {
      return await fillCardFields(card);
    } catch (err) {
      return { filledCount: 0, error: (err && err.message) || String(err) };
    }
  };

  // ---- card tab / row ("Credit/Debit/ATM Card") ----
  function findCardTab() {
    const hits = [];
    for (const el of document.querySelectorAll('[role="tab"], [role="radio"], button, a, li, label, div, span, p')) {
      if (!isVisible(el) || el.children.length > 4) continue;
      const t = btnText(el);
      if (!t || t.length > 40 || !/card/.test(t)) continue;
      if (!/^(?:(?:credit|debit|atm|cards?|and|&)\s*)+$/.test(t)) continue;
      hits.push(el);
    }
    if (!hits.length) return null;
    const inner = hits.find((h) => !hits.some((o) => o !== h && h.contains(o))) || hits[0];
    return actionClickable(inner) || inner;
  }

  window.__pilgrimSelectCardOption = async function () {
    try {
      if (hasCardNumberField()) return { ok: true, already: true };
      const tab = await waitFor(() => findCardTab() || (isOnPaymentMethodPage() ? findPaymentOption(CARD_TEXTS) : null), 3500, 150);
      if (!tab) return { ok: false, reason: "No Card/Debit Card option found on this page" };
      for (let attempt = 0; attempt < 2; attempt++) {
        tab.scrollIntoView({ block: "center" });
        fireClickSequence(tab);
        if (await waitFor(() => hasCardNumberField() || null, 1800, 100)) return { ok: true };
        if (window === window.top && !__trusted.unavailable) {
          await trustedTap(tab);
          if (await waitFor(() => hasCardNumberField() || null, 1800, 100)) return { ok: true };
        }
      }
      // The fields may live in a gateway iframe (checked in its own frame).
      return { ok: true, clicked: true };
    } catch (err) {
      return { ok: false, reason: (err && err.message) || String(err) };
    }
  };

  // Lets the popup tell that this frame is a payment / card screen, so Fill
  // doesn't push the pilgrim's name into "Name on Card".
  window.__pilgrimPaymentPageState = function () {
    try { return { gateway: isOnPaymentMethodPage(), card: hasCardNumberField() }; } catch { return { gateway: false, card: false }; }
  };

  window.__pilgrimHasCardNumberField = function () {
    try { return hasCardNumberField(); } catch { return false; }
  };

  // ---- final Pay on the card screen ----
  // CVV window: shows a visible countdown (default 10s, with Cancel), focuses the
  // CVV box so you can type straight away, and pays the moment the CVV looks
  // complete (3 digits, 4 for Amex) after a 1s grace to fix a typo. The CVV
  // value is only ever READ for its length - never written, stored or sent.
  // If the CVV is not entered in time it stops (it never taps Pay on an empty
  // CVV) and leaves the page to you. Exact-text match on the Pay button, so
  // "Pay via QR" can never be clicked by mistake.
  const CVV_GRACE_MS = 1000;

  function cvvNeededDigits() {
    try {
      const num = digitsOf((locateCardFields().number || {}).value);
      return /^3[47]/.test(num) ? 4 : 3;
    } catch (_) { return 3; }
  }

  // Resolves "filled" | "timeout" | "cancel".
  function showCvvOverlay(seconds) {
    return new Promise((resolve) => {
      playAlertCue();
      let cvvField = null;
      try { cvvField = locateCardFields().cvv || null; } catch (_) {}
      if (cvvField) { try { cvvField.scrollIntoView({ block: "center" }); cvvField.focus(); } catch (_) {} }

      const overlay = document.createElement("div");
      overlay.id = "__pilgrimPayCountdown";
      overlay.style.cssText =
        "position:fixed;z-index:2147483647;right:16px;bottom:16px;" +
        "background:#1f2430;color:#fff;padding:14px 16px;border-radius:10px;" +
        "font:14px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;" +
        "box-shadow:0 6px 20px rgba(0,0,0,.35);max-width:300px;";
      const text = document.createElement("div");
      text.style.marginBottom = "10px";
      overlay.appendChild(text);
      const btn = document.createElement("button");
      btn.type = "button";
      btn.textContent = "Cancel";
      btn.style.cssText = "background:#e0455a;color:#fff;border:0;border-radius:6px;padding:6px 12px;cursor:pointer;font-weight:600;font-size:13px;";
      overlay.appendChild(btn);
      document.body.appendChild(overlay);

      const t0 = Date.now();
      const need = cvvNeededDigits();
      let completeSince = 0;
      let done = false;
      const finish = (v) => { if (done) return; done = true; clearInterval(timer); overlay.remove(); resolve(v); };
      const tick = () => {
        const left = Math.max(0, Math.ceil(seconds - (Date.now() - t0) / 1000));
        const len = cvvField ? digitsOf(cvvField.value).length : 0;
        if (cvvField && len >= need) {
          if (!completeSince) completeSince = Date.now();
          text.textContent = "CVV entered — paying…";
          if (Date.now() - completeSince >= CVV_GRACE_MS) return finish("filled");
        } else {
          completeSince = 0;
          text.textContent = `Type your CVV now — ${left}s left. It pays as soon as the CVV is complete.`;
        }
        if (Date.now() - t0 >= seconds * 1000) finish("timeout");
      };
      const timer = setInterval(tick, 150);
      tick();
      btn.addEventListener("click", () => finish("cancel"));
    });
  }

  window.__pilgrimCardProceed = async function (opts) {
    try {
      const cvvSeconds = (opts && opts.cvvSeconds) || 10;
      const found = await waitFor(() => findActionButton(FINAL_PAY_EXACT) || null, 5000, 150);
      if (!found) return { ok: false, reason: "Card fields filled, but no Pay Now button was found — enter the CVV and tap it yourself" };

      const outcome = await showCvvOverlay(cvvSeconds);
      if (outcome === "cancel") return { ok: false, terminal: true, reason: "Proceed cancelled" };

      // On timeout, only pay if we cannot see the CVV box at all (it lives in a
      // different frame). If we can see it and it is incomplete, stop instead of
      // tapping Pay on an empty CVV.
      let cvvField = null;
      try { cvvField = locateCardFields().cvv || null; } catch (_) {}
      if (outcome === "timeout" && cvvField && digitsOf(cvvField.value).length < cvvNeededDigits()) {
        return { ok: false, terminal: true, reason: `CVV not entered within ${cvvSeconds}s — enter it and tap Pay Now yourself` };
      }

      let btn = findActionButton(FINAL_PAY_EXACT);
      if (!btn || !btn.enabled) {
        btn = await waitFor(() => { const b = findActionButton(FINAL_PAY_EXACT); return b && b.enabled ? b : null; }, 3000, 150);
        if (!btn) return { ok: false, terminal: true, reason: "Pay Now stayed disabled (CVV missing or invalid?) — fix it and tap Pay Now yourself" };
      }
      btn.el.scrollIntoView({ block: "center" });
      fireClickSequence(btn.el);
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: (err && err.message) || String(err) };
    }
  };

  // ---------------- step hooks used by background.js / scheduler ----------------
  window.__pilgrimClickContinue = async function () {
    try {
      const boxes = findPilgrimCardCheckboxes();
      if (boxes.length) await ensurePilgrimCardsSelected(0);
      const continueBtn = await waitForEnabledContinue(5000);
      if (!continueBtn) return { ok: false, reason: "Continue button is still disabled or not found — pilgrim selection may be incomplete" };
      continueBtn.scrollIntoView({ block: "center" });
      fireClickSequence(continueBtn);
      await delay(250);
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: (err && err.message) || String(err) };
    }
  };

  window.__pilgrimClickReviewPay = async function (opts) {
    return await window.__pilgrimDrive({ mode: "auto", finalPay: "click", payload: opts && opts.payload, maxMs: (opts && opts.maxMs) || 55000 });
  };

  // Same walk, but stops AT Pay Now (scheduler's "leave the tap to me" path).
  window.__pilgrimFindReviewPayButton = async function () {
    const r = await window.__pilgrimDrive({ mode: "pay", finalPay: "stop", maxMs: 30000 });
    return r.ok ? { ok: true, arrived: !!r.arrived } : r;
  };

  // One call: Continue (as many times as needed) -> payment page -> PhonePe
  // (or the Card option when opts.useCard) -> Pay.
  window.__pilgrimAutoContinuePay = async function (opts) {
    opts = opts || {};
    try {
      const drive = await window.__pilgrimDrive({ mode: "pay", finalPay: "click", payload: opts.payload, maxMs: 60000 });
      if (!drive.ok) return drive;

      if (opts.useCard) {
        const sel = await window.__pilgrimSelectCardOption();
        if (!sel.ok) return { ok: false, reason: sel.reason };
        const cardPageReady = await waitFor(() => hasCardNumberField() || null, 6000, 200);
        return { ok: true, cardMode: true, cardPageReady: !!cardPageReady };
      }

      const phonePeSelected = await waitFor(() => selectPaymentOption(PHONEPE_TEXTS) || null, 4000, 150);
      const proceed = await showCountdownOverlay(2, phonePeSelected ? "Opening PhonePe" : "Proceeding to payment");
      if (!proceed) return { ok: false, reason: "Payment cancelled" };
      const fin = await waitFor(() => {
        const b = findActionButton(FINAL_PAY_EXACT.concat(NEXT_EXACT));
        return b && b.enabled ? b : null;
      }, 6000, 200);
      if (!fin) return { ok: false, reason: "Reached the payment page, but no enabled Pay Now/Continue button was found to finish it" };
      fin.el.scrollIntoView({ block: "center" });
      fireClickSequence(fin.el);
      return { ok: true, phonePeSelected: !!phonePeSelected };
    } catch (err) {
      return { ok: false, reason: (err && err.message) || String(err) };
    }
  };

  // Best-effort booking-confirmation scraper — looks for a PNR/Booking
  // ID/Reference/Transaction number pattern anywhere in the page's visible
  // text. Only meaningfully useful right after a click that stays on TTD's
  // own site (Book Now for Angapradakshana); the Pay Now/PhonePe path
  // redirects off-site for the actual payment, so there's no confirmation
  // text left on this page to find at that point — this simply returns
  // null there rather than guessing at something that isn't on the page.
  function scrapeConfirmationRef() {
    try {
      const text = document.body.innerText || "";
      const patterns = [
        /\b(?:booking|transaction|reference|confirmation|receipt)\s*(?:id|no\.?|number)\s*[:\-]?\s*([A-Z0-9\-\/]{5,30})/i,
        /\bPNR\s*[:\-]?\s*([A-Z0-9\-\/]{5,30})/i
      ];
      for (const re of patterns) {
        const m = text.match(re);
        if (m && m[1]) return m[1].trim();
      }
    } catch (_) {
      // Best-effort only — never let a scrape failure affect the flow.
    }
    return null;
  }

  // ---------------------------------------------------------------------
  // Auto Continue → Book Now (Angapradakshana and any other "Book Now"
  // flow). Clicks Continue however many times the screens need, then
  // Book Now after a cancel-able 2s countdown. See __pilgrimDrive.
  // ---------------------------------------------------------------------
  window.__pilgrimAutoContinueBook = async function (opts) {
    try {
      const r = await window.__pilgrimDrive({ mode: "book", payload: opts && opts.payload, maxMs: 60000 });
      return r.ok ? { ok: true, confirmationRef: r.confirmationRef } : r;
    } catch (err) {
      return { ok: false, reason: (err && err.message) || String(err) };
    }
  };

  // ---------------------------------------------------------------------
  // Preferred date / number of tickets / slot (booking calendar step)
  //
  // Before Pilgrim Details even exists, TTD's "Special Entry Darshan"-style
  // booking pages show a month calendar (day cells color-coded per a
  // legend: Available/Quota is Full/Quota Not Released/Filling Fast/Slot
  // Not Available). Picking a day is what makes "Number of Tickets" (a
  // custom dropdown) and a list of time-slot cards (radio-selectable,
  // "Slot Time 8:00 pm" / "1 Person" / "₹300") appear — neither exists in
  // the DOM before that. Only once a slot's picked does Continue lead to
  // Pilgrim Details.
  // ---------------------------------------------------------------------

  const MONTH_NAMES = [
    "january", "february", "march", "april", "may", "june",
    "july", "august", "september", "october", "november", "december"
  ];

  function parseISODate(str) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str || "");
    if (!m) return null;
    return { year: Number(m[1]), month: Number(m[2]) - 1, day: Number(m[3]) };
  }

  // Finds a leaf element whose whole text is exactly "<Month> <Year>", e.g.
  // "August 2026" — this calendar's own month/year heading.
  function findCalendarHeading() {
    const candidates = document.querySelectorAll("h1, h2, h3, h4, h5, div, span, p");
    for (const el of candidates) {
      if (el.children.length > 0) continue;
      if (!isVisible(el)) continue;
      const t = textOf(el);
      const m = /^([a-z]+)\s+(\d{4})$/.exec(t);
      if (!m) continue;
      const month = MONTH_NAMES.indexOf(m[1]);
      if (month === -1) continue;
      return { el, month, year: Number(m[2]) };
    }
    return null;
  }

  function findCalendarNavButton(direction) {
    const ariaWords = direction === "next" ? ["next"] : ["previous", "prev"];
    const nodes = document.querySelectorAll('button, [role="button"], a');
    for (const el of nodes) {
      if (!isClickEnabled(el)) continue;
      const aria = (el.getAttribute("aria-label") || el.getAttribute("title") || "").toLowerCase();
      if (ariaWords.some((w) => aria.includes(w))) return el;
    }
    // Fall back to a lone arrow glyph — this calendar's prev/next buttons
    // sit beside the grid itself with no visible text besides the glyph.
    const glyphs = direction === "next" ? ["›", ">", "❯", "»"] : ["‹", "<", "❮", "«"];
    for (const el of nodes) {
      if (!isClickEnabled(el)) continue;
      const t = (el.innerText || el.textContent || "").trim();
      if (glyphs.includes(t)) return el;
    }
    // TTD's own arrows carry neither text nor an aria-label at all — just
    // a left/right arrow <img>, e.g. <div class="...arrow..."><img
    // src="/right_arrow_black.png"></div>. Confirmed on every booking
    // flow's calendar (Special Entry Darshan, Angapradakshinam, Arjitha
    // Seva all use the same component). Click the wrapping element (the
    // actual click handler normally sits there, not on the <img> itself).
    const imgKeyword = direction === "next" ? "right_arrow" : "left_arrow";
    const img = document.querySelector(`img[src*="${imgKeyword}"]`);
    if (img) {
      const clickTarget = [img, img.parentElement, img.parentElement?.parentElement].find(
        (el) => el && isClickEnabled(el)
      );
      if (clickTarget) return clickTarget;
      if (img.parentElement) return img.parentElement; // click anyway — isClickEnabled may be too strict for a bare div
    }
    return null;
  }

  async function navigateToMonth(target) {
    for (let i = 0; i < 24; i++) {
      const heading = findCalendarHeading();
      if (!heading) return null; // no calendar on this page at all
      if (heading.month === target.month && heading.year === target.year) return heading;
      const wantNext = heading.year < target.year || (heading.year === target.year && heading.month < target.month);
      const btn = findCalendarNavButton(wantNext ? "next" : "prev");
      if (!btn) return heading; // can't navigate further — report whatever month we're stuck on
      fireClickSequence(btn);
      await delay(300);
    }
    return findCalendarHeading();
  }

  // Real, currently-in-month days on this calendar get one of the legend's
  // availability colors; spillover days from the previous/next month are
  // left plain. Checked a couple of ancestors up too, since the color is
  // sometimes painted on a wrapping cell rather than the day-number text
  // itself.
  function cellBackgroundIsColored(el) {
    let node = el;
    for (let i = 0; i < 3 && node; i++, node = node.parentElement) {
      const bg = getComputedStyle(node).backgroundColor;
      if (!bg) continue;
      if (bg === "transparent" || bg === "rgba(0, 0, 0, 0)") continue;
      if (/^rgba?\(255,\s*255,\s*255/.test(bg)) continue; // plain white
      return true;
    }
    return false;
  }

  function findDayCell(day) {
    const wanted = String(day);
    const candidates = [...document.querySelectorAll("td, div, span, button, a")].filter((el) => {
      if (el.children.length > 0) return false; // leaf text only
      if (!isVisible(el)) return false;
      return textOf(el) === wanted;
    });
    if (!candidates.length) return null;
    const colored = candidates.filter(cellBackgroundIsColored);
    // Prefer a colored (real, in-month) cell over a plain spillover one.
    // Among duplicates, a spillover cell for the same day number normally
    // comes FIRST in document order (previous month's tail row, above the
    // real grid) — so the true cell for the currently-displayed month is
    // the last match.
    const pool = colored.length ? colored : candidates;
    return pool[pool.length - 1];
  }

  function findTicketTrigger() {
    const nodes = document.querySelectorAll(DROPDOWN_TRIGGER_SELECTOR + ", select");
    for (const el of nodes) {
      if (!isVisible(el)) continue;
      const sig = [labelForField(el), signature(el)].join(" ").toLowerCase();
      // Angapradakshinam labels this control "Number of Persons" (seen in a
      // real booking recording), the darshan/seva pages say "tickets".
      if (sig.includes("number of tickets") || sig.includes("tickets") ||
          sig.includes("number of persons") || sig.includes("no. of persons") || sig.includes("no of persons")) return el;
    }
    return null;
  }

  // Clicks a ticket-count trigger and finds the matching option SCOPED to
  // the trigger's own DOM neighborhood, instead of going through
  // selectFromDropdown's whole-page fallback. findOpenMenu() only
  // recognizes a handful of known widget-library class names (MUI,
  // PrimeNG, ng-select, select2, react-select); TTD's own ticket-count
  // popup is a bespoke, class-name-less <div> that matches none of them,
  // so selectFromDropdown falls straight through to a whole-PAGE text
  // search. That's fine for Gender/Photo ID Proof (their option text —
  // "Male", "Aadhaar Card" — can't collide with anything else on the
  // page), but a ticket count is a bare 1–2 digit number, and the
  // Darshan-date calendar (day cells "1".."31", also short exact-text
  // leaf nodes) sits elsewhere on this same page — a whole-page search
  // for "2" can find and click a calendar day instead of the real
  // option, which then silently reports success (a click happened) while
  // the ticket count itself never actually changed. Searching a few
  // ancestor levels out from the TRIGGER ITSELF (where TTD actually
  // renders the popup, structurally — a sibling within a couple of
  // levels) finds the real option without ever risking that collision,
  // regardless of what class names the popup uses.
  async function clickTicketOptionNearTrigger(trigger, wantedCount, dryRun) {
    const wanted = String(wantedCount).trim();
    trigger.scrollIntoView({ block: "center" });
    trigger.focus?.();
    if (dryRun) {
      markDry(trigger);
      return true;
    }
    fireClickSequence(trigger);
    let option = null;
    let scope = trigger.parentElement;
    for (let hop = 0; scope && hop < 4 && !option; hop++, scope = scope.parentElement) {
      option = await waitFor(() => {
        const found = [...scope.querySelectorAll("*")].find(
          (el) => el !== trigger && !trigger.contains(el) && isVisible(el) && el.children.length === 0 && textOf(el) === wanted
        );
        return found || null;
      }, 500, 80);
    }
    if (!option) return false;
    option.scrollIntoView({ block: "nearest" });
    fireClickSequence(option);
    return true;
  }

  // If ticket-count selection keeps failing, run this in the page's dev
  // console (F12 → Console) while the date/slot/ticket screen is on
  // screen. It shows exactly what findTicketTrigger() finds (if
  // anything) and what its computed label text is, so a mismatch shows
  // up directly instead of only surfacing as a silent miss.
  window.__pilgrimTicketDebug = function () {
    console.group("Pilgrim Assistant — ticket-count scan");
    const nodes = [...document.querySelectorAll(DROPDOWN_TRIGGER_SELECTOR + ", select")].filter(isVisible);
    console.log(
      `Dropdown-trigger candidates on this page (${nodes.length}):`,
      nodes.map((el) => ({
        tag: el.tagName,
        label: labelForField(el),
        signature: signature(el),
        value: el.value,
        text: textOf(el)
      }))
    );
    const trigger = findTicketTrigger();
    console.log("findTicketTrigger() result:", trigger ? { tag: trigger.tagName, label: labelForField(trigger), value: trigger.value } : null);
    if (!trigger) {
      console.log(
        'No element\'s label/signature contained "tickets" — either the caption text differs from ' +
          '"Number of Tickets" on this page, or the control renders as something DROPDOWN_TRIGGER_SELECTOR ' +
          "doesn't match yet (check the selector list above findTicketTrigger in content.js)."
      );
    }
    console.groupEnd();
  };

  function findSlotTimeElement() {
    const nodes = document.querySelectorAll("div, span, p, li");
    for (const el of nodes) {
      if (el.children.length > 2) continue;
      if (!isVisible(el)) continue;
      if (textOf(el).startsWith("slot time")) return el;
    }
    return null;
  }

  // Mirrors findTicketTrigger() below, for the slot picker. This existed
  // as a presence-check (findSlotTimeElement, used only by
  // looksLikeDateSlotPage) long before selectDateSlot actually tried to
  // pick a specific slot — the selection code only ever attempted
  // selectPaymentOption's open tile/radio matching, with no path at all
  // for a slot picker that's a closed dropdown needing a click to reveal
  // its options first, the same shape the ticket-count control already
  // needed clickTicketOptionNearTrigger for. If TTD renders slots that
  // way, tile/radio matching alone would find nothing to click no matter
  // how correct the wanted slot text was — indistinguishable from
  // outside from "the slot list is there but doesn't have this time".
  function findSlotTrigger() {
    const nodes = document.querySelectorAll(DROPDOWN_TRIGGER_SELECTOR + ", select");
    for (const el of nodes) {
      if (!isVisible(el)) continue;
      const sig = [labelForField(el), signature(el)].join(" ").toLowerCase();
      if (sig.includes("slot") || sig.includes("darshan time")) return el;
    }
    return null;
  }

  // Same scoped-search approach as clickTicketOptionNearTrigger (click the
  // trigger, then look only a few DOM levels out from it, never the whole
  // page) — but matching by "contains", not exact equality: a slot's
  // visible text is often more than the bare time ("1:00 PM", "1:00 PM -
  // 2:00 PM", plus seat count or price alongside it in the same tile),
  // so requiring an exact match the way ticket-count needs to (to avoid
  // colliding with calendar day numbers) would just as often reject the
  // right option outright.
  async function clickSlotOptionNearTrigger(trigger, wantedText, dryRun) {
    const wanted = String(wantedText).trim().toLowerCase();
    trigger.scrollIntoView({ block: "center" });
    trigger.focus?.();
    if (dryRun) {
      markDry(trigger);
      return true;
    }
    fireClickSequence(trigger);
    let option = null;
    let scope = trigger.parentElement;
    for (let hop = 0; scope && hop < 4 && !option; hop++, scope = scope.parentElement) {
      option = await waitFor(() => {
        const found = [...scope.querySelectorAll("*")].find(
          (el) =>
            el !== trigger &&
            !trigger.contains(el) &&
            isVisible(el) &&
            el.children.length <= 2 &&
            textOf(el).toLowerCase().includes(wanted)
        );
        return found || null;
      }, 500, 80);
    }
    if (!option) return false;
    option.scrollIntoView({ block: "nearest" });
    fireClickSequence(option);
    return true;
  }

  // ---------------------------------------------------------------------
  // Slot fallback list: "Preferred Slot" can hold an ordered,
  // comma-separated list ("1:00 PM, 2:00 PM, 3:00 PM") instead of a
  // single time. trySelectSlotCandidate tries ONE candidate and reports
  // whether it looks genuinely full/unavailable (so the caller moves on
  // to the next preference) vs. just not found at all (also moves on —
  // there's nothing useful to retry against).
  // ---------------------------------------------------------------------
  const UNAVAILABLE_TILE_PATTERN = /\bfull\b|sold\s*out|not\s*available|unavailable|\b0\s*(seats?|slots?|tickets?)\b|closed/;

  function tileLooksUnavailable(el) {
    if (!el) return true;
    const sig = paymentOptionSignature(el);
    if (UNAVAILABLE_TILE_PATTERN.test(sig)) return true;
    if (el.matches?.('[disabled], [aria-disabled="true"]')) return true;
    if (!isClickEnabled(el)) return true;
    return false;
  }

  async function trySelectSlotCandidate(wantedRaw, dryRun) {
    const wanted = String(wantedRaw).trim().toLowerCase();
    if (!wanted) return { ok: false, reason: "empty slot text" };

    // Same tile/radio matching findPaymentOption already does for payment
    // options — a slot card (time + seat count + price + a radio) is
    // structurally the same shape. maxSigLen raised since a slot tile's
    // text routinely runs longer than a payment method's.
    const target = await waitFor(() => findPaymentOption([wanted], 160) || null, 1500, 150);
    if (target) {
      if (tileLooksUnavailable(target)) {
        return { ok: false, reason: `"${wantedRaw}" looks full/unavailable` };
      }
      if (dryRun) {
        markDry(target);
        return { ok: true };
      }
      if (target.matches?.('input[type="radio"], [role="radio"]')) {
        if (target.labels && target.labels.length) fireClickSequence(target.labels[0]);
        target.checked = true;
        target.dispatchEvent(new Event("input", { bubbles: true }));
        target.dispatchEvent(new Event("change", { bubbles: true }));
      }
      target.scrollIntoView({ block: "center" });
      fireClickSequence(target);
      return { ok: true };
    }

    // No open tile matched — the slot picker may instead be a closed
    // dropdown needing a click to reveal its options first (same shape
    // ticket-count needs clickTicketOptionNearTrigger for).
    const slotTrigger = findSlotTrigger();
    if (slotTrigger) {
      const ok = await clickSlotOptionNearTrigger(slotTrigger, wantedRaw, dryRun);
      return ok ? { ok: true } : { ok: false, reason: `no option matching "${wantedRaw}" found after opening the slot list` };
    }

    return { ok: false, reason: `no slot tile/dropdown matching "${wantedRaw}" found on this page` };
  }

  // True once this page shows either the calendar itself, the ticket-count
  // control, or a slot card — i.e. any part of the pre-Pilgrim-Details
  // booking step. Used to skip selectDateSlot entirely on a page that's
  // already past this step (e.g. a second "Fill All Details" tap on the
  // Pilgrim Details form itself), same reasoning as the rest of this
  // codebase avoids reporting a field as "missed" when it was never
  // applicable to the current page in the first place.
  function looksLikeDateSlotPage() {
    return !!(findCalendarHeading() || findTicketTrigger() || findSlotTimeElement());
  }

  // TTD-specific fast path. Verified directly against a real page dump of
  // this exact calendar (Special Entry Darshan's "Darshan Slots" widget,
  // which renders July–October 2026 simultaneously): every day cell's id
  // is "day/month" with month 0-indexed — Jan=0 ... Dec=11 — same as
  // target.month below. Checked across all three month boundaries in
  // that dump: 30 June is id="30/5", 1 July is id="1/6" (June=5, July=6);
  // 31 July is id="31/6", 1 August is id="1/7" (July=6, August=7); 31
  // August is id="31/7", 1 September is id="1/8" (August=7, September=8).
  // An earlier version of this fast path added 1 to target.month on the
  // (incorrect, unverified) assumption that the site's own ids were
  // 1-indexed — that off-by-one is exactly why date auto-select kept
  // silently landing on the wrong day or finding nothing at all. Unlike
  // the generic scan below, this also can't collide with a spillover day
  // from a neighbouring month showing the same bare number, since the id
  // encodes the month too.
  // Critically, this calendar renders ALL of July through October at
  // once — there's no "current month" to page through — but
  // navigateToMonth (below) assumes a single-month-at-a-time picker and
  // requires its header-matching loop to succeed before ever attempting
  // a day click. Since the real "next/prev" controls are bare <img>
  // arrows with no text or aria-label (nothing navigateToMonth's button
  // finder can match), that requirement was failing on essentially every
  // real booking flow, well before selectDateSlot ever got as far as
  // clicking a date at all — this fast path sidesteps that requirement
  // entirely whenever the id lookup succeeds.
  function findTtdCalendarCellById(target) {
    const id = `${target.day}/${target.month}`; // both sides 0-indexed — see comment above
    const cell = document.getElementById(id);
    if (!cell || cell.tagName !== "TD" || !isVisible(cell)) return null;
    return cell;
  }

  function ttdCalendarCellClickability(cell) {
    const cursor = (cell.style?.cursor || "").toLowerCase();
    const pointerEvents = (cell.style?.pointerEvents || "").toLowerCase();
    if (pointerEvents === "none") {
      return { clickable: false, reason: "not open for booking yet (quota not released, or outside the bookable window)" };
    }
    if (cursor === "not-allowed") {
      return { clickable: false, reason: "not available (fully booked or closed for this date)" };
    }
    return { clickable: true };
  }

  // If slot selection keeps failing, run this in the page's dev console
  // (F12 → Console) while the date/slot/ticket screen is showing. Shows
  // exactly what findSlotTrigger() finds (if the picker is a closed
  // dropdown) and what tile-based candidates exist on the page (if it's
  // an open list), so a mismatch shows up directly instead of only
  // surfacing as a silent miss.
  window.__pilgrimSlotDebug = function () {
    console.group("Pilgrim Assistant — slot scan");
    const trigger = findSlotTrigger();
    console.log(
      "findSlotTrigger() result:",
      trigger ? { tag: trigger.tagName, label: labelForField(trigger), value: trigger.value } : null
    );
    const tiles = [...document.querySelectorAll('li, div, button, a, [role="button"], [role="option"], input[type="radio"]')].filter(
      (el) => isVisible(el) && el.children.length <= 8
    );
    console.log(
      `Tile/radio candidates on this page (${tiles.length}):`,
      tiles.map((el) => ({ tag: el.tagName, signature: paymentOptionSignature(el) })).filter((x) => x.signature)
    );
    console.groupEnd();
  };

  async function selectDateSlotOnce(dateSlot, dryRun) {
    try {
      const target = parseISODate(dateSlot.date);
      if (!target) return { ok: false, reason: "no preferred date set" };

      const ttdCell = findTtdCalendarCellById(target);
      let cell;
      if (ttdCell) {
        const { clickable, reason } = ttdCalendarCellClickability(ttdCell);
        if (!clickable) return { ok: false, reason: `date not selectable — ${reason}` };
        cell = ttdCell;
      } else {
        // Not this site's calendar (or the target month isn't rendered
        // yet) — fall back to the generic single-month-at-a-time flow.
        const heading = await navigateToMonth(target);
        if (!heading) return { ok: false, reason: "date picker not found on this page" };
        if (heading.month !== target.month || heading.year !== target.year) {
          return { ok: false, reason: "couldn't navigate the calendar to the requested month" };
        }
        cell = findDayCell(target.day);
        if (!cell) return { ok: false, reason: `no selectable day ${target.day} found on the calendar` };
      }
      cell.scrollIntoView({ block: "center" });
      if (dryRun) {
        // Dry-run stops right here: highlight the day that would be
        // clicked, and don't touch the ticket-count/slot list at all
        // (they don't exist in the DOM until the real click happens), so
        // there's nothing further to preview on this page in one pass.
        markDry(cell);
        return { ok: true, dryRun: true, note: `would select ${dateSlot.date}${dateSlot.slot ? ` / ${dateSlot.slot}` : ""}${dateSlot.ticketCount ? ` / ${dateSlot.ticketCount} ticket(s)` : ""}, then Continue` };
      }
      fireClickSequence(cell);

      // Ticket count and the slot list only render once a date's actually
      // been accepted — wait for either to show up rather than assuming
      // the click "took".
      const dateAccepted = await waitFor(() => findTicketTrigger() || findSlotTimeElement() || null, 4000, 150);
      if (!dateAccepted) {
        return {
          ok: false,
          reason: "date was clicked but the ticket/slot list never appeared — that day may not be bookable"
        };
      }

      let ticketOk = true;
      let ticketReason = "";
      if (dateSlot.ticketCount) {
        const trigger = findTicketTrigger();
        // Arjitha Seva shows the ticket count as a locked (disabled) "01":
        // the seva fixes the number of persons. That is not a failure —
        // use what the page allows instead of stalling on it.
        const ticketLocked = !!trigger && (trigger.disabled || trigger.getAttribute("aria-disabled") === "true");
        if (!trigger) {
          ticketOk = false;
        } else if (ticketLocked) {
          ticketOk = true;
        } else {
          const res = await selectFromDropdown(trigger, dateSlot.ticketCount, null);
          ticketOk = !!res.ok;
          if (!ticketOk) {
            ticketReason = res.reason;
            ticketOk = await clickTicketOptionNearTrigger(trigger, dateSlot.ticketCount);
          }
        }
      }

      // "Preferred Slot" may hold an ordered, comma-separated fallback
      // list ("1:00 PM, 2:00 PM, 3:00 PM") — try each in turn and stop at
      // the first one that isn't full/unavailable. A single slot with no
      // comma behaves exactly as before (one-element list).
      let slotOk = true;
      const slotAttempts = [];
      if (dateSlot.slot) {
        const candidates = String(dateSlot.slot)
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean);
        slotOk = false;
        for (const candidate of candidates) {
          const res = await trySelectSlotCandidate(candidate, false);
          slotAttempts.push(`"${candidate}": ${res.ok ? "selected" : res.reason}`);
          if (res.ok) {
            slotOk = true;
            break;
          }
        }
      }

      if (!ticketOk || !slotOk) {
        const parts = [];
        if (!ticketOk) parts.push(`couldn't set the ticket count${ticketReason ? " (" + ticketReason + ")" : ""}`);
        if (!slotOk) parts.push(`couldn't select any of the preferred slots (${slotAttempts.join("; ")})`);
        return { ok: false, reason: parts.join("; ") };
      }

      // Optional "Additional Services" section on this same page (No. of
      // Additional Laddus / Hundi Offerings) — confirmed against a real
      // recording that these sit right below the slot tiles, are entirely
      // optional, and Continue enables without them. Only touched if the
      // person actually set a value; page-level (one field each), not
      // per-pilgrim, so a plain fresh scan is enough — no need for the
      // fuller pilgrim/contact machinery scanAndFill uses.
      if (dateSlot.additionalLaddus || dateSlot.hundiOffering) {
        const { plain } = collectFields();
        const byKey = bucketByKey(classifyList(plain));
        if (dateSlot.additionalLaddus) setPlainValue(byKey.additionalLaddus?.[0], dateSlot.additionalLaddus);
        if (dateSlot.hundiOffering) setPlainValue(byKey.hundiOffering?.[0], dateSlot.hundiOffering);
      }

      const continueBtn = await waitForEnabledContinue(5000);
      if (!continueBtn) return { ok: false, reason: "date/tickets/slot selected, but Continue is disabled or not found" };
      continueBtn.scrollIntoView({ block: "center" });
      fireClickSequence(continueBtn);
      // If the page didn't move on, retry with a genuine tap.
      const moved = await waitFor(() => !looksLikeDateSlotPage() || !continueBtn.isConnected, 1200, 80);
      if (!moved && !__trusted.unavailable) await trustedTap(continueBtn);
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: (err && err.message) || String(err) };
    }
  }

  // "Preferred Darshan Date" may hold an ordered, comma-separated fallback
  // list of ISO dates ("2026-09-12, 2026-09-13") — same pattern as the
  // slot fallback list above. Only advances to the next date when THIS
  // date itself looked unavailable/not-selectable; a ticket-count or
  // slot-selection failure is a page-level problem trying another day
  // wouldn't fix, so that stops immediately rather than risking an
  // unintended date getting booked.
  async function selectDateSlot(dateSlotRaw, dryRun) {
    const candidates = String(dateSlotRaw?.date || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (candidates.length <= 1) return selectDateSlotOnce(dateSlotRaw, dryRun);

    const attempts = [];
    for (const d of candidates) {
      const res = await selectDateSlotOnce({ ...dateSlotRaw, date: d }, dryRun);
      if (res.ok) return res;
      attempts.push(`${d}: ${res.reason}`);
      if (!/date not selectable|no selectable day|couldn't navigate the calendar|date picker not found/i.test(res.reason || "")) {
        return { ok: false, reason: `${res.reason} (tried ${d}; not trying further dates since this wasn't an availability problem)` };
      }
    }
    return { ok: false, reason: `none of the preferred dates were selectable (${attempts.join("; ")})` };
  }

  // ---------------------------------------------------------------------
  // Accommodation tab
  //
  // Built from a real TTD accommodation-booking walkthrough video, not a
  // live recorded session on our own account — every page/label/button
  // text below is transcribed as accurately as the footage allowed, but
  // a couple of things (the exact field order below "State" in General
  // Details — Country/Pincode are assumed present per the standard
  // address-field set this file already matches everywhere else; whether
  // a review screen sits between General Details and the Payment page)
  // couldn't be pinned down frame-by-frame and are handled generically
  // instead of hard-coded — see the comments at each such step below.
  // This hasn't been run against the live site, so treat the first run
  // like any new flow: watch it, don't walk away from it.
  //
  // Observed flow, in order:
  //   1. /accommodation/instructions — sometimes shows a virtual-queue
  //      wait first ("You've been placed in a virtual queue due to
  //      exceptionally high demand", max ~6 minutes), then the actual
  //      "IMPORTANT INSTRUCTION" page: a checkbox ("I have read and agree
  //      to the instructions") gates the Continue button.
  //   2. Accommodation Details: Select Location*, Check In Time Slot*,
  //      No of Pilgrims*, and a multi-month calendar.
  //      - TIRUMALA/TIRUPATI "(Exclusively for ticket holders)" options
  //        require linking a real Darshan/Seva ticket: choosing either
  //        one navigates to a separate "Select service" step, then a list
  //        of the pilgrim's own past bookings for that service, each with
  //        its own "Book Accommodation" button (only enabled on eligible
  //        ones). Clicking it returns to this same Accommodation Details
  //        page with Location pre-filled and the calendar auto-restricted
  //        to only the date(s) that ticket covers — so a user-provided
  //        date is neither needed nor able to override that; this flow
  //        just clicks whichever calendar day is actually clickable.
  //      - Plain TIRUPATI/TALAKONA/VONTIMITTA skip that ticket-linking
  //        step entirely and go straight to picking a date normally,
  //        using payload.date the same way selectDateSlot does elsewhere
  //        in this file.
  //   3. Available Rooms: price-tiered tiles (₹100 / ₹999 / ₹1518 AC, in
  //      the walkthrough — TTD may add/remove/reprice tiers over time, so
  //      this matches on price text rather than a hard-coded tile list).
  //      Continue → a "TTD Online booking portal" confirmation popup → Okay.
  //   4. Pilgrim details: a checkbox per name pulled from the linked
  //      ticket ("select any of two names from the list") — this checks
  //      exactly payload.pilgrimSelectCount (default 2), not "select
  //      every box" (ensurePilgrimCardsSelected above is deliberately not
  //      reused here for that reason). Then General Details — Email/City/
  //      State/Country/Pincode — filled through the same fillContact/
  //      KEYWORDS matching every other tab already uses.
  //   5. Continue → Payment ("Choose the payment method below", UPI /
  //      Credit-Debit-ATM Card / Netbanking, "Pay Now"). Reuses
  //      clickThroughToPayNow so any review screen the footage didn't
  //      capture between General Details and Payment still gets hopped
  //      through automatically, the same way it already does for SED/
  //      Arjitha Seva; and reuses fillCardFields + the existing 10s
  //      Cancel-able countdown (CARD_PROCEED_TEXTS already includes
  //      "pay now") rather than adding a second, parallel countdown.
  // ---------------------------------------------------------------------

  function findAccommodationQueueBanner() {
    const b = (document.body?.innerText || "").toLowerCase();
    return b.includes("virtual queue") || (b.includes("placed in a") && b.includes("queue") && b.includes("high demand"));
  }

  async function waitOutAccommodationQueue(maxMs = 6 * 60 * 1000) {
    if (!findAccommodationQueueBanner()) return { ok: true, waited: false };
    const deadline = Date.now() + maxMs;
    while (Date.now() < deadline) {
      if (!findAccommodationQueueBanner()) return { ok: true, waited: true };
      await delay(1000);
    }
    return { ok: !findAccommodationQueueBanner(), waited: true, timedOut: findAccommodationQueueBanner() };
  }

  function findLabeledCheckbox(matchWords) {
    const boxes = [...document.querySelectorAll('input[type="checkbox"]')].filter(isVisible);
    return boxes.find((cb) => {
      const near = (labelForField(cb) || textOf(cb.closest("label, div, li")) || "").toLowerCase();
      return matchWords.every((w) => near.includes(w));
    }) || null;
  }

  async function acceptAccommodationInstructions() {
    if (!/important instruction/i.test(document.body?.innerText || "")) return { ok: true, skipped: true };
    const cb = findLabeledCheckbox(["read", "agree"]);
    if (cb && !checkboxIsChecked(cb)) {
      cb.scrollIntoView({ block: "center" });
      fireClickSequence(cb);
      await delay(200);
    }
    const btn = await waitForEnabledContinue(4000);
    if (!btn) return { ok: false, reason: "instructions checkbox ticked, but Continue never enabled" };
    fireClickSequence(btn);
    await delay(600);
    return { ok: true };
  }

  function findLabeledDropdownTrigger(matchWords) {
    const nodes = document.querySelectorAll(DROPDOWN_TRIGGER_SELECTOR + ", select");
    for (const el of nodes) {
      if (!isVisible(el)) continue;
      const sig = [labelForField(el), signature(el)].join(" ").toLowerCase();
      if (matchWords.every((w) => sig.includes(w))) return el;
    }
    return null;
  }

  async function selectAccommodationLocation(locationText) {
    if (!locationText) return { ok: false, reason: "no location provided" };
    const trigger = findLabeledDropdownTrigger(["location"]);
    if (!trigger) return { ok: false, reason: "Select Location field not found" };
    return selectFromDropdown(trigger, locationText, null);
  }

  async function selectAccommodationService(serviceText) {
    if (!serviceText) return { ok: false, reason: "no service provided" };
    const trigger = await waitFor(() => findLabeledDropdownTrigger(["service"]), 4000, 150);
    if (!trigger) return { ok: false, reason: "Select service field not found" };
    return selectFromDropdown(trigger, serviceText, null);
  }

  async function clickEligibleBookAccommodationButton() {
    const btn = await waitForButton(["book accommodation"], 6000);
    if (!btn) return { ok: false, reason: 'no enabled "Book Accommodation" button found among the ticket list' };
    fireClickSequence(btn);
    await delay(700);
    return { ok: true };
  }

  async function selectAccommodationCheckInSlot(slotText) {
    if (!slotText) return { ok: true, skipped: true };
    const trigger = findLabeledDropdownTrigger(["check", "time"]) || findLabeledDropdownTrigger(["check-in"]);
    if (!trigger) return { ok: false, reason: "Check In Time Slot field not found" };
    return selectFromDropdown(trigger, slotText, null);
  }

  // Ticket-linked bookings pre-restrict the calendar to the only day(s)
  // that ticket covers (see the flow comment above) — payload.date is
  // ignored in that case since there's nothing to choose between; this
  // just clicks whatever the site itself left clickable.
  async function selectAnyClickableAccommodationDate() {
    const cells = [...document.querySelectorAll("td")].filter(isVisible);
    for (const cell of cells) {
      if (!/^\d{1,2}$/.test(textOf(cell))) continue;
      const { clickable } = ttdCalendarCellClickability(cell);
      if (clickable) {
        cell.scrollIntoView({ block: "center" });
        fireClickSequence(cell);
        await delay(500);
        return { ok: true };
      }
    }
    return { ok: false, reason: "no clickable calendar date found" };
  }

  async function selectAccommodationDate(dateISO) {
    if (dateISO) {
      const target = parseISODate(dateISO);
      if (target) {
        const cell = findTtdCalendarCellById(target) || (await (async () => {
          const heading = await navigateToMonth(target);
          return heading && heading.month === target.month && heading.year === target.year ? findDayCell(target.day) : null;
        })());
        if (cell) {
          const { clickable, reason } = ttdCalendarCellClickability(cell);
          if (!clickable) return { ok: false, reason: `date not selectable — ${reason}` };
          cell.scrollIntoView({ block: "center" });
          fireClickSequence(cell);
          await delay(500);
          return { ok: true };
        }
      }
    }
    // No date given, or the given one wasn't found — most likely this is
    // the ticket-linked case where the calendar is already restricted to
    // one clickable day. Fall back to clicking whichever day is open.
    return selectAnyClickableAccommodationDate();
  }

  async function selectAccommodationRoomByPrice(price) {
    if (!price) return { ok: false, reason: "no room price given" };
    const wanted = String(price).replace(/[^\d]/g, "");
    if (!wanted) return { ok: false, reason: `couldn't parse a price from "${price}"` };
    const rows = [...document.querySelectorAll("body *")].filter(
      (el) => isVisible(el) && el.children.length <= 6 && new RegExp(`(?:₹|rs\\.?\\s*)${wanted}\\b`, "i").test(textOf(el))
    );
    if (!rows.length) return { ok: false, reason: `no room tile showing ₹${wanted} found` };
    // Prefer the smallest matching element (the price label itself, not an
    // ancestor wrapping the whole tile list) to scope the radio search.
    rows.sort((a, b) => textOf(a).length - textOf(b).length);
    const priceEl = rows[0];
    let scope = priceEl;
    let radio = null;
    for (let hop = 0; hop < 4 && scope && !radio; hop++, scope = scope.parentElement) {
      radio = scope.querySelector('input[type="radio"], [role="radio"]');
    }
    const clickTarget = radio || priceEl.closest('[role="button"], li, div');
    if (!clickTarget) return { ok: false, reason: `found the ₹${wanted} tile but no selectable radio/row near it` };
    clickTarget.scrollIntoView({ block: "center" });
    fireClickSequence(clickTarget);
    await delay(300);
    return { ok: true };
  }

  async function confirmAccommodationOkayPopup() {
    // Not every path necessarily shows this modal (e.g. if TTD changes it,
    // or a returning pilgrim has already seen/dismissed it this session)
    // — absence isn't a failure, so this only acts when the popup is
    // actually there rather than requiring it.
    const btn = await waitForButton(["okay", "ok", "got it"], 3000);
    if (!btn) return { ok: true, skipped: true };
    fireClickSequence(btn);
    await delay(400);
    return { ok: true };
  }

  async function checkExactlyNPilgrimBoxes(n) {
    const boxes = findPilgrimCardCheckboxes();
    if (!boxes.length) return { ok: true, selected: 0, none: true };
    let selected = 0;
    for (const cb of boxes) {
      if (selected >= n) break;
      if (!checkboxIsChecked(cb)) {
        cb.scrollIntoView({ block: "center" });
        fireClickSequence(cb);
        await delay(150);
      }
      if (checkboxIsChecked(cb)) selected++;
    }
    if (selected >= n) return { ok: true, selected };
    return { ok: false, selected, reason: `only ${selected} of ${n} requested pilgrim box(es) got checked` };
  }

  window.__pilgrimAccommodationDebug = function () {
    console.group("Pilgrim Assistant — accommodation scan");
    console.log("queue banner present:", findAccommodationQueueBanner());
    console.log("location trigger:", findLabeledDropdownTrigger(["location"]));
    console.log("service trigger:", findLabeledDropdownTrigger(["service"]));
    console.log("check-in slot trigger:", findLabeledDropdownTrigger(["check", "time"]));
    console.log("pilgrim checkboxes found:", findPilgrimCardCheckboxes().length);
    console.groupEnd();
  };

  window.__pilgrimAccommodationFlow = async function (payload = {}) {
    const steps = {};
    try {
      steps.queue = await waitOutAccommodationQueue();
      if (!steps.queue.ok) return { ok: false, reason: "virtual queue never cleared within 6 minutes", steps };

      steps.instructions = await acceptAccommodationInstructions();
      if (!steps.instructions.ok) return { ok: false, reason: steps.instructions.reason, steps };

      const isTicketHolderLocation = /exclusively for ticket holders/i.test(payload.location || "");

      steps.location = await selectAccommodationLocation(payload.location);
      if (!steps.location.ok) return { ok: false, reason: steps.location.reason, steps };
      await delay(500);

      if (isTicketHolderLocation) {
        steps.service = await selectAccommodationService(payload.service);
        if (!steps.service.ok) return { ok: false, reason: steps.service.reason, steps };
        await delay(500);

        steps.bookAccommodation = await clickEligibleBookAccommodationButton();
        if (!steps.bookAccommodation.ok) return { ok: false, reason: steps.bookAccommodation.reason, steps };
        // Lands back on Accommodation Details with Location pre-filled and
        // the calendar pre-restricted — nothing further to select here.
      }

      steps.slot = await selectAccommodationCheckInSlot(payload.checkInSlot);
      if (!steps.slot.ok) return { ok: false, reason: steps.slot.reason, steps };
      await delay(400);

      if (payload.noOfPilgrims) {
        const { plain } = collectFields();
        const byKey = bucketByKey(classifyList(plain));
        setPlainValue(byKey.noOfPilgrims?.[0], payload.noOfPilgrims);
      }

      steps.date = await selectAccommodationDate(payload.date);
      if (!steps.date.ok) return { ok: false, reason: steps.date.reason, steps };
      await delay(600);

      steps.room = await selectAccommodationRoomByPrice(payload.roomPrice);
      if (!steps.room.ok) return { ok: false, reason: steps.room.reason, steps };

      const continueAfterRoom = await waitForEnabledContinue(5000);
      if (!continueAfterRoom) return { ok: false, reason: "room selected, but Continue never enabled", steps };
      fireClickSequence(continueAfterRoom);
      await delay(600);

      steps.okayPopup = await confirmAccommodationOkayPopup();

      steps.pilgrimBoxes = await checkExactlyNPilgrimBoxes(payload.pilgrimSelectCount || 2);
      if (!steps.pilgrimBoxes.ok) return { ok: false, reason: steps.pilgrimBoxes.reason, steps };

      if (payload.contact) {
        const { plain, dropdownTriggers } = collectFields();
        const plainByKey = bucketByKey(classifyList(plain));
        const dropdownByKey = bucketByKey(classifyList(dropdownTriggers));
        steps.contact = await fillContact(payload.contact, plainByKey, dropdownByKey, false);
      }

      const continueAfterDetails = await waitForEnabledContinue(5000);
      if (!continueAfterDetails) return { ok: false, reason: "General Details filled, but Continue never enabled", steps };
      fireClickSequence(continueAfterDetails);
      await delay(600);

      // Hops through any review screen(s) between here and the Payment
      // page the same way every other multi-continue flow in this file
      // does, rather than assuming a fixed number of clicks.
      const hop = await clickThroughToPayNow();
      if (hop.button) {
        fireClickSequence(hop.button);
        await delay(600);
      } else if (!hop.atChooser) {
        return { ok: false, reason: "Continue clicked, but never reached the Payment page", steps };
      }

      if (payload.useCard && payload.card) {
        const cardOption = findPaymentOption(CARD_TEXTS);
        if (cardOption) {
          fireClickSequence(cardOption);
          await delay(600);
        }
        steps.card = await fillCardFields(payload.card);
      }

      steps.proceed = await window.__pilgrimCardProceed();
      return { ok: !!steps.proceed.ok, reason: steps.proceed.ok ? undefined : steps.proceed.reason, steps };
    } catch (err) {
      return { ok: false, error: (err && err.message) || String(err), steps };
    }
  };
})();



/* -------------------------------------------------------------------------
 * TTD server-time-synced booking click
 *
 * The user chooses the target IST time in the popup. 10:00:00 is the
 * default, but it is not hard-coded as the only possible target.
 * ------------------------------------------------------------------------- */
(() => {
  "use strict";

  // This IIFE is a separate closure from the main autofill code above
  // (which has its own, identically-named delay()) — nothing defined
  // there is visible in here. This was missing entirely: every call to
  // delay() inside this closure (the virtual-queue wait loop, the
  // readiness poll, the pre-Pay-Now pause) threw "delay is not defined"
  // the moment it was reached, aborting the whole workflow immediately
  // with that as the only status shown. That's also exactly why this
  // never surfaced until now — runPostReloadWorkflow() couldn't
  // previously get past its own marker-check bug (fixed in v2.6.1) to
  // ever reach a delay() call in the first place.
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  const TTD_HOST = "ttdevasthanams.ap.gov.in";
  const TIME_SYNC_KEY = "pilgrimAutofillData";
  const DEFAULT_TARGET = "10:00:00";
  const PRECHECK_SECONDS = 6;
  const DEFAULT_ONE_WAY_MS = 0;
  const MAX_OFFSET_MS = 5 * 60 * 1000;
  const RELOAD_MARKER = "__ttdTimeSyncReloadedFor";
  const SERVICE_RETRY_MARKER = "__ttdServiceReleaseRetry";
  const MAX_SERVICE_RELEASE_REFRESHES = 3;
  // The observed release-buffer window is short (<~1.5s). Use a bounded
  // retry delay, but let the DOM observer react immediately when the
  // announcement is actually present rather than waiting for a polling tick.
  const SERVICE_RELEASE_REFRESH_DELAY_MS = 180;
  const RELEASE_DOM_DEBOUNCE_MS = 35;

  let enabled = false;
  let targetTime = DEFAULT_TARGET;
  let action = "reload"; // reload | click
  let executed = false;
  let latencyChecked = false;
  let oneWayLatencyMs = DEFAULT_ONE_WAY_MS;
  let serverOffsetMs = 0;
  let timer = null;
  let targetEpochMs = null;

  if (location.hostname !== TTD_HOST) return;

  function isVisible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.display !== "none" &&
      st.visibility !== "hidden" && st.pointerEvents !== "none";
  }

  function text(el) {
    return (el?.innerText || el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function status(msg, error = false) {
    const id = "__ttdTimeSyncStatus";
    let box = document.getElementById(id);
    if (!box) {
      box = document.createElement("div");
      box.id = id;
      box.style.cssText =
        "position:fixed;z-index:2147483647;right:14px;bottom:14px;max-width:360px;" +
        "background:#1f2430;color:#fff;padding:10px 12px;border-radius:9px;" +
        "font:13px/1.35 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;" +
        "box-shadow:0 5px 18px rgba(0,0,0,.28);";
      document.documentElement.appendChild(box);
    }
    box.style.borderLeft = error ? "4px solid #ef4444" : "4px solid #22c55e";
    box.textContent = msg;
    clearTimeout(box.__timer);
    box.__timer = setTimeout(() => box.remove(), 8000);
  }

  function parseTarget(value) {
    const m = String(value || "").match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
    if (!m) return { h: 10, min: 0, sec: 0, text: DEFAULT_TARGET };
    const h = Number(m[1]), min = Number(m[2]), sec = Number(m[3] || 0);
    if (h > 23 || min > 59 || sec > 59) {
      return { h: 10, min: 0, sec: 0, text: DEFAULT_TARGET };
    }
    return {
      h, min, sec,
      text: `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
    };
  }

  function istParts(epochMs) {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Asia/Kolkata", hour12: false,
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit"
    }).formatToParts(new Date(epochMs));
    const out = {};
    for (const p of parts) if (p.type !== "literal") out[p.type] = Number(p.value);
    return out;
  }

  // "reload"/"workflow"/"click" all assume the user is already sitting on
  // the actual Darshan Slots calendar page they want reloaded/continued —
  // that's the whole point of those three modes (only "service-click" is
  // meant to be armed from the homepage, launching a service by name).
  // A loose OR-of-common-words check here is a false-positive trap: TTD's
  // own homepage says "Namaskaram Pilgrim", "Pilgrim Services", and lists
  // "Special Entry Darshan (Ammavari Temple)" as a tile — so "pilgrim",
  // "darshan", and "special entry" all appear on literally every TTD page,
  // making that check pass everywhere and defeating its own purpose. This
  // requires signals that only the real calendar/slot page actually has.
  function isLikelyBookingPage() {
    const url = location.href.toLowerCase();
    const body = text(document.body).toLowerCase();
    if (/slot-booking|pilgrim-details|flow=sed|flow=spat/.test(url)) return true;
    return /darshan slots|number of tickets|select any \d+ slot|slot time \d/.test(body);
  }

  function findBookingButton() {
    const selectors = ['a[href*="flow=sed"]','a[href*="slot-booking"]','button','[role="button"]','a'];
    const preferred = ["special entry", "special entry darshan", "book now", "booking", "continue"];
    for (const selector of selectors) {
      const nodes = [...document.querySelectorAll(selector)].filter(isVisible);
      for (const wanted of preferred) {
        const match = nodes.find(el => {
          const t = text(el).toLowerCase();
          return t === wanted || t.includes(wanted);
        });
        if (match) return match;
      }
    }
    return null;
  }

  async function measureServerTiming(force = false) {
    if (latencyChecked && !force) return;
    latencyChecked = true;

    // Low-latency sync:
    // Take several timing samples concurrently instead of waiting 120 ms
    // between them. We only keep the lowest-RTT sample, which minimizes the
    // effect of transient Wi-Fi/mobile jitter without intentionally sending
    // the booking request early.
    const sampleCount = 4;
    const samples = await Promise.all(Array.from({ length: sampleCount }, async () => {
      try {
        const startWall = Date.now();
        const startPerf = performance.now();
        const response = await fetch("https://" + TTD_HOST + "/", {
          method: "HEAD",
          cache: "no-store",
          credentials: "include",
          keepalive: true
        });
        const endPerf = performance.now();
        const endWall = Date.now();
        const rtt = endPerf - startPerf;
        const serverDate = response.headers.get("date");
        if (!serverDate) return null;

        const serverMs = Date.parse(serverDate);
        if (!Number.isFinite(serverMs)) return null;

        return {
          rtt,
          offset: (serverMs + 500) - ((startWall + endWall) / 2)
        };
      } catch (err) {
        console.warn("[TTD Sync] server-time sample failed", err);
        return null;
      }
    }));

    const best = samples.filter(Boolean).reduce(
      (winner, sample) => !winner || sample.rtt < winner.rtt ? sample : winner,
      null
    );

    if (!best) {
      console.warn("[TTD Sync] no usable Date header; falling back to device clock");
      status("[TTD Sync] TTD server time unavailable; using device time.", true);
      return;
    }

    // HTTP Date is only second-resolution. Center it at :00.500 and use the
    // request midpoint for the offset. Never subtract one-way latency from
    // the scheduled click: doing so would deliberately fire before the
    // estimated server-time boundary.
    oneWayLatencyMs = 0;
    serverOffsetMs = Math.max(-MAX_OFFSET_MS, Math.min(MAX_OFFSET_MS, best.offset));
    status(`[TTD Sync] Low-latency sync • server offset ${serverOffsetMs >= 0 ? "+" : ""}${serverOffsetMs.toFixed(0)} ms • RTT ${best.rtt.toFixed(0)} ms`);
    console.log("[TTD Sync]", { rtt: best.rtt, oneWayLatencyMs, serverOffsetMs, targetTime, action });

    // Warm the same origin's HTTP connection. This is only a connection
    // warm-up; it does not submit a booking or bypass any server-side queue,
    // rate limit, or release rule.
    warmTTDConnection();
  }

  let ttdWarmupPromise = null;
  function warmTTDConnection() {
    if (ttdWarmupPromise) return ttdWarmupPromise;
    ttdWarmupPromise = fetch("https://" + TTD_HOST + "/", {
      method: "HEAD",
      cache: "no-store",
      credentials: "include",
      keepalive: true
    }).catch(() => null).finally(() => {
      // Allow another warm-up later if the connection is dropped.
      ttdWarmupPromise = null;
    });
    return ttdWarmupPromise;
  }

  let pinnedTargetDate = null; // {year, month, day} in IST — see computeTargetEpoch

  function computeTargetEpoch(nowMs) {
    const t = parseTarget(targetTime);
    // Decide which IST calendar day the target falls on ONLY ONCE per arm
    // cycle, then reuse it. Re-deriving the day fresh from "now" on every
    // call (as this used to do) is dangerous: computeTargetEpoch gets
    // called again after each of the two re-measurements schedule() does
    // in the final seconds before firing, and each measureServerTiming()
    // call is a real awaited fetch that costs genuine wall-clock time. If
    // that push happens to land "now" fractionally past today's target
    // instant — even by a few hundred ms, well before the real release
    // moment if serverOffsetMs was refined at the same time — the
    // `target <= nowMs` guard below reads that as "today's slot already
    // passed" and rolls the target a full 24 HOURS forward. That silently
    // disarms the rest of the countdown for the whole day: remaining stays
    // enormous, schedule() just keeps re-polling every ~250ms forever, and
    // nothing ever fires — no error, no click, no reload. A screen
    // recording showed exactly this: two re-measurements land in the
    // final ~2.5s stretch, the status bubble goes quiet right after the
    // second one, and the action never runs. Pinning the day once removes
    // the chance for a measurement's own latency to flip it.
    if (!pinnedTargetDate) {
      const p = istParts(nowMs + serverOffsetMs);
      const provisional = Date.UTC(p.year, p.month - 1, p.day, t.h, t.min, t.sec) - (5 * 60 + 30) * 60 * 1000 - serverOffsetMs;
      if (provisional <= nowMs) {
        const nextUtcMidnight = new Date(Date.UTC(p.year, p.month - 1, p.day + 1));
        pinnedTargetDate = { year: nextUtcMidnight.getUTCFullYear(), month: nextUtcMidnight.getUTCMonth() + 1, day: nextUtcMidnight.getUTCDate() };
      } else {
        pinnedTargetDate = { year: p.year, month: p.month, day: p.day };
      }
    }
    const utcForIst = Date.UTC(pinnedTargetDate.year, pinnedTargetDate.month - 1, pinnedTargetDate.day, t.h, t.min, t.sec);
    const istAsUtc = utcForIst - (5 * 60 + 30) * 60 * 1000;
    return istAsUtc - serverOffsetMs;
  }

  // The virtual queue page TTD shows under high load ("You've been placed
  // in a virtual queue due to exceptionally high demand", with its own
  // countdown that clears and redirects on its own — no button to click).
  // Matched on wording rather than any class name since this is a
  // transient interstitial the site can restyle independently of the
  // booking page itself.
  function isVirtualQueuePage() {
    const body = (document.body?.innerText || "").toLowerCase();
    return body.includes("virtual queue") || (body.includes("placed in a queue") && body.includes("high demand"));
  }

  function findReleaseNoticeElement() {
    const nodes = [...document.querySelectorAll("body *")].filter(isVisible);
    let best = null;
    let bestLen = Infinity;
    for (const el of nodes) {
      const t = text(el).toLowerCase();
      if (!t || t.length > 1200) continue;
      const matchesReleasedAt =
        t.includes("will be released at") &&
        (t.includes("online quota") || t.includes("quota of") || t.includes("released at"));
      // Confirmed against a real recording of TTD's actual pre-release
      // "curtain" page (URL contains "curtain?section=..."): its wording
      // is NOT "will be released at" at all — it reads "...tickets for
      // <month> ... will be available for booking w.e.f. <date>, <time>".
      // The check above alone would never match that page, so the
      // refresh-until-it-disappears behavior would silently never kick in
      // for it. Matched as a second, independent pattern here.
      const matchesAvailableForBooking = t.includes("available for booking") && t.includes("w.e.f");
      if (!matchesReleasedAt && !matchesAvailableForBooking) continue;
      // Prefer the smallest visible ancestor that still contains the complete
      // announcement. This avoids treating the entire page/body as the banner.
      if (t.length < bestLen) {
        best = el;
        bestLen = t.length;
      }
    }
    return best;
  }

  function isReleaseNoticePage() {
    return !!findReleaseNoticeElement();
  }

  // TTD displays a short 10→0 countdown during the release/transition
  // sequence. The bell is an audio cue, but audio timing is not reliable
  // enough to drive automation. We use the visible DOM countdown instead.
  function findReleaseCountdown() {
    const nodes = [...document.querySelectorAll("body *")].filter(isVisible);
    let best = null;
    let bestLen = Infinity;
    for (const el of nodes) {
      const t = text(el).toLowerCase();
      if (!t || t.length > 300) continue;
      // Accept common countdown renderings: 00:10, 0:10, 10 sec,
      // or a standalone 10..0 value inside a countdown-like element.
      const hasCountdownWord = /count.?down|seconds?|queue|release|wait/.test(t);
      const m = t.match(/(?:^|\s)(?:0?:)?([0-9]|10)(?:\s*(?:sec|secs|seconds))?(?:\s|$)/);
      const clock = t.match(/(?:^|\s)(?:00?:)?([0-9]|10)(?::[0-5]\d)?(?:\s|$)/);
      if ((hasCountdownWord && (m || clock)) || /^(?:10|9|8|7|6|5|4|3|2|1|0)$/.test(t)) {
        if (t.length < bestLen) { best = el; bestLen = t.length; }
      }
    }
    return best;
  }

  function getReleaseCountdownValue() {
    const el = findReleaseCountdown();
    if (!el) return null;
    const t = text(el).toLowerCase();
    const mm = t.match(/(?:00?:)?([0-9]|10)(?::[0-5]\d)?/);
    if (!mm) return null;
    const n = Number(mm[1]);
    return Number.isFinite(n) && n >= 0 && n <= 10 ? n : null;
  }

  function serviceRetryKey() {
    const p = istParts(Date.now() + serverOffsetMs);
    return `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}|${savedServiceName.trim().toLowerCase()}`;
  }

  function monitorServiceReleaseTransition() {
    if (action !== "service-click" || !enabled) return;

    const deadline = Date.now() + 20000;
    let observer = null;
    let refreshTimer = null;
    let debounceTimer = null;
    let stopped = false;

    const stop = () => {
      stopped = true;
      if (observer) observer.disconnect();
      if (refreshTimer) clearTimeout(refreshTimer);
      if (debounceTimer) clearTimeout(debounceTimer);
    };

    const stateKey = () => serviceRetryKey();

    const readState = () => {
      try {
        const s = JSON.parse(sessionStorage.getItem(SERVICE_RETRY_MARKER) || "null");
        if (s && s.key === stateKey()) return s;
      } catch (_) {}
      return { key: stateKey(), count: 0 };
    };

    const saveState = (state) => {
      try { sessionStorage.setItem(SERVICE_RETRY_MARKER, JSON.stringify(state)); } catch (_) {}
    };

    const evaluate = () => {
      if (stopped || !enabled || Date.now() > deadline) {
        stop();
        return;
      }

      // During TTD's 10→0 release countdown, do not refresh. The countdown
      // (and its bell/audio cue) is already the site's own release mechanism;
      // refreshing during it can restart the transition and cost time.
      const countdown = getReleaseCountdownValue();
      if (countdown !== null && countdown >= 0 && countdown <= 10) {
        status(`[TTD Sync] TTD release countdown: ${countdown} — no refresh`);
        return;
      }

      // DOM-first detection: React/Next.js can replace the announcement
      // without a navigation. We therefore inspect the actual visible
      // announcement element rather than relying on a body-text poll.
      const banner = findReleaseNoticeElement();
      if (banner) {
        const state = readState();
        if (state.count >= MAX_SERVICE_RELEASE_REFRESHES) {
          stop();
          status(`[TTD Sync] Release notice remains after ${MAX_SERVICE_RELEASE_REFRESHES} refreshes — stopping automatic refresh.`, true);
          return;
        }
        state.count += 1;
        saveState(state);
        status(`[TTD Sync] Release notice detected — refresh ${state.count}/${MAX_SERVICE_RELEASE_REFRESHES}…`);
        refreshTimer = setTimeout(() => {
          if (!stopped) window.location.reload();
        }, SERVICE_RELEASE_REFRESH_DELAY_MS);
        return;
      }

      if (isVirtualQueuePage()) {
        try { sessionStorage.removeItem(SERVICE_RETRY_MARKER); } catch (_) {}
        stop();
        status(`[TTD Sync] ${savedServiceName || "Service"} entered TTD's virtual queue — waiting…`);
        // The queue clears and redirects on its own (this page stays put
        // until then) — runPostReloadWorkflow()'s own queue-wait loop
        // picks up from exactly here and continues into date/slot/ticket
        // selection + Pilgrim Details + Pay Now once it does, instead of
        // this just being a status message with nothing after it.
        runPostReloadWorkflow();
        return;
      }

      // The announcement disappearing is itself a useful transition signal.
      // Do not refresh again. TTD now owns the loader/queue transition —
      // hand off to the same post-arrival workflow "reload + workflow"
      // mode uses (its own readiness poll tolerates landing straight on
      // the real booking page with no queue at all, too).
      stop();
      status(`[TTD Sync] Release announcement disappeared — TTD is transitioning to loading/queue. No refresh.`);
      runPostReloadWorkflow();
    };

    // React/Next.js DOM changes are observed immediately. This is the primary
    // detector for the short release window; the fallback timer handles cases
    // where the site changes state without a MutationObserver mutation.
    observer = new MutationObserver(() => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(evaluate, RELEASE_DOM_DEBOUNCE_MS);
    });
    try {
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["class", "style", "hidden", "aria-hidden"]
      });
    } catch (_) {}

    evaluate();

    const fallback = () => {
      if (stopped) return;
      evaluate();
      if (!stopped) setTimeout(fallback, 150);
    };
    setTimeout(fallback, 150);
  }

  async function recoverServiceReleaseAfterReload() {
    if (action !== "service-click" || !enabled) return false;

    let state = null;
    try {
      state = JSON.parse(sessionStorage.getItem(SERVICE_RETRY_MARKER) || "null");
    } catch (_) {}
    if (!state || state.key !== serviceRetryKey()) return false;

    // If the site's 10→0 countdown is visible, leave the page completely
    // untouched. Never restart TTD's own countdown/queue transition.
    const countdown = getReleaseCountdownValue();
    if (countdown !== null && countdown >= 0 && countdown <= 10) {
      executed = true;
      status(`[TTD Sync] TTD release countdown: ${countdown} — waiting without refresh`);
      return true;
    }

    // Once the release notice disappears, TTD is free to show its loader /
    // virtual queue. From this point onward DO NOT refresh again.
    if (!isReleaseNoticePage()) {
      try { sessionStorage.removeItem(SERVICE_RETRY_MARKER); } catch (_) {}
      executed = true;
      if (isVirtualQueuePage()) {
        status(`[TTD Sync] ${savedServiceName || "Service"} entered TTD's virtual queue — waiting…`);
      } else {
        status(`[TTD Sync] Release page cleared — waiting for TTD to finish loading…`);
      }
      // Give the SPA a little time to transition, then hand off to the
      // same post-arrival workflow "reload + workflow" mode uses —
      // runPostReloadWorkflow() has its own queue-wait loop (so this is
      // safe to call even while still queued) and its own readiness poll
      // for the real booking page, then does date/slot/ticket selection,
      // Pilgrim Details, and stops at Pay Now. Never reload from here.
      setTimeout(runPostReloadWorkflow, 400);
      return true;
    }

    if ((state.count || 0) >= MAX_SERVICE_RELEASE_REFRESHES) {
      executed = true;
      status(`[TTD Sync] Release notice is still showing after ${MAX_SERVICE_RELEASE_REFRESHES} refreshes. Leaving TTD untouched so you can refresh manually.`, true);
      return true;
    }

    state.count = (state.count || 0) + 1;
    try { sessionStorage.setItem(SERVICE_RETRY_MARKER, JSON.stringify(state)); } catch (_) {}
    executed = true;
    status(`[TTD Sync] Release notice still showing — refresh ${state.count}/${MAX_SERVICE_RELEASE_REFRESHES}…`);
    setTimeout(() => window.location.reload(), SERVICE_RELEASE_REFRESH_DELAY_MS);
    return true;
  }

  async function runPostReloadWorkflow() {
    try {
      const res = await chrome.storage.local.get(TIME_SYNC_KEY);
      const saved = res?.[TIME_SYNC_KEY] || {};
      if (!saved.timeSyncBooking || !["workflow", "service-click"].includes(saved.timeSyncAction)) return;
      if (!isLikelyBookingPage()) {
        status(
          "[TTD Sync] Reloaded, but landed somewhere that isn't the Darshan Slots calendar page — nothing more to do from here. If TTD redirected you elsewhere (e.g. back to the homepage), re-open the actual booking page and arm workflow mode again from there.",
          true
        );
        try { sessionStorage.removeItem("__ttdTimeSyncWorkflowFor"); } catch (_) {}
        return;
      }
      // Check the "is this attempt actually still the one that was armed"
      // marker BEFORE removing it — checking after removing it (as this
      // used to) means the read always sees the value that was just
      // deleted, so the comparison below could never pass: this entire
      // function was an unconditional no-op on every single call,
      // including from the original "reload + workflow" mode's own
      // setTimeout hookup, not just the new service-click hand-off. From
      // the outside that looked exactly like the workflow silently
      // stopping right after the reload, every time.
      const p = istParts(Date.now() + serverOffsetMs);
      const targetKey = `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
      let armedKey = null;
      try { armedKey = sessionStorage.getItem("__ttdTimeSyncWorkflowFor"); } catch (_) {}
      if (armedKey !== targetKey) return;

      // Now commit to this one attempt (success or failure) — clear the
      // marker so a failed run doesn't leave a stale "still armed" flag
      // that could confuse a later, unrelated page load in this same tab.
      try { sessionStorage.removeItem("__ttdTimeSyncWorkflowFor"); } catch (_) {}

      // Wait for TTD's calendar/app shell to finish rendering. Mobile TTD
      // pages can take several seconds after a reload, especially around
      // the opening-time traffic spike — and during genuinely high demand,
      // TTD interposes its own virtual-queue interstitial first, which
      // clears and redirects on its own after anywhere from ~30s to a few
      // minutes. That queue page is an expected, normal part of the flow
      // during a release rush, not a failure — so it gets its own,
      // separately-budgeted wait rather than eating into (or tripping)
      // the shorter "page just didn't load" timeout below. Nothing is
      // clicked or filled while queued; the page redirects on its own.
      let sawQueue = false;
      let ready = false;
      const queueDeadline = Date.now() + 6 * 60 * 1000; // TTD virtual queue hard maximum: 6 minutes
      // Polled at 350ms rather than a flatter 1s — TTD releases people from
      // the queue at unpredictable, per-person moments ("varies from user
      // to user"), and with tickets gone in seconds once freed, every
      // extra poll interval here is pure reaction-time lost off the front
      // of the race. 350ms keeps CPU/DOM cost negligible while cutting
      // worst-case reaction lag by roughly two-thirds versus the old 1s.
      while (Date.now() < queueDeadline) {
        if (isVirtualQueuePage()) {
          if (!sawQueue) {
            sawQueue = true;
            status("[TTD Sync] In TTD's virtual queue (high demand) — waiting for it to clear…");
            try { Promise.resolve(chrome.runtime.sendMessage({ type: "PILGRIM_QUEUE_STATUS", state: "queued" })).catch(() => {}); } catch (_) {}
          }
          await delay(350);
          continue;
        }
        if (sawQueue) {
          status("[TTD Sync] Queue cleared — waiting for the booking page…");
          try { Promise.resolve(chrome.runtime.sendMessage({ type: "PILGRIM_QUEUE_STATUS", state: "cleared" })).catch(() => {}); } catch (_) {}
        }
        break;
      }

      const readyDeadline = Date.now() + (sawQueue ? 20000 : 15000);
      while (Date.now() < readyDeadline) {
        if (isVirtualQueuePage()) {
          // Some TTD queue implementations re-queue once or twice before
          // finally releasing under sustained load — fold back into the
          // queue wait rather than burning the short ready-timeout on it.
          if (!sawQueue) {
            try { Promise.resolve(chrome.runtime.sendMessage({ type: "PILGRIM_QUEUE_STATUS", state: "queued" })).catch(() => {}); } catch (_) {}
          }
          sawQueue = true;
          status("[TTD Sync] Back in queue — still waiting…");
          await delay(350);
          continue;
        }
        if (window.__pilgrimAutofillRun && isLikelyBookingPage()) {
          const body = (document.body?.innerText || "").toLowerCase();
          const hasCalendar = /darshan slots|number of tickets|slot time \d/.test(body);
          const hasPilgrimForm = !!document.querySelector('input[label="Name"], input[name="name"], input[placeholder="Name"]');
          if (hasCalendar || hasPilgrimForm) {
            ready = true;
            break;
          }
        }
        // Same reasoning as the queue poll above — the calendar/pilgrim
        // form can finish rendering at any point in this window, and
        // __pilgrimAutofillRun should fire the instant it does.
        await delay(300);
      }
      if (!ready) {
        status("[TTD Sync] Booking page did not finish loading after the server-time reload.", true);
        return;
      }

      // Pull from whichever service's own saved fields match what was
      // actually scheduled — "reload + workflow" mode (armed from the
      // Sri PAT tab, historically the only one) can keep defaulting to
      // the plain pilgrims/dateSlot fields, but service-click mode is now
      // driven by the service dropdown, and each service tab (Sri PAT,
      // Special Entry Darshan, Angapradakshinam) keeps its own separate
      // pilgrim list and date/slot/ticket-count — using the wrong one
      // would silently fill in the wrong pilgrims (or none) for whichever
      // service isn't Sri PAT.
      const info = SERVICE_INFO[savedServiceKey];
      const pilgrimsKey = info?.pilgrimsKey || "pilgrims";
      const dateSlotKey = info?.dateSlotKey || "dateSlot";
      if (savedServiceKey && !info?.pilgrimsKey) {
        status(`[TTD Sync] ${SERVICE_INFO[savedServiceKey]?.label || "This service"} has no date/slot + pilgrim workflow configured yet — you're on the real page now, continue manually from here.`);
        return;
      }

      const payload = {
        pilgrims: Array.isArray(saved[pilgrimsKey]) ? saved[pilgrimsKey] : [],
        contact: saved.contact || {},
        dateSlot: saved[dateSlotKey] || {}
      };

      if (!payload.pilgrims.length || !payload.dateSlot?.date) {
        status("[TTD Sync] Workflow needs a saved Darshan date and at least one pilgrim.", true);
        return;
      }

      status("[TTD Sync] Selecting date, ticket count and slot…");
      const filled = await window.__pilgrimAutofillRun(payload);
      if (filled?.error) {
        status(`[TTD Sync] Workflow error: ${filled.error}`, true);
        return;
      }
      if ((filled?.filledCount || 0) <= 0) {
        status(`[TTD Sync] No pilgrim fields were filled${filled?.missed?.length ? `: ${filled.missed.join("; ")}` : ""}.`, true);
        return;
      }
      if (filled?.missed?.some((x) => String(x).startsWith("date/slot:"))) {
        status(`[TTD Sync] Date/slot step failed: ${filled.missed.join("; ")}`, true);
        return;
      }
      if (filled?.missed?.length) {
        status(`[TTD Sync] Some optional fields were not matched: ${filled.missed.join("; ")}`);
      }

      // __pilgrimAutofillRun already pressed Continue from the calendar
      // and left us on Pilgrim Details, filled in but not yet submitted.
      // What happens next depends on which auto-continue toggle (if any)
      // is on — this used to always just press Continue once more and
      // stop at Pay Now, even when card autofill was enabled, which
      // meant reaching the review screen through the scheduler never
      // went any further: no card fill, no Proceed, regardless of what
      // the popup's own toggles said.
      if (saved.cardAutofill) {
        // The card path crosses a full-page redirect ("Redirecting to
        // payment gateway…"), which reliably closes any open popup —
        // exactly why background.js exists as a resilient,
        // popup-independent state machine instead of one long function
        // here (see its own header comment). A content script can
        // message it directly; background.js fills in this tab's id
        // from the sender since a scheduled run has no popup open to
        // have supplied one. Its first step ("click_continue") is
        // exactly the Continue press Pilgrim Details is waiting on, so
        // nothing here should click it first.
        status("[TTD Sync] Pilgrim Details filled — handing off to the card payment flow…");
        try { sessionStorage.removeItem("__ttdTimeSyncWorkflowFor"); } catch (_) {}
        Promise.resolve(chrome.runtime.sendMessage({
          type: "PILGRIM_START_AUTO_PAY",
          useCard: true,
          card: saved.card || null,
          // Same shape the popup sends, so later steps can re-fill any field the
          // site clears between screens.
          payload: { pilgrims: payload.pilgrims, contact: payload.contact, dateSlot: null, dryRun: false }
        })).catch(() => {});
        return;
      }

      if (saved.autoPay) {
        // Same reasoning as the card branch, minus the cross-page
        // redirect concern — PhonePe hand-off is the last step either
        // way, so this can run entirely in-page. Also does its own
        // initial Continue click, same as the card path above.
        const payRes = await window.__pilgrimAutoContinuePay?.({ useCard: false });
        if (!payRes?.ok) {
          status(`[TTD Sync] Details filled, but continuing to payment failed: ${payRes?.reason || "Continue/Pay Now not found"}`, true);
          return;
        }
        status("[TTD Sync] Continued through to Pay Now.");
        try { sessionStorage.removeItem("__ttdTimeSyncWorkflowFor"); } catch (_) {}
        return;
      }

      // Neither auto-continue toggle is on — press Continue once more
      // and stop right at Pay Now, same as this has always done.
      const continueRes = await window.__pilgrimClickContinue?.();
      if (!continueRes?.ok) {
        status(`[TTD Sync] Details filled, but Continue was not found: ${continueRes?.reason || "unknown"}`, true);
        return;
      }

      await delay(500);
      // window.__pilgrimFindReviewPayButton (not the bare
      // clickThroughToPayNow() — that function lives in the OTHER
      // content-script closure and throws "not defined" if called
      // directly from here, the same class of bug delay() itself had)
      // locates Pay Now without clicking it, matching this path's whole
      // point: leaving the final tap for the person.
      const reviewRes = await window.__pilgrimFindReviewPayButton?.();
      if (reviewRes?.ok) {
        status(
          reviewRes.arrived
            ? "[TTD Sync] Booking details are ready. The payment page is up — pick a method and pay when you're ready."
            : "[TTD Sync] Booking details are ready. Pay Now is waiting for your confirmation."
        );
        try { sessionStorage.removeItem("__ttdTimeSyncWorkflowFor"); } catch (_) {}
      } else {
        status(`[TTD Sync] Details were filled, but Pay Now wasn't found yet: ${reviewRes?.reason || "unknown"}`, true);
      }
    } catch (err) {
      status(`[TTD Sync] Workflow failed: ${(err && err.message) || String(err)}`, true);
    }
  }


  let savedServiceName = "";
  let savedServiceKey = "";

  // Canonical service list for the popup's dropdown (mirrored in
  // popup.js's SERVICE_OPTIONS). Every path here is cross-checked against
  // two independent sources: a capture of TTD's own CMS navigation
  // payload (cms/api/universal-sub-headers) and a live HAR of an actual
  // successful booking session — both agree. Preferred over hunting for a
  // tile to click: TTD's service tiles are plain divs with a click
  // handler (no <a href>, no <button>), so text-matching them is fragile
  // by nature; a known-good URL sidesteps that matching entirely.
  // pilgrimsKey/dateSlotKey point at the matching state fields in
  // popup.js's storage object, when this service has a booking tab wired
  // up for full date/slot/ticket + pilgrim-details automation — for the
  // two that don't yet (Srivari Seva is a one-time personal-profile
  // application with no per-visit date/slot concept in this extension
  // yet; the Homam falls under the general Arjitha Seva booking flow,
  // which also isn't wired up yet), the scheduler still opens the page,
  // waits out the queue, and clears the release banner — it just stops
  // there rather than guessing at fields it has nothing saved for.
  const SERVICE_INFO = {
    spat: {
      label: "Special Entry Darshan (Ammavari Temple)",
      path: "/spat/slot-booking?flow=spat&flowIdentifier=spat",
      pilgrimsKey: "pilgrims",
      dateSlotKey: "dateSlot"
    },
    sed: {
      label: "Special Entry Darshan",
      path: "/slot-booking?flow=sed&flowIdentifier=sed",
      pilgrimsKey: "sedPilgrims",
      dateSlotKey: "sedDateSlot"
    },
    apd: {
      label: "Angapradakshinam",
      path: "/apd/slot-booking?flow=apd&flowIdentifier=apd",
      pilgrimsKey: "angPilgrims",
      dateSlotKey: "angDateSlot"
    },
    "srivari-seva": {
      label: "Srivari Seva",
      path: "/srivari-seva/instructions"
    },
    homam: {
      label: "Sri Srinivasa Divyanugraha Homam",
      path: "/arjitha-seva/slot-booking?section=pilgrim-details&flowIdentifier=arjitha-seva&templeName=Sapthagiri Gau Pradakshina Shala&sevaName=Sri Srinivasa Divyaanugraha Homam",
      pilgrimsKey: "sriPilgrims",
      dateSlotKey: "dateSlot"
    }
  };

  // Kept for the free-typed "Custom" fallback in the popup (any service
  // not in the dropdown above) — same lookup as before, by normalized
  // visible text rather than a canonical key.
  const SERVICE_PATHS = Object.fromEntries(
    Object.values(SERVICE_INFO).map((v) => [v.label.toLowerCase(), v.path])
  );
  SERVICE_PATHS["special entry darshan sri pat"] = SERVICE_INFO.spat.path;
  SERVICE_PATHS["special entry darshan ammavari temple"] = SERVICE_INFO.spat.path;

  function findKnownServicePath(serviceName) {
    const norm = s => String(s || "").replace(/[()]/g, " ").replace(/[./]/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
    const wanted = norm(serviceName);
    if (!wanted) return null;
    if (SERVICE_PATHS[wanted]) return SERVICE_PATHS[wanted];
    // Loose containment match either direction, e.g. "special entry
    // darshan ammavari" (missing "temple") should still hit the Sri PAT
    // entry above.
    for (const [key, path] of Object.entries(SERVICE_PATHS)) {
      if (wanted.includes(key) || key.includes(wanted)) return path;
    }
    return null;
  }

  function findServiceLaunchButton(serviceName) {
    // Strip parentheses before comparing — TTD's own tile text wraps the
    // temple name in them ("Special Entry Darshan (Ammavari Temple)"), but
    // it's easy to type the plain words without them, which used to make
    // this match fail silently (a missing "(" breaks a substring match
    // even though every actual word is right).
    const norm = s => String(s || "").replace(/[()]/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
    const wanted = norm(serviceName);
    if (!wanted) return null;

    // TTD's home-page service tiles (the "Pilgrim Services" grid) are
    // plain, unstyled-semantically <div>s with a click handler — not
    // <button>/<a>/[role=button] — confirmed against the site's own
    // bundled page component. The original selector here only looked at
    // semantic clickable elements, so it could never find a tile-based
    // service at all; this only ever worked for services that happened to
    // render as a real link/button elsewhere on the page. Broadened to
    // include divs, but scoped tightly (short own text, few children) so
    // it can't accidentally match a large wrapping container whose
    // innerText happens to include the wanted words as a substring.
    const candidates = [
      ...document.querySelectorAll(
        "button, a, [role='button'], input[type='button'], input[type='submit'], div, span, li"
      )
    ].filter(el => {
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return false;
      if (el.children.length > 4) return false;
      const t = text(el);
      return t.length > 0 && t.length <= 60;
    });

    // Prefer exact-ish visible text, then containing text. A tile's own
    // text is usually just its label (e.g. "Special Entry Darshan
    // (Ammavari Temple)"), so exact/near-exact match is tried first and is
    // the common case; "includes" is the fallback for icon+label wrappers.
    const exact = candidates.find(el => norm(text(el)) === wanted);
    if (exact) return exact;
    return candidates.find(el => norm(text(el)).includes(wanted)) || null;
  }

  function triggerAction() {
    if (executed) return;

    if (action === "reload" || action === "workflow") {
      const p = istParts(Date.now() + serverOffsetMs);
      const targetKey = `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
      try {
        if (sessionStorage.getItem(RELOAD_MARKER) === targetKey) {
          executed = true;
          if (action === "workflow") runPostReloadWorkflow();
          else status(`[TTD Sync] Page already loaded for ${targetTime} IST.`);
          return;
        }
        sessionStorage.setItem(RELOAD_MARKER, targetKey);
        if (action === "workflow") sessionStorage.setItem("__ttdTimeSyncWorkflowFor", targetKey);
      } catch (_) {}

      executed = true;
      status(`[TTD Sync] TTD server reached ${targetTime} IST. Loading page…`);
      console.log("[TTD Sync] SERVER-TIME RELOAD", { targetTime, serverOffsetMs, oneWayLatencyMs, workflow: action === "workflow" });
      window.location.reload();
      return;
    }

    const serviceText = (savedServiceName || "").trim();
    const knownInfo = savedServiceKey && savedServiceKey !== "custom" ? SERVICE_INFO[savedServiceKey] : null;

    // A service chosen from the dropdown (not the free-typed "Custom"
    // fallback) has a confirmed real URL — go straight there instead of
    // hunting for its tile on screen at all. This is both more reliable
    // (no dependency on the tile having rendered, not being covered by a
    // banner/ad, wording matching exactly, etc.) and is literally what
    // was asked for: open the selected service's page at the synced
    // time, not necessarily click through the home page's own UI to get
    // there.
    if (knownInfo) {
      executed = true;
      try {
        sessionStorage.setItem(RELOAD_MARKER, `nav|${savedServiceKey}`);
        if (action === "service-click") {
          const p = istParts(Date.now() + serverOffsetMs);
          const targetKey = `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
          sessionStorage.setItem("__ttdTimeSyncWorkflowFor", targetKey);
          // Same marker monitorServiceReleaseTransition()'s in-page path
          // sets on a real click — needed here too so that once we land
          // on the destination page, loadSetting() recognizes this as a
          // pending service-release attempt and calls
          // recoverServiceReleaseAfterReload() (which watches for TTD's
          // "not yet open"/release-countdown banner and refreshes through
          // it, then hands off into the same autofill continuation
          // workflow mode uses) instead of just sitting there.
          sessionStorage.setItem(SERVICE_RETRY_MARKER, JSON.stringify({ key: serviceRetryKey(), count: 0 }));
        }
      } catch (_) {}
      status(`[TTD Sync] TTD server reached ${targetTime} IST. Opening ${knownInfo.label}…`);
      console.log("[TTD Sync] SERVICE NAVIGATE", { savedServiceKey, path: knownInfo.path, at: new Date().toISOString() });
      window.location.href = `https://${TTD_HOST}${knownInfo.path}`;
      return;
    }

    const btn = serviceText ? findServiceLaunchButton(serviceText) : findBookingButton();
    if (!btn) {
      // Clicking the real tile (preferred — see findServiceLaunchButton)
      // keeps this a same-page SPA transition, which is what lets
      // monitorServiceReleaseTransition() below keep watching for TTD's
      // release-announcement banner without a reload wiping it out. Only
      // fall back to a hard navigation, which loses that in-page
      // watching, when the tile genuinely can't be found at all — still
      // better than doing nothing.
      const knownPath = serviceText ? findKnownServicePath(serviceText) : null;
      if (knownPath) {
        executed = true;
        try {
          sessionStorage.setItem(RELOAD_MARKER, `nav|${serviceText}`);
          if (action === "service-click") {
            const p = istParts(Date.now() + serverOffsetMs);
            const targetKey = `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
            sessionStorage.setItem("__ttdTimeSyncWorkflowFor", targetKey);
          }
        } catch (_) {}
        status(`[TTD Sync] "${serviceText}" tile wasn't found on screen — opening its booking page directly instead…`);
        console.log("[TTD Sync] FALLBACK NAVIGATE", { serviceText, knownPath, at: new Date().toISOString() });
        window.location.href = `https://${TTD_HOST}${knownPath}`;
        return;
      }
      status(`[TTD Sync] ${targetTime} IST reached, but ${serviceText ? `"${serviceText}"` : "the booking button"} was not found.`, true);
      return;
    }
    executed = true;
    if (action === "service-click") {
      try {
        sessionStorage.setItem(SERVICE_RETRY_MARKER, JSON.stringify({
          key: serviceRetryKey(),
          count: 0
        }));
        // Without this, clearing the queue/release-banner and landing on
        // the real booking page did nothing further — the person had to
        // notice it themselves and tap Fill All Details by hand.
        // Workflow mode already has this exact continuation (date/slot/
        // ticket selection → Continue → Pilgrim Details → Continue → Pay
        // Now); arming the same marker here lets service-click's
        // post-queue/post-banner code below hand off into it too, instead
        // of only ever showing a "waiting…" status with nothing after it.
        const p = istParts(Date.now() + serverOffsetMs);
        const targetKey = `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
        sessionStorage.setItem("__ttdTimeSyncWorkflowFor", targetKey);
      } catch (_) {}
    }
    btn.scrollIntoView({ block: "center", inline: "center" });
    try { btn.focus?.({ preventScroll: true }); } catch (_) {}
    // Bare fireClickSequence(btn) is the OTHER content-script closure's
    // function and isn't visible here — same class of bug delay() and
    // clickThroughToPayNow had (see comments on those). Use the
    // window-exposed copy instead.
    window.__pilgrimFireClickSequence?.(btn);
    status(`[TTD Sync] Click executed for ${serviceText || "booking"} at ${targetTime} IST. Watching for TTD's release/queue transition…`);
    console.log("[TTD Sync] CLICK EXECUTED", { serviceText, at: new Date().toISOString() });
    if (action === "service-click") monitorServiceReleaseTransition();
  }

  let warnedNotOnBookingPage = false;

  function schedule() {
    clearTimeout(timer);
    if (!enabled || executed) return;
    if (action !== "service-click" && !isLikelyBookingPage()) {
      if (!warnedNotOnBookingPage) {
        warnedNotOnBookingPage = true;
        status(
          `[TTD Sync] Armed for ${targetTime} IST, but this doesn't look like the Darshan Slots booking page yet — ${
            action === "click" ? "\"Click booking button\"" : action === "workflow" ? "\"Reload + select date/slot + fill pilgrim details\"" : "\"Reload / load current TTD page\""
          } needs you to navigate to the actual booking page first (open the service, then arm it there). Nothing will happen from here.`,
          true
        );
      }
      return;
    }
    warnedNotOnBookingPage = false;
    if (action === "service-click" && location.hostname !== TTD_HOST) return;

    const now = Date.now();
    targetEpochMs = computeTargetEpoch(now);
    const precheckAt = targetEpochMs - PRECHECK_SECONDS * 1000;
    const delay = now < precheckAt ? Math.min(precheckAt - now, 1000) : 0;

    timer = setTimeout(async () => {
      if (!enabled || executed) return;

      if (Date.now() >= precheckAt && !latencyChecked) {
        await measureServerTiming();
        targetEpochMs = computeTargetEpoch(Date.now());
      }

      // Do NOT await a network measurement in the final 2.5 seconds.
      // Even a fast HEAD request can delay the actual navigation/click by
      // its RTT, which is exactly the latency we are trying to remove. The
      // earlier precheck already established the server offset; the final
      // window is reserved for the real action and connection warm-up.
      const remaining = targetEpochMs - Date.now();

      // Keep the TTD origin connection warm during the final second. This
      // cannot move the trigger earlier; it only tries to avoid paying a
      // fresh DNS/TCP/TLS setup cost when the browser performs the real
      // navigation/click.
      if (remaining > 0 && remaining <= 3000) {
        warmTTDConnection();
      }

      if (remaining <= 0) {
        triggerAction();
      } else {
        timer = setTimeout(schedule, Math.min(Math.max(remaining, 2), remaining <= 1000 ? 25 : 250));
      }
    }, Math.max(0, delay));
  }

  async function loadSetting() {
    try {
      const res = await chrome.storage.local.get(TIME_SYNC_KEY);
      const saved = res?.[TIME_SYNC_KEY] || {};
      enabled = !!saved.timeSyncBooking;
      targetTime = parseTarget(saved.timeSyncTarget || DEFAULT_TARGET).text;
      action = ["reload", "workflow", "click", "service-click"].includes(saved.timeSyncAction) ? saved.timeSyncAction : "reload";
      savedServiceName = String(saved.timeSyncService || saved.serviceName || "");
      savedServiceKey = String(saved.serviceKey || "");
    } catch (_) {
      enabled = false;
      targetTime = DEFAULT_TARGET;
    }
    if (enabled) {
      status(`[TTD Sync] Armed for ${targetTime} IST — final server-time sync enabled (${action === "service-click" ? `service: ${savedServiceName || "not set"}` : action}).`);
      if (action === "workflow") {
        try {
          const p = istParts(Date.now() + serverOffsetMs);
          const targetKey = `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
          if (sessionStorage.getItem("__ttdTimeSyncWorkflowFor") === targetKey) {
            setTimeout(runPostReloadWorkflow, 900);
            return;
          }
        } catch (_) {}
      }
      if (action === "service-click") {
        try {
          const pending = JSON.parse(sessionStorage.getItem(SERVICE_RETRY_MARKER) || "null");
          if (pending && pending.key === serviceRetryKey()) {
            setTimeout(() => { recoverServiceReleaseAfterReload().catch(() => {}); }, 500);
            return;
          }
        } catch (_) {}
      }
      schedule();
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[TIME_SYNC_KEY]) return;

    const saved = changes[TIME_SYNC_KEY].newValue || {};
    const nextEnabled = !!saved.timeSyncBooking;
    const nextTargetTime = parseTarget(saved.timeSyncTarget || DEFAULT_TARGET).text;
    const nextAction = ["reload", "workflow", "click", "service-click"].includes(saved.timeSyncAction) ? saved.timeSyncAction : "reload";
    const nextServiceName = String(saved.timeSyncService || saved.serviceName || "");
    const nextServiceKey = String(saved.serviceKey || "");

    // The WHOLE extension state — every pilgrim, contact field, everything —
    // is saved under this same storage key, so this listener used to fire
    // (and reset the whole armed countdown, including re-measuring server
    // time from scratch) on every unrelated save too, not just an actual
    // change to one of the time-sync settings. Typing in any field anywhere
    // in the popup — even after arming — kept re-triggering this reset; if
    // that happened repeatedly close to the target time, the trigger point
    // kept getting pushed a little further out and could end up never firing
    // at all. Only reset when a setting this feature actually cares about
    // has genuinely changed.
    if (
      nextEnabled === enabled &&
      nextTargetTime === targetTime &&
      nextAction === action &&
      nextServiceName === savedServiceName &&
      nextServiceKey === savedServiceKey
    ) {
      return;
    }

    enabled = nextEnabled;
    targetTime = nextTargetTime;
    action = nextAction;
    savedServiceName = nextServiceName;
    savedServiceKey = nextServiceKey;
    executed = false;
    latencyChecked = false;
    serverOffsetMs = 0;
    targetEpochMs = null;
    pinnedTargetDate = null;

    if (enabled) {
      status(`[TTD Sync] Armed for ${targetTime} IST — final server-time sync enabled (${action === "service-click" ? `service: ${savedServiceName || "not set"}` : action}).`);
      if (action === "workflow") {
        try {
          const p = istParts(Date.now() + serverOffsetMs);
          const targetKey = `${targetTime}|${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
          if (sessionStorage.getItem("__ttdTimeSyncWorkflowFor") === targetKey) {
            setTimeout(runPostReloadWorkflow, 900);
            return;
          }
        } catch (_) {}
      }
      schedule();
    } else {
      clearTimeout(timer);
      status("[TTD Sync] Disabled.");
    }
  });

  loadSetting();
})();

