'use strict';
// popup.js reads saved data with storage.local.get(keys, callback); make sure the shim honours it.
const fs = require('fs'); const assert = require('assert'); const { JSDOM } = require('jsdom');
const src = fs.readFileSync(__dirname + '/../popup-shim.js', 'utf8').replace(/__TOKEN__/g, 't');
const dom = new JSDOM('<body></body>', { url: 'http://127.0.0.1:8787/popup.html', runScripts: 'outside-only' });
const w = dom.window;
w.EventSource = function () {};
w.fetch = (u, o) => { const b = JSON.parse(o.body); return Promise.resolve({ json: () => Promise.resolve({ ok: true, value: b.kind === 'storage.get' ? { pilgrimAutofillData: { x: 1 } } : null }) }); };
w.eval(src);
let got;
w.chrome.storage.local.get(['pilgrimAutofillData'], (r) => { got = r; });
setTimeout(() => { assert.deepStrictEqual(got, { pilgrimAutofillData: { x: 1 } }); console.log('popup-shim callback OK'); process.exit(0); }, 100);
