'use strict';
// Smoke test against a mock Chrome DevTools endpoint (no real Chrome needed).
const http = require('http');
const assert = require('assert');
const WebSocket = require('ws');
process.env.GOV_PORT = '18787';
process.env.GOV_CDP = 'http://127.0.0.1:19222';
process.env.GOV_DATA = require('os').tmpdir() + '/govinda-test-' + process.pid;

const calls = [];
const httpSrv = http.createServer((req, res) => {
  if (req.url === '/json/version') {
    res.end(JSON.stringify({ Browser: 'MockChrome', webSocketDebuggerUrl: 'ws://127.0.0.1:19222/devtools/browser/x' }));
  } else { res.statusCode = 404; res.end(); }
});
const wss = new WebSocket.Server({ server: httpSrv });
wss.on('connection', (ws) => {
  const ev = (method, params, sessionId) => ws.send(JSON.stringify({ method, params, sessionId }));
  ws.on('message', (raw) => {
    const m = JSON.parse(raw); calls.push(m);
    let result = {};
    if (m.method === 'Target.attachToTarget') result = { sessionId: 'S1' };
    if (m.method === 'Runtime.evaluate') {
      const e = m.params.expression;
      result = { result: { value: /visibilityState/.test(e) ? 'visible' : /__f\(/.test(e) ? 'RAN' : undefined } };
      if (/__f\(/.test(e)) result = { result: { value: { ok: true, echo: e.includes('"hello"') } } };
    }
    ws.send(JSON.stringify({ id: m.id, result, sessionId: m.sessionId }));
    if (m.method === 'Target.setDiscoverTargets')
      ev('Target.targetCreated', { targetInfo: { targetId: 'T1', type: 'page', url: 'https://ttdevasthanams.ap.gov.in/x', title: 'TTD' } });
    if (m.method === 'Runtime.enable')
      ev('Runtime.executionContextCreated', { context: { id: 7, origin: 'https://ttdevasthanams.ap.gov.in', auxData: { isDefault: true, frameId: 'T1' } } }, 'S1');
  });
});

function rpc(port, token, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: '/api/rpc', method: 'POST', headers: { 'content-type': 'application/json', 'x-gov-token': token, 'content-length': Buffer.byteLength(data) } },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => resolve(JSON.parse(b))); });
    r.on('error', reject); r.end(data);
  });
}
function get(port, p, host) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port, path: p, headers: host ? { host } : {} }, (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => resolve({ status: res.statusCode, body: b })); }).on('error', reject);
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

httpSrv.listen(19222, async () => {
  require('../server').start();
  await sleep(1200);
  try {
    const page = await get(18787, '/popup.html');
    assert(page.body.includes('/__shim/popup-shim.js'), 'popup shim injected');
    const shim = await get(18787, '/__shim/popup-shim.js');
    const token = /var TOKEN = '([0-9a-f]+)'/.exec(shim.body)[1];
    assert.strictEqual((await get(18787, '/popup.html', 'evil.example:18787')).status, 403, 'rebinding host rejected');
    assert.strictEqual((await rpc(18787, 'wrong', { kind: 'tabs.list' })).ok, false, 'bad token rejected');

    await rpc(18787, token, { kind: 'storage.set', items: { card: { n: 1 } } });
    assert.deepStrictEqual((await rpc(18787, token, { kind: 'storage.get', keys: 'card' })).value, { card: { n: 1 } });

    const tabsList = (await rpc(18787, token, { kind: 'tabs.list' })).value;
    assert.strictEqual(tabsList.length, 1, 'page tab attached');
    const active = (await rpc(18787, token, { kind: 'tabs.active' })).value;
    assert.strictEqual(active.id, tabsList[0].id);

    const ex = await rpc(18787, token, { kind: 'scripting.exec', tabId: active.id, allFrames: true, func: '(a) => ({ok:true})', args: ['hello'] });
    assert(ex.ok && ex.value[0].result.echo, 'executeScript ran in page context: ' + JSON.stringify(ex));

    // background.js message handler -> CDP Input events
    await rpc(18787, token, { kind: 'msg', tabId: active.id, msg: { action: 'pilgrimTrustedTap', x: 10, y: 20 } });
    const types = calls.filter((c) => c.method === 'Input.dispatchMouseEvent').map((c) => c.params.type);
    assert.deepStrictEqual(types, ['mouseMoved', 'mousePressed', 'mouseReleased'], 'trusted tap -> CDP mouse events');
    assert(calls.some((c) => c.method === 'Page.addScriptToEvaluateOnNewDocument' && c.params.source.includes('pilgrimAutofillRun')), 'content.js injected');

    const q = await rpc(18787, token, { kind: 'msg', msg: { type: 'PILGRIM_SYNC_TAB_QUEUE', queue: [] } });
    assert.deepStrictEqual(q.value, { ok: true }, 'background async handler responds');
    console.log('ALL SMOKE TESTS PASSED');
    process.exit(0);
  } catch (e) { console.error('FAIL', e); process.exit(1); }
});
