#!/data/data/com.termux/files/usr/bin/bash
# One-time setup inside Termux (install Termux from F-Droid, not the Play Store).
set -e
pkg update -y
pkg install -y nodejs android-tools termux-api
cd "$(dirname "$0")"
npm install --omit=dev
cat <<MSG

Setup done. Next (once, then after every reboot):
 1. Settings > Developer options > turn on "Wireless debugging" (connect to Wi-Fi first).
 2. Tap "Pair device with pairing code". Keep that screen open (use split-screen with Termux) and run:
        adb pair 127.0.0.1:<PAIRING_PORT>      # type the 6-digit code
 3. Back on the Wireless debugging screen note the "IP address & Port", then run:
        adb connect 127.0.0.1:<PORT>
 4. Run:  ./start.sh
MSG
