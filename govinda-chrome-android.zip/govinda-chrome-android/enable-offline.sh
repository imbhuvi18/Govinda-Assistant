#!/data/data/com.termux/files/usr/bin/bash
# Run ONCE while connected to Wi-Fi (after `adb pair` + `adb connect`).
# Switches adb to a fixed local port (5555) that keeps working with Wi-Fi OFF,
# until the phone is rebooted.
adb devices | grep -q "device$" || { echo "Not connected. Do: adb connect 127.0.0.1:<wireless-debugging-port>"; exit 1; }
adb tcpip 5555
sleep 3
adb connect 127.0.0.1:5555
adb devices
echo
echo "If 127.0.0.1:5555 shows 'device', you can now turn Wi-Fi off and use ./start.sh anywhere."
echo "Repeat this once after every phone reboot."
