'use strict';
// Govinda Assistant bridge for Chrome on Android.
//
// Chrome for Android cannot load extensions, so this process (run in Termux)
// attaches to the real Chrome app through its DevTools socket and plays the
// role of the extension's browser:
//   * injects content.js into every frame (with a small chrome.* shim),
//   * runs the unmodified background.js with a chrome.* host built on CDP,
//   * serves the unmodified popup UI on http://127.0.0.1:<port>/ and shows it
//     over the TTD page through a floating "G" button.

const fs = require('fs');
const path = require('path');
const http = require('http');
const vm = require('vm');
const os = require('os');
const crypto = require('crypto');
const cp = require('child_process');
const WebSocket = require('ws');
const { buildPageScript } = require('./page-shim');

const CFG = {
  cdp: process.env.GOV_CDP || 'http://127.0.0.1:9222',
  port: Number(process.env.GOV_PORT || 8787),
  touch: process.env.GOV_TOUCH === '1',            // send real touch events instead of mouse events
  embed: process.env.GOV_EMBED !== '0',            // floating "G" panel on TTD pages
  launcherHosts: process.env.GOV_LAUNCHER_HOSTS || 'ttd|tirumala',
  bypassCsp: process.env.GOV_BYPASS_CSP !== '0',   // needed so the panel iframe can load
  data: process.env.GOV_DATA || path.join(os.homedir(), '.govinda')
};
const EXT = path.join(__dirname, 'ext');
const BIND = '__gvBridge' + crypto.randomBytes(4).toString('hex');
const TOKEN = crypto.randomBytes(16).toString('hex');
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

fs.mkdirSync(CFG.data, { recursive: true });

// ---------------------------------------------------------------- storage --
const STORE_FILE = path.join(CFG.data, 'storage.json');
const stores = { local: {}, session: {} };
try { stores.local = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8')); } catch (_) {}
let saveTimer = null;
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { fs.writeFileSync(STORE_FILE, JSON.stringify(stores.local), { mode: 0o600 }); } catch (e) { log('save failed', e.message); }
  }, 200);
}
const storageListeners = [];
const sseClients = new Set();
function sse(obj) {
  const line = `data: ${JSON.stringify(obj)}\n\n`;
  for (const res of sseClients) { try { res.write(line); } catch (_) {} }
}
function area(name) {
  const data = () => stores[name];
  const pick = (keys) => {
    const d = data();
    if (keys == null) return JSON.parse(JSON.stringify(d));
    const out = {};
    if (typeof keys === 'string') keys = [keys];
    if (Array.isArray(keys)) { for (const k of keys) if (k in d) out[k] = d[k]; }
    else { for (const k of Object.keys(keys)) out[k] = k in d ? d[k] : keys[k]; }
    return JSON.parse(JSON.stringify(out));
  };
  const change = (changes) => {
    if (!Object.keys(changes).length) return;
    if (name === 'local') persist();
    for (const l of storageListeners) { try { l(changes, name); } catch (_) {} }
    pushToPages({ push: 'storage', changes, area: name });
    sse({ type: 'storage', changes, area: name });
  };
  return {
    async get(keys) { return pick(keys); },
    async set(items) {
      const d = data(), changes = {};
      for (const [k, v] of Object.entries(items || {})) {
        const nv = JSON.parse(JSON.stringify(v === undefined ? null : v));
        changes[k] = { oldValue: d[k], newValue: nv };
        d[k] = nv;
      }
      change(changes);
    },
    async remove(keys) {
      const d = data(), changes = {};
      for (const k of [].concat(keys)) if (k in d) { changes[k] = { oldValue: d[k] }; delete d[k]; }
      change(changes);
    }
  };
}

// -------------------------------------------------------------------- CDP --
class CDP {
  constructor() { this.ws = null; this.id = 0; this.calls = new Map(); this.onEvent = () => {}; this.onClose = () => {}; }
  async connect() {
    const base = new URL(CFG.cdp);
    const info = await new Promise((resolve, reject) => {
      http.get(new URL('/json/version', base), (res) => {
        let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(e); } });
      }).on('error', reject);
    });
    const u = new URL(info.webSocketDebuggerUrl);
    u.host = base.host;                                  // always go through the forwarded port
    await new Promise((resolve, reject) => {
      this.ws = new WebSocket(u.toString(), { perMessageDeflate: false });
      this.ws.once('open', resolve);
      this.ws.once('error', reject);
    });
    this.ws.on('message', (raw) => {
      const m = JSON.parse(raw);
      if (m.id) {
        const c = this.calls.get(m.id);
        if (!c) return;
        this.calls.delete(m.id);
        m.error ? c.reject(new Error(m.error.message)) : c.resolve(m.result || {});
      } else if (m.method) this.onEvent(m.method, m.params || {}, m.sessionId);
    });
    this.ws.on('close', () => {
      for (const c of this.calls.values()) c.reject(new Error('CDP closed'));
      this.calls.clear();
      this.onClose();
    });
    this.ws.on('error', () => {});
    return info;
  }
  send(method, params, sessionId) {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return reject(new Error('Chrome not connected'));
      const id = ++this.id;
      this.calls.set(id, { resolve, reject });
      const msg = { id, method, params: params || {} };
      if (sessionId) msg.sessionId = sessionId;
      this.ws.send(JSON.stringify(msg));
    });
  }
}
const cdp = new CDP();

// ------------------------------------------------------------ tab registry --
const tabs = new Map();            // tabId -> {id,targetId,session,url,title,lastVisible}
const tabByTarget = new Map();
const sessions = new Map();        // sessionId -> {tabId, kind}
const ctxs = new Map();            // `${session}:${ctxId}` -> {session,ctxId,frameId,tabId}
let nextTabId = 1;
const popupTargets = new Set();
let PAGE_SCRIPT = '';

const tabInfo = (t) => ({ id: t.id, url: t.url, title: t.title, active: true, windowId: 1, status: 'complete' });
const isPopupUrl = (u) => String(u || '').startsWith(`http://127.0.0.1:${CFG.port}`) || String(u || '').startsWith(`http://localhost:${CFG.port}`);
const quiet = () => {};

async function setupSession(sid) {
  const s = (m, p) => cdp.send(m, p, sid).catch(quiet);
  await s('Runtime.addBinding', { name: BIND });
  await s('Page.enable');
  await s('Page.addScriptToEvaluateOnNewDocument', { source: PAGE_SCRIPT });
  if (CFG.bypassCsp) await s('Page.setBypassCSP', { enabled: true });
  await s('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: false, flatten: true });
  await s('Runtime.enable');
}

async function attachPage(ti) {
  if (ti.type !== 'page' || tabByTarget.has(ti.targetId) || popupTargets.has(ti.targetId)) return;
  if (isPopupUrl(ti.url)) { popupTargets.add(ti.targetId); return; }
  const { sessionId } = await cdp.send('Target.attachToTarget', { targetId: ti.targetId, flatten: true });
  const tab = { id: nextTabId++, targetId: ti.targetId, session: sessionId, url: ti.url, title: ti.title || '', lastVisible: 0 };
  tabs.set(tab.id, tab);
  tabByTarget.set(ti.targetId, tab);
  sessions.set(sessionId, { tabId: tab.id, kind: 'page' });
  log(`tab ${tab.id} attached: ${(ti.url || '').slice(0, 70)}`);
  await setupSession(sessionId);
}

function dropTab(targetId) {
  const tab = tabByTarget.get(targetId);
  if (!tab) { popupTargets.delete(targetId); return; }
  tabs.delete(tab.id);
  tabByTarget.delete(targetId);
  for (const [sid, s] of sessions) if (s.tabId === tab.id) sessions.delete(sid);
  for (const [k, c] of ctxs) if (c.tabId === tab.id) ctxs.delete(k);
  fire(removedListeners, tab.id, {});
}

function onCdpEvent(method, p, sid) {
  switch (method) {
    case 'Target.targetCreated':
      attachPage(p.targetInfo).catch((e) => log('attach failed', e.message));
      break;
    case 'Target.targetInfoChanged': {
      const tab = tabByTarget.get(p.targetInfo.targetId);
      if (tab) {
        const change = {};
        if (p.targetInfo.url !== tab.url) change.url = p.targetInfo.url;
        if (p.targetInfo.title !== tab.title) change.title = p.targetInfo.title;
        tab.url = p.targetInfo.url; tab.title = p.targetInfo.title;
        if (change.url) { fire(updatedListeners, tab.id, change, tabInfo(tab)); }
      } else attachPage(p.targetInfo).catch(quiet);   // e.g. a tab that navigated off chrome://
      break;
    }
    case 'Target.targetDestroyed':
      dropTab(p.targetId);
      break;
    case 'Target.attachedToTarget': {          // OOPIF / iframe child session
      const parent = sessions.get(sid);
      if (!parent) break;
      sessions.set(p.sessionId, { tabId: parent.tabId, kind: 'frame' });
      setupSession(p.sessionId).catch(quiet);
      break;
    }
    case 'Target.detachedFromTarget':
      sessions.delete(p.sessionId);
      for (const [k, c] of ctxs) if (c.session === p.sessionId) ctxs.delete(k);
      break;
    case 'Runtime.executionContextCreated': {
      const c = p.context, s = sessions.get(sid);
      if (!s || !c.auxData || !c.auxData.isDefault || !/^https?:/.test(c.origin || '')) break;
      ctxs.set(`${sid}:${c.id}`, { session: sid, ctxId: c.id, frameId: c.auxData.frameId, tabId: s.tabId });
      // Fallback for documents that existed before we attached (guarded inside the script).
      cdp.send('Runtime.evaluate', { expression: PAGE_SCRIPT, contextId: c.id }, sid).catch(quiet);
      break;
    }
    case 'Runtime.executionContextDestroyed':
      ctxs.delete(`${sid}:${p.executionContextId}`);
      break;
    case 'Runtime.executionContextsCleared':
      for (const [k, c] of ctxs) if (c.session === sid) ctxs.delete(k);
      break;
    case 'Runtime.bindingCalled':
      if (p.name === BIND) handleBinding(sid, p.executionContextId, p.payload);
      break;
    case 'Page.frameStartedLoading': {
      const s = sessions.get(sid), tab = s && tabs.get(s.tabId);
      if (tab && s.kind === 'page' && p.frameId === tab.targetId) fire(updatedListeners, tab.id, { status: 'loading' }, tabInfo(tab));
      break;
    }
    case 'Page.loadEventFired': {
      const s = sessions.get(sid), tab = s && tabs.get(s.tabId);
      if (tab && s.kind === 'page') fire(updatedListeners, tab.id, { status: 'complete' }, tabInfo(tab));
      break;
    }
  }
}

function pageContexts(tabId, topOnly) {
  const tab = tabs.get(tabId);
  const all = [...ctxs.values()].filter((c) => c.tabId === tabId);
  const top = all.filter((c) => tab && c.frameId === tab.targetId);
  if (topOnly) return top;
  return [...top, ...all.filter((c) => !top.includes(c))];
}

function pushToPages(msg) {
  const expr = `window[Symbol.for('govinda.recv')]&&window[Symbol.for('govinda.recv')](${JSON.stringify(msg)})`;
  for (const c of ctxs.values()) cdp.send('Runtime.evaluate', { expression: expr, contextId: c.ctxId }, c.session).catch(quiet);
}

function replyToPage(sid, ctxId, obj) {
  const expr = `window[Symbol.for('govinda.recv')]&&window[Symbol.for('govinda.recv')](${JSON.stringify(obj)})`;
  cdp.send('Runtime.evaluate', { expression: expr, contextId: ctxId }, sid).catch(quiet);
}

async function handleBinding(sid, ctxId, payload) {
  let req;
  try { req = JSON.parse(payload); } catch (_) { return; }
  const s = sessions.get(sid);
  const ctx = ctxs.get(`${sid}:${ctxId}`);
  const reply = (o) => replyToPage(sid, ctxId, Object.assign({ id: req.id }, o));
  try {
    if (req.kind === 'who') return reply({ ok: true, value: { tabId: s && s.tabId } });
    if (req.kind === 'storage.get') return reply({ ok: true, value: await area('local').get(req.keys) });
    if (req.kind === 'storage.set') { await area('local').set(req.items); return reply({ ok: true, value: null }); }
    if (req.kind === 'msg') {
      const tab = s && tabs.get(s.tabId);
      const sender = { tab: tab ? tabInfo(tab) : undefined, frameId: ctx ? ctx.frameId : undefined, id: 'govinda-bridge' };
      return reply({ ok: true, value: await dispatchMessage(req.msg, sender) });
    }
    reply({ ok: false, error: 'unknown kind ' + req.kind });
  } catch (e) { reply({ ok: false, error: String(e && e.message || e) }); }
}

// ------------------------------------------------------------ chrome.* host --
function emitter() { return []; }
const messageListeners = emitter();
const updatedListeners = emitter();
const removedListeners = emitter();
const alarmListeners = emitter();
function fire(list, ...args) {
  for (const f of list) { try { f(...args); } catch (e) { log('listener error', e.message); } }
  if (list === updatedListeners) sse({ type: 'tabUpdated', tabId: args[0], changeInfo: args[1], tab: args[2] });
}

function dispatchMessage(msg, sender) {
  return new Promise((resolve) => {
    let done = false, async_ = false;
    const respond = (r) => { if (!done) { done = true; resolve(r); } };
    for (const l of messageListeners) {
      try { if (l(msg, sender, respond) === true) async_ = true; } catch (e) { log('onMessage error', e.message); }
    }
    if (!async_ && !done) resolve(undefined);
    else setTimeout(() => respond(undefined), 120000);
  });
}

const alarms = new Map();          // name -> {name, scheduledTime, timer}
function alarmCreate(name, info) {
  alarmClear(name);
  let when = info.when != null ? info.when : Date.now() + (info.delayInMinutes != null ? info.delayInMinutes : (info.periodInMinutes || 0)) * 60000;
  const timer = setTimeout(() => {
    alarms.delete(name);
    for (const l of alarmListeners) { try { l({ name, scheduledTime: when }); } catch (e) { log('alarm error', e.message); } }
  }, Math.max(0, when - Date.now()));
  alarms.set(name, { name, scheduledTime: when, timer });
}
function alarmClear(name) {
  const a = alarms.get(name);
  if (a) { clearTimeout(a.timer); alarms.delete(name); return true; }
  return false;
}

function topTab(tabId) {
  const t = tabs.get(tabId);
  if (!t) throw new Error('No tab with id: ' + tabId);
  return t;
}

async function executeScript({ target, func, args }) {
  const tabId = target.tabId;
  topTab(tabId);
  const fnSrc = typeof func === 'function' ? func.toString() : String(func);
  const expression = `(async () => { const __f = (${fnSrc}); return await __f(...${JSON.stringify(args || [])}); })()`;
  const list = pageContexts(tabId, !target.allFrames);
  if (!list.length) throw new Error('No frame with id 0 in tab ' + tabId);
  const out = []; let firstErr = null;
  for (const c of list) {
    try {
      const r = await cdp.send('Runtime.evaluate', { expression, contextId: c.ctxId, awaitPromise: true, returnByValue: true }, c.session);
      if (r.exceptionDetails) throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
      out.push({ frameId: c.frameId, result: r.result ? r.result.value : undefined });
    } catch (e) {
      if (!target.allFrames) throw e;
      firstErr = firstErr || e;
    }
  }
  if (!out.length && firstErr) throw firstErr;
  return out;
}

async function sendCommand(tabId, method, params) {
  const tab = topTab(tabId);
  if (CFG.touch && method === 'Input.dispatchMouseEvent') {
    if (params.type === 'mousePressed') return cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: params.x, y: params.y }] }, tab.session);
    if (params.type === 'mouseReleased') return cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }, tab.session);
    return {};
  }
  return cdp.send(method, params, tab.session);
}

function notify(title, message) {
  log('NOTIFY', title, message || '');
  sse({ type: 'notify', title, message });
  try { cp.execFile('termux-notification', ['--title', String(title), '--content', String(message || '')], quiet); } catch (_) {}
}

function activeTab(prefer) {
  if (prefer != null && tabs.has(prefer)) return tabs.get(prefer);
  const list = [...tabs.values()].filter((t) => /^https?:/.test(t.url || ''));
  list.sort((a, b) => b.lastVisible - a.lastVisible);
  return list[0] || null;
}

const chromeHost = {
  storage: {
    local: area('local'),
    session: area('session'),
    onChanged: { addListener: (f) => storageListeners.push(f) }
  },
  alarms: {
    create: (name, info) => alarmCreate(name, info || {}),
    clear: async (name) => alarmClear(name),
    getAll: async () => [...alarms.values()].map((a) => ({ name: a.name, scheduledTime: a.scheduledTime })),
    onAlarm: { addListener: (f) => alarmListeners.push(f) }
  },
  tabs: {
    create: async (o) => {
      const r = await cdp.send('Target.createTarget', { url: o.url });
      return { id: -1, url: o.url, targetId: r.targetId };
    },
    query: async () => [...tabs.values()].map(tabInfo),
    onUpdated: { addListener: (f) => updatedListeners.push(f) },
    onRemoved: { addListener: (f) => removedListeners.push(f) }
  },
  scripting: { executeScript },
  debugger: {
    attach: async () => {},
    detach: async () => {},
    sendCommand: ({ tabId }, method, params) => sendCommand(tabId, method, params),
    getTargets: async () => [...tabs.values()].map((t) => ({ tabId: t.id, attached: true, type: 'page', url: t.url })),
    onDetach: { addListener: () => {} }
  },
  runtime: {
    onMessage: { addListener: (f) => messageListeners.push(f) },
    sendMessage: async () => undefined,
    getURL: (p) => p
  },
  notifications: { create: (o) => notify(o.title, o.message) },
  action: { setBadgeText: ({ text }) => { if (text) log('badge', text); }, setBadgeBackgroundColor: () => {} }
};

function startBackground() {
  const sandbox = { chrome: chromeHost, console, setTimeout, clearTimeout, setInterval, clearInterval, URL, URLSearchParams, fetch };
  sandbox.self = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(EXT, 'background.js'), 'utf8'), sandbox, { filename: 'background.js' });
  log('background.js loaded');
}

// ------------------------------------------------------------ popup server --
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png' };
const STATIC = new Set(['popup.html', 'popup.css', 'popup.js', 'platform.js']);

function readBody(req) {
  return new Promise((resolve, reject) => {
    let b = ''; req.on('data', (c) => { b += c; if (b.length > 5e6) req.destroy(); });
    req.on('end', () => resolve(b)); req.on('error', reject);
  });
}

async function rpc(body) {
  switch (body.kind) {
    case 'storage.get': return area('local').get(body.keys);
    case 'storage.set': await area('local').set(body.items); return null;
    case 'status': return { connected: !!(cdp.ws && cdp.ws.readyState === WebSocket.OPEN), tabs: tabs.size };
    case 'tabs.list': return [...tabs.values()].filter((t) => /^https?:/.test(t.url || '')).map(tabInfo);
    case 'tabs.active': { const t = activeTab(body.prefer); return t ? tabInfo(t) : null; }
    case 'tabs.create': return chromeHost.tabs.create({ url: body.url });
    case 'scripting.exec': return executeScript({ target: { tabId: body.tabId, allFrames: body.allFrames }, func: body.func, args: body.args });
    case 'msg': {
      const t = activeTab(body.tabId);
      return dispatchMessage(body.msg, { id: 'govinda-popup', tab: t ? tabInfo(t) : undefined });
    }
    default: throw new Error('unknown rpc ' + body.kind);
  }
}

const server = http.createServer(async (req, res) => {
  const host = String(req.headers.host || '');
  if (host !== `127.0.0.1:${CFG.port}` && host !== `localhost:${CFG.port}`) { res.writeHead(403); return res.end('bad host'); }
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/') { res.writeHead(302, { location: '/popup.html' }); return res.end(); }
    if (url.pathname === '/__shim/popup-shim.js') {
      const src = fs.readFileSync(path.join(__dirname, 'popup-shim.js'), 'utf8').replace(/__TOKEN__/g, TOKEN);
      res.writeHead(200, { 'content-type': MIME['.js'], 'cache-control': 'no-store' });
      return res.end(src);
    }
    if (url.pathname === '/api/events') {
      if (url.searchParams.get('token') !== TOKEN) { res.writeHead(403); return res.end(); }
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' });
      res.write(': ok\n\n');
      sseClients.add(res);
      const ka = setInterval(() => { try { res.write(': ka\n\n'); } catch (_) {} }, 20000);
      req.on('close', () => { clearInterval(ka); sseClients.delete(res); });
      return;
    }
    if (url.pathname === '/api/rpc' && req.method === 'POST') {
      if (req.headers['x-gov-token'] !== TOKEN) { res.writeHead(403); return res.end('{"ok":false,"error":"forbidden"}'); }
      let out;
      try { out = { ok: true, value: await rpc(JSON.parse(await readBody(req))) }; }
      catch (e) { out = { ok: false, error: String(e && e.message || e) }; }
      res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      return res.end(JSON.stringify(out === undefined ? { ok: true } : out));
    }
    const name = url.pathname.slice(1);
    const isIcon = /^icons\/icon\d+\.png$/.test(name);
    if (STATIC.has(name) || isIcon) {
      let data = fs.readFileSync(path.join(EXT, name));
      if (name === 'popup.html') {
        data = Buffer.from(data.toString('utf8').replace(/<script src="platform\.js"><\/script>/, '<script src="/__shim/popup-shim.js"></script>\n<script src="platform.js"></script>'));
      }
      res.writeHead(200, { 'content-type': MIME[path.extname(name)] || 'application/octet-stream', 'cache-control': 'no-store' });
      return res.end(data);
    }
    res.writeHead(404); res.end('not found');
  } catch (e) { res.writeHead(500); res.end(String(e && e.message || e)); }
});

// ------------------------------------------------------------------- main --
async function connectLoop() {
  for (;;) {
    try {
      const info = await cdp.connect();
      log('connected to', info.Browser || 'Chrome');
      cdp.onEvent = onCdpEvent;
      const closed = new Promise((r) => (cdp.onClose = r));
      await cdp.send('Target.setDiscoverTargets', { discover: true });
      const vis = setInterval(pollVisibility, 1500);
      await closed;
      clearInterval(vis);
      log('Chrome connection lost - retrying (is wireless debugging still on?)');
      for (const t of [...tabs.values()]) dropTab(t.targetId);
    } catch (e) {
      log('waiting for Chrome DevTools on', CFG.cdp, '-', e.message);
    }
    await new Promise((r) => setTimeout(r, 2500));
  }
}

function pollVisibility() {
  for (const t of tabs.values()) {
    cdp.send('Runtime.evaluate', { expression: 'document.visibilityState', returnByValue: true }, t.session)
      .then((r) => { if (r.result && r.result.value === 'visible') t.lastVisible = Date.now(); }, quiet);
  }
}

function start() {
  const contentSrc = fs.readFileSync(path.join(EXT, 'content.js'), 'utf8');
  const launcherRe = '/' + CFG.launcherHosts.replace(/\//g, '\\/') + '/i';
  PAGE_SCRIPT = buildPageScript({ contentSrc, bind: BIND, port: CFG.port, embed: CFG.embed, launcherRe });
  startBackground();
  server.listen(CFG.port, '127.0.0.1', () => {
    log(`Govinda bridge ready. Open  http://127.0.0.1:${CFG.port}/  (or tap the G button on the TTD page)`);
  });
  connectLoop();
}

if (require.main === module) start();
module.exports = { start, CFG };
